import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_session.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';

import '../models/media_asset.dart';
import '../models/composition.dart';
import '../models/project.dart';
import 'composition_engine.dart';
import '../models/timeline.dart';
import 'three_d_offscreen_renderer.dart';

class ExportProgress {
  const ExportProgress({required this.fraction, required this.message});
  final double fraction;
  final String message;
}

class ExportService {
  FFmpegSession? _androidSession;
  Process? _desktopProcess;
  bool _cancelRequested = false;

  Future<void> cancel() async {
    _cancelRequested = true;
    await _androidSession?.cancel();
    _desktopProcess?.kill(ProcessSignal.sigterm);
  }

  Future<void> export(
    Project project,
    String outputPath, {
    void Function(ExportProgress progress)? onProgress,
  }) async {
    _cancelRequested = false;
    final finalOutput = outputPath;
    final temporaryOutput = '$outputPath.openreel-part.mp4';
    final object3dClips = project.tracks
        .where((track) => !track.hidden && track.kind == TrackKind.object3d)
        .expand((track) => track.clips)
        .where((clip) => clip.enabled)
        .toList();
    final trackOrder = <String, int>{
      for (var i = 0; i < project.tracks.length; i++) project.tracks[i].id: i,
    };
    final videoClips =
        project.tracks
            .where((track) => !track.hidden)
            .expand((track) => track.clips)
            .where((clip) => clip.enabled)
            .where((clip) {
              final kind = _asset(project, clip.assetId)?.kind;
              return kind == MediaKind.video || kind == MediaKind.image;
            })
            .toList()
          ..sort((a, b) {
            final trackCompare =
                (trackOrder[a.trackId] ?? 0).compareTo(trackOrder[b.trackId] ?? 0);
            if (trackCompare != 0) return trackCompare;
            return a.startMs.compareTo(b.startMs);
          });
    if (videoClips.isEmpty && object3dClips.isEmpty) {
      throw StateError('Adicione pelo menos uma mídia visual à timeline.');
    }

    // Fail with the renderer/platform capability before validating individual
    // 3D assets. This keeps the unsupported-platform contract deterministic
    // while preserving real asset validation on supported platforms.
    if (object3dClips.isNotEmpty &&
        !Platform.isAndroid &&
        !Platform.isIOS &&
        !Platform.isMacOS &&
        !Platform.isWindows) {
      throw UnsupportedError(
        'Renderização 3D offline requer um backend WebView com WebGL nesta plataforma.',
      );
    }

    final audioClips = project.tracks
        .where((track) => !track.hidden)
        .expand((track) => track.clips)
        .where((clip) => clip.enabled)
        .where((clip) => _asset(project, clip.assetId)?.kind == MediaKind.audio)
        .toList();
    final settings = project.exportSettings;
    final inferredDurationMs = [
      ...videoClips.map((clip) => clip.endMs),
      ...object3dClips.map((clip) => clip.endMs),
    ].fold<int>(0, (max, value) => value > max ? value : max);
    final effectiveDurationMs = project.durationMs > 0
        ? project.durationMs
        : inferredDurationMs;
    final compositionEngine = CompositionEngine();
    final startFrames = <String, CompositionLayer>{};
    for (final clip in videoClips) {
      final frame = compositionEngine.compose(project, clip.startMs);
      final layer = frame.layers.cast<CompositionLayer?>().firstWhere(
        (candidate) => candidate?.clipId == clip.id,
        orElse: () => null,
      );
      if (layer == null) {
        throw StateError('CompositionFrame não contém o clipe ${clip.id} no início da renderização.');
      }
      startFrames[clip.id] = layer;
    }
    final threeDFrameDirs = <String, Directory>{};
    final threeDRenderer = ThreeDOffscreenRenderer();
    Directory? threeDWorkRoot;
    if (object3dClips.isNotEmpty) {
      threeDWorkRoot = Directory(
        '${File(outputPath).parent.path}/.openreel-3d-${DateTime.now().microsecondsSinceEpoch}',
      );
      await threeDWorkRoot.create(recursive: true);
      try {
        for (var i = 0; i < object3dClips.length; i++) {
        final clip = object3dClips[i];
        final assetId = clip.object3dAssetId;
        if (assetId == null) throw StateError('Clipe 3D ${clip.id} não possui asset 3D.');
        final asset = project.model3dAssets.where((item) => item.id == assetId).firstOrNull;
        if (asset == null) throw StateError('Asset 3D $assetId não encontrado.');
        final initialLayer = compositionEngine.compose(project, clip.startMs).layers.where((l) => l.clipId == clip.id).firstOrNull;
        if (initialLayer == null) throw StateError('CompositionFrame não contém o clipe 3D ${clip.id}.');
        final dir = await threeDRenderer.renderClip(
          asset: asset,
          layer: initialLayer,
          width: settings.width,
          height: settings.height,
          fps: settings.fps,
          durationMs: clip.durationMs,
          outputDirectory: threeDWorkRoot,
          layerAt: (timelineMs) => compositionEngine.compose(project, timelineMs).layers.where((l) => l.clipId == clip.id).firstOrNull ?? initialLayer,
          onProgress: (fraction) => onProgress?.call(ExportProgress(
            fraction: 0.05 + 0.20 * ((i + fraction) / object3dClips.length),
            message: 'Renderizando 3D ${i + 1}/${object3dClips.length}…',
          )),
        );
        threeDFrameDirs[clip.id] = dir;
      }
      } catch (_) {
        await threeDRenderer.dispose();
        if (threeDWorkRoot.existsSync()) await threeDWorkRoot.delete(recursive: true);
        rethrow;
      }
    }
    final args = <String>['-y'];
    final assets = <MediaAsset>[];
    for (final clip in videoClips) {
      final asset = _asset(project, clip.assetId)!;
      if (!File(asset.path).existsSync())
        throw StateError('Arquivo não encontrado: ${asset.name}');
      assets.add(asset);
      args.addAll(['-i', asset.path]);
    }

    for (final clip in audioClips) {
      final asset = _asset(project, clip.assetId)!;
      if (!File(asset.path).existsSync())
        throw StateError('Arquivo de áudio não encontrado: ${asset.name}');
      args.addAll(['-i', asset.path]);
    }

    final threeDInputIndex = <String, int>{};
    var nextInputIndex = videoClips.length + audioClips.length;
    for (final clip in object3dClips) {
      final dir = threeDFrameDirs[clip.id];
      if (dir == null) throw StateError('Frames 3D ausentes para ${clip.id}.');
      threeDInputIndex[clip.id] = nextInputIndex++;
      args.addAll(['-framerate', '${settings.fps}', '-i', '${dir.path}/frame_%07d.png']);
    }

    final filters = <String>[];
    for (var i = 0; i < videoClips.length; i++) {
      final clip = videoClips[i];
      final asset = assets[i];
      final layer = startFrames[clip.id]!;
      final sourceDuration = clip.durationMs * clip.speed / 1000;
      final start = layer.localTimeMs / 1000;
      final timelineStart = clip.startMs / 1000;
      final chain = <String>[
        'trim=start=${start.toStringAsFixed(3)}:duration=${sourceDuration.toStringAsFixed(3)}',
        'setpts=PTS-STARTPTS',
      ];
      if (clip.speed != 1) {
        chain.add('setpts=${(1 / clip.speed).toStringAsFixed(5)}*PTS');
      }
      chain.addAll([
        'setpts=PTS+${timelineStart.toStringAsFixed(3)}/TB',
        'scale=${settings.width}:${settings.height}:force_original_aspect_ratio=decrease',
        'fps=${settings.fps}',
      ]);
      final scaleX = _keyframeExpression(
        clip.scaleXKeyframes.isEmpty
            ? clip.scaleKeyframes
            : clip.scaleXKeyframes,
        layer.transform.scaleX,
        speed: clip.speed,
        timelineStartMs: clip.startMs,
      );
      final scaleY = _keyframeExpression(
        clip.scaleYKeyframes,
        layer.transform.scaleY,
        speed: clip.speed,
        timelineStartMs: clip.startMs,
      );
      if (scaleX != '1' || scaleY != '1') {
        chain.add('scale=iw*${scaleX}:ih*${scaleY}');
      }
      final rotation = _keyframeExpression(
        clip.rotationKeyframes,
        layer.transform.rotation,
        speed: clip.speed,
        timelineStartMs: clip.startMs,
      );
      if (rotation != '0') {
        chain.add('rotate=(${rotation})*PI/180:fillcolor=black@0');
      }
      for (final effect in clip.effects) chain.add(_effectFilter(effect));
      final opacity = _keyframeExpression(
        clip.opacityKeyframes,
        layer.opacity,
        speed: clip.speed,
        timelineStartMs: clip.startMs,
      );
      if (opacity != '1') {
        final alphaExpression = opacity
            .replaceAll(r'\,', ',')
            .replaceAll('(t-', '(T-')
            .replaceAll('t*', 'T*');
        chain.add(
          "format=rgba,geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='255*($alphaExpression)'",
        );
      }
      if (clip.transitionIn.enabled && clip.transitionIn.type == 'fade') {
        chain.add(
          'fade=t=in:st=0:d=${(clip.transitionIn.durationMs / 1000).toStringAsFixed(3)}:alpha=1',
        );
      }
      if (clip.transitionOut.enabled && clip.transitionOut.type == 'fade') {
        chain.add(
          'fade=t=out:st=${((clip.durationMs - clip.transitionOut.durationMs).clamp(0, clip.durationMs) / 1000).toStringAsFixed(3)}:d=${(clip.transitionOut.durationMs / 1000).toStringAsFixed(3)}:alpha=1',
        );
      }
      chain.add(
        'pad=${settings.width}:${settings.height}:(ow-iw)/2:(oh-ih)/2:color=black@0.0',
      );
      final source = asset.kind == MediaKind.image
          ? '[$i:v]loop=loop=-1:size=1:start=0'
          : '[$i:v]';
      filters.add('$source${chain.join(',')}[v$i]');
    }
    for (final clip in object3dClips) {
      final inputIndex = threeDInputIndex[clip.id]!;
      final label = '[v3d_${_filterId(clip.id)}]';
      final start = clip.startMs / 1000;
      filters.add(
        '[$inputIndex:v]format=rgba,setpts=PTS-STARTPTS+${start.toStringAsFixed(3)}/TB$label',
      );
    }
    final compositionDuration = effectiveDurationMs / 1000;
    filters.add(
      'color=c=black:s=${settings.width}x${settings.height}:r=${settings.fps}:d=${compositionDuration.toStringAsFixed(3)}[base]',
    );
    var composedVideo = '[base]';
    final orderedVisualClips = <TimelineClip>[...videoClips, ...object3dClips]
      ..sort((a, b) {
        final trackCompare = (trackOrder[a.trackId] ?? 0).compareTo(trackOrder[b.trackId] ?? 0);
        if (trackCompare != 0) return trackCompare;
        return a.startMs.compareTo(b.startMs);
      });
    final mediaLabelByClip = <String, String>{
      for (var i = 0; i < videoClips.length; i++) videoClips[i].id: '[v$i]',
    };
    var visualIndex = 0;
    for (final clip in orderedVisualClips) {
      final layer = startFrames[clip.id] ??
          compositionEngine.compose(project, clip.startMs).layers.where((l) => l.clipId == clip.id).firstOrNull;
      if (layer == null) continue;
      final sourceLabel = mediaLabelByClip[clip.id] ?? '[v3d_${_filterId(clip.id)}]';
      final next = '[vcomp${visualIndex++}]';
      final is3d = object3dClips.any((candidate) => candidate.id == clip.id);
      final x = is3d
          ? '0'
          : _keyframeExpression(
              clip.positionXKeyframes.isEmpty ? clip.positionKeyframes : clip.positionXKeyframes,
              layer.transform.x,
              speed: clip.speed,
              timelineStartMs: clip.startMs,
            );
      final y = is3d
          ? '0'
          : _keyframeExpression(
              clip.positionYKeyframes,
              layer.transform.y,
              speed: clip.speed,
              timelineStartMs: clip.startMs,
            );
      final enable = 'between\\(t\\,${(clip.startMs / 1000).toStringAsFixed(3)}\\,${(clip.endMs / 1000).toStringAsFixed(3)}\\)';
      if (clip.blendMode == BlendMode.normal) {
        filters.add('$composedVideo$sourceLabel overlay=x=$x:y=$y:enable=$enable:format=auto$next');
      } else {
        final mode = switch (clip.blendMode) {
          BlendMode.screen => 'screen',
          BlendMode.add => 'addition',
          BlendMode.multiply => 'multiply',
          BlendMode.overlay => 'overlay',
          BlendMode.normal => 'normal',
        };
        final fullLayer = '[vblend${visualIndex}]';
        filters.add(
          'color=c=black:s=${settings.width}x${settings.height}:r=${settings.fps}:d=${compositionDuration.toStringAsFixed(3)}[blendbase${visualIndex}]',
        );
        filters.add(
          '[blendbase${visualIndex}]$sourceLabel overlay=x=$x:y=$y:enable=$enable:format=auto,format=rgba$fullLayer',
        );
        filters.add('$composedVideo$fullLayer blend=all_mode=$mode:all_opacity=1$next');
      }
      composedVideo = next;
    }
    var finalVideoLabel = composedVideo;
    final textClips = project.tracks
        .where((track) => !track.hidden)
        .expand((track) => track.clips)
        .where((clip) => clip.enabled && clip.text?.trim().isNotEmpty == true)
        .toList();
    for (var i = 0; i < textClips.length; i++) {
      final clip = textClips[i];
      final previous = i == 0 ? finalVideoLabel : '[vtext${i - 1}]';
      final next = '[vtext$i]';
      final text = _escapeFilterText(clip.text!);
      final style = clip.textStyle;
      final x = _keyframeExpression(
        clip.positionXKeyframes.isEmpty ? clip.positionKeyframes : clip.positionXKeyframes,
        clip.transform.x,
        speed: clip.speed,
        timelineStartMs: clip.startMs,
      );
      final y = _keyframeExpression(
        clip.positionYKeyframes,
        clip.transform.y,
        speed: clip.speed,
        timelineStartMs: clip.startMs,
      );
      final opacity = _keyframeExpression(
        clip.opacityKeyframes,
        style.opacity * clip.opacity,
        speed: clip.speed,
        timelineStartMs: clip.startMs,
      );
      final fontColor = _escapeFilterText(style.color);
      final outlineColor = _escapeFilterText(style.outlineColor);
      final box = style.background == 'transparent'
          ? ''
          : ':box=1:boxcolor=${_escapeFilterText(style.background)}';
      final align = switch (style.align) {
        'left' => x,
        'right' => 'w-text_w-$x',
        _ => '(w-text_w)/2+$x',
      };
      filters.add(
        '${previous}drawtext=text=$text'
        ':enable=between\\(t\\,${clip.startMs / 1000}\\,${clip.endMs / 1000}\\)'
        ':x=$align:y=$y:fontsize=${style.fontSize.toStringAsFixed(1)}'
        ':fontcolor_expr=${fontColor}@($opacity)'
        ':borderw=${style.outlineWidth.toStringAsFixed(1)}:bordercolor=$outlineColor'
        '$box$next',
      );
      finalVideoLabel = next;
    }

    // Match CompositionEngine: explicit subtitle-track clips take precedence
    // over the project-level imported cue list, preventing duplicate captions.
    final hasSubtitleTrackClips = project.tracks
        .where((track) => !track.hidden && track.kind == TrackKind.subtitle)
        .expand((track) => track.clips)
        .any((clip) => clip.enabled && clip.text?.trim().isNotEmpty == true);
    if (!hasSubtitleTrackClips) {
      for (var i = 0; i < project.subtitleCues.length; i++) {
      final cue = project.subtitleCues[i];
      final previous = finalVideoLabel;
      final next = '[vsub$i]';
      final text = _escapeFilterText(cue.text.replaceAll('\n', r'\n'));
      final style = cue.style;
      final x = '(w-text_w)*${style.x.toStringAsFixed(4)}';
      final y = '(h-text_h)*${style.y.toStringAsFixed(4)}';
      final box = style.background == 'transparent'
          ? ''
          : ':box=1:boxcolor=${_escapeFilterText(style.background)}';
      filters.add(
        '${previous}drawtext=text=$text'
        ':enable=between\\(t\\,${(cue.startMs / 1000).toStringAsFixed(3)}\\,${(cue.endMs / 1000).toStringAsFixed(3)}\\)'
        ':x=$x:y=$y:fontsize=${style.fontSize.toStringAsFixed(1)}'
        ':fontcolor=${_escapeFilterText(style.color)}'
        ':borderw=${style.outlineWidth.toStringAsFixed(1)}'
        ':bordercolor=${_escapeFilterText(style.outlineColor)}$box$next',
      );
        finalVideoLabel = next;
      }
    }

    String? audioLabel;
    final audioSources = <({int inputIndex, TimelineClip clip})>[];
    for (var i = 0; i < videoClips.length; i++) {
      if (assets[i].hasAudio)
        audioSources.add((inputIndex: i, clip: videoClips[i]));
    }
    for (var i = 0; i < audioClips.length; i++) {
      audioSources.add((
        inputIndex: videoClips.length + i,
        clip: audioClips[i],
      ));
    }
    for (var i = 0; i < audioSources.length; i++) {
      final clip = audioSources[i].clip;
      final inputIndex = audioSources[i].inputIndex;
      final delay = clip.startMs;
      final sourceDuration = clip.durationMs * clip.speed / 1000;
      final volume = clip.muted
          ? '0'
          : _keyframeExpression(
              clip.volumeKeyframes,
              clip.volume.clamp(0, 1).toDouble(),
              speed: clip.speed,
              timelineStartMs: clip.startMs,
            );
      final audioChain = <String>[
        'atrim=start=${(clip.sourceStartMs / 1000).toStringAsFixed(3)}:duration=${sourceDuration.toStringAsFixed(3)}',
        'asetpts=PTS-STARTPTS',
        'volume=$volume',
      ];
      if (clip.speed != 1) audioChain.addAll(_atempoFilters(clip.speed));
      if (clip.fadeInMs > 0)
        audioChain.add(
          'afade=t=in:st=0:d=${(clip.fadeInMs / 1000).toStringAsFixed(3)}',
        );
      if (clip.fadeOutMs > 0)
        audioChain.add(
          'afade=t=out:st=${((clip.durationMs - clip.fadeOutMs).clamp(0, clip.durationMs) / 1000).toStringAsFixed(3)}:d=${(clip.fadeOutMs / 1000).toStringAsFixed(3)}',
        );
      if (clip.pan != 0) {
        final left = (1 - clip.pan).clamp(0, 2).toStringAsFixed(3);
        final right = (1 + clip.pan).clamp(0, 2).toStringAsFixed(3);
        audioChain.add('pan=stereo|c0=${left}*c0|c1=${right}*c1');
      }
      audioChain.add('adelay=${delay}|${delay}');
      filters.add('[$inputIndex:a]${audioChain.join(',')}[a$i]');
    }
    if (audioSources.isNotEmpty) {
      final audioInputs = List.generate(
        audioSources.length,
        (i) => '[a$i]',
      ).join();
      filters.add(
        '$audioInputs'
        'amix=inputs=${audioSources.length}:duration=longest:dropout_transition=2[aout]',
      );
      audioLabel = '[aout]';
    }
    args.addAll([
      '-filter_complex',
      filters.join(';'),
      '-map',
      finalVideoLabel,
    ]);

    if (audioLabel != null) args.addAll(['-map', audioLabel]);
    args.addAll([
      '-c:v',
      settings.videoCodec,
      '-crf',
      '${settings.crf}',
      '-b:v',
      '${settings.bitrate}',
      '-pix_fmt',
      'yuv420p',
      if (audioLabel != null) ...['-c:a', settings.audioCodec, '-b:a', '192k'],
      '-movflags',
      '+faststart',
      temporaryOutput,
    ]);

    onProgress?.call(
      const ExportProgress(fraction: 0.05, message: 'Preparando renderização…'),
    );
    try {
      if (Platform.isAndroid || Platform.isIOS) {
        await _runAndroid(args, onProgress, effectiveDurationMs);
      } else {
        await _runDesktop(args, onProgress, effectiveDurationMs);
      }
      if (_cancelRequested) throw StateError('Exportação cancelada.');
      if (!await validateOutput(
        temporaryOutput,
        expectedWidth: settings.width,
        expectedHeight: settings.height,
        expectedDurationMs: effectiveDurationMs,
      )) {
        throw StateError('FFprobe não validou o arquivo exportado.');
      }
      final finalFile = File(finalOutput);
      final tempFile = File(temporaryOutput);
      if (finalFile.existsSync()) await finalFile.delete();
      await tempFile.rename(finalFile.path);
    } catch (_) {
      final partial = File(temporaryOutput);
      if (partial.existsSync()) await partial.delete();
      rethrow;
    } finally {
      await threeDRenderer.dispose();
      if (threeDWorkRoot != null && threeDWorkRoot!.existsSync()) {
        await threeDWorkRoot!.delete(recursive: true);
      }
    }
    onProgress?.call(
      const ExportProgress(fraction: 1, message: 'Exportação concluída.'),
    );
  }

  Future<void> _runAndroid(
    List<String> args,
    void Function(ExportProgress progress)? onProgress,
    int durationMs,
  ) async {
    final command = args.map(_quoteIfNeeded).join(' ');
    final result = Completer<ReturnCode?>();
    _androidSession = await FFmpegKit.executeAsync(
      command,
      (completed) async {
        final code = await completed.getReturnCode();
        if (!result.isCompleted) result.complete(code);
      },
      (log) {
        final message = log.getMessage().trim();
        onProgress?.call(_progressFromFfmpegLog(message, durationMs));
      },
    );
    final code = await result.future;
    _androidSession = null;
    if (!ReturnCode.isSuccess(code))
      throw StateError(
        'FFmpeg encerrou com código ${code?.getValue() ?? 'desconhecido'}.',
      );
  }

  Future<void> _runDesktop(
    List<String> args,
    void Function(ExportProgress progress)? onProgress,
    int durationMs,
  ) async {
    // Keep the spawned process in a local non-null reference for desktop export.
    final process = await Process.start('ffmpeg', args.sublist(1));
    _desktopProcess = process;
    process.stderr.transform(const SystemEncoding().decoder).listen((
      line,
    ) {
      if (line.trim().isNotEmpty) {
        final message = line.trim();
        onProgress?.call(_progressFromFfmpegLog(message, durationMs));
      }
    });
    final exitCode = await process.exitCode;
    _desktopProcess = null;
    if (exitCode != 0)
      throw StateError('FFmpeg encerrou com código $exitCode.');
  }


  ExportProgress _progressFromFfmpegLog(String message, int durationMs) {
    final match = RegExp(r'time=(\d+):(\d+):(\d+(?:\.\d+)?)').firstMatch(message);
    if (match == null || durationMs <= 0) {
      return ExportProgress(fraction: .05, message: message);
    }
    final seconds = int.parse(match.group(1)!) * 3600 +
        int.parse(match.group(2)!) * 60 +
        double.parse(match.group(3)!);
    final mediaMs = seconds * 1000;
    final fraction = (.05 + .90 * (mediaMs / durationMs)).clamp(.05, .95).toDouble();
    return ExportProgress(fraction: fraction, message: message);
  }

  Future<bool> validateOutput(
    String outputPath, {
    int? expectedWidth,
    int? expectedHeight,
    int? expectedDurationMs,
  }) async {
    final file = File(outputPath);
    if (!file.existsSync() || await file.length() == 0) return false;
    try {
      Map<String, dynamic> data;
      if (Platform.isAndroid || Platform.isIOS) {
        final session = await FFprobeKit.execute(
          '-v error -show_entries format=duration:stream=codec_type,codec_name,width,height,r_frame_rate -of json ${_quoteIfNeeded(outputPath)}',
        );
        final code = await session.getReturnCode();
        final output = await session.getOutput();
        if (!ReturnCode.isSuccess(code) || output == null) return false;
        data = (jsonDecode(output) as Map).cast<String, dynamic>();
      } else {
        final result = await Process.run('ffprobe', [
          '-v', 'error',
          '-show_entries',
          'format=duration:stream=codec_type,codec_name,width,height,r_frame_rate',
          '-of', 'json',
          outputPath,
        ]);
        if (result.exitCode != 0) return false;
        data = (jsonDecode(result.stdout as String) as Map).cast<String, dynamic>();
      }
      final streams = (data['streams'] as List? ?? []).cast<Map>();
      final video = streams.firstWhere(
        (stream) => stream['codec_type'] == 'video',
        orElse: () => <String, dynamic>{},
      );
      if (video.isEmpty) return false;
      if (expectedWidth != null && video['width'] != expectedWidth) return false;
      if (expectedHeight != null && video['height'] != expectedHeight) return false;
      final duration = double.tryParse('${(data['format'] as Map?)?['duration'] ?? 0}') ?? 0;
      if (duration <= 0) return false;
      if (expectedDurationMs != null && expectedDurationMs > 0) {
        final expected = expectedDurationMs / 1000;
        if ((duration - expected).abs() > .20) return false;
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  String _filterId(String value) => value.replaceAll(RegExp(r'[^A-Za-z0-9_]'), '_');

  MediaAsset? _asset(Project project, String id) => project.assets
      .cast<MediaAsset?>()
      .firstWhere((asset) => asset?.id == id, orElse: () => null);

  String _effectFilter(EffectConfig effect) {
    final p = effect.parameters;
    switch (effect.type) {
      case 'brightness':
        return 'eq=brightness=${p['value'] ?? 0}';
      case 'exposure':
        return 'eq=gamma=${p['value'] ?? 1}';
      case 'contrast':
        return 'eq=contrast=${p['value'] ?? 1}';
      case 'highlights':
        return 'eq=gamma=${p['value'] ?? 1}';
      case 'shadows':
        return 'eq=gamma=${p['value'] ?? 1}';
      case 'saturation':
        return 'eq=saturation=${p['value'] ?? 1}';
      case 'temperature':
        return 'colorbalance=rs=${p['value'] ?? 0}:bs=-${p['value'] ?? 0}';
      case 'tint':
        return 'hue=h=${p['value'] ?? 0}';
      case 'blur':
        return 'boxblur=${p['radius'] ?? 2}';
      case 'sharpen':
        return 'unsharp=5:5:${p['amount'] ?? 1}:5:5:0';
      case 'grayscale':
        return 'hue=s=0';
      case 'vignette':
        return 'vignette';
      case 'grain':
      case 'noise':
        return 'noise=alls=${p['amount'] ?? 12}:allf=t+u';
      case 'pixelate':
        return 'scale=iw/20:ih/20:flags=neighbor,scale=iw*20:ih*20:flags=neighbor';
      case 'rgb_split':
      case 'glitch':
        return 'rgbashift=rh=${p['amount'] ?? 3}:bv=${p['amount'] ?? 2}';
      case 'distortion':
        return 'lenscorrection=k1=${p['amount'] ?? 0.1}:k2=0';
      case 'chroma_key':
        return 'colorkey=${p['color'] ?? '0x00ff00'}:${p['similarity'] ?? 0.3}:${p['blend'] ?? 0.1}';
      default:
        throw ArgumentError(
          'Efeito não suportado pelo exportador: ${effect.type}',
        );
    }
  }

  List<String> _atempoFilters(double speed) {
    var remaining = speed;
    final filters = <String>[];
    while (remaining > 2) {
      filters.add('atempo=2');
      remaining /= 2;
    }
    while (remaining < 0.5) {
      filters.add('atempo=0.5');
      remaining /= 0.5;
    }
    if ((remaining - 1).abs() > 0.0001) {
      filters.add('atempo=${remaining.toStringAsFixed(6)}');
    }
    return filters;
  }

  String _escapeFilterText(String value) => value
      .replaceAll('\\', '\\\\')
      .replaceAll(':', '\\\\:')
      .replaceAll(',', '\\\\,')
      .replaceAll("'", "\\\\'");

  /// Builds a time-varying FFmpeg expression from the same local-time
  /// keyframes evaluated by CompositionEngine. Values are evaluated in the
  /// clip's local timeline, so playback speed is applied consistently.
  String _keyframeExpression(
    List<Keyframe> keyframes,
    double fallback, {
    required double speed,
    required int timelineStartMs,
  }) {
    if (keyframes.isEmpty) return fallback.toStringAsFixed(4);
    final ordered = [...keyframes]
      ..sort((a, b) => a.timeMs.compareTo(b.timeMs));
    var expression = ordered.last.value.toStringAsFixed(4);
    for (var i = ordered.length - 2; i >= 0; i--) {
      final left = ordered[i];
      final right = ordered[i + 1];
      final duration = (right.timeMs - left.timeMs).clamp(1, 1 << 30);
      final position = '((t-${(timelineStartMs / 1000).toStringAsFixed(6)})*${speed.toStringAsFixed(6)}*1000-${left.timeMs})/${duration}';
      final normalized = 'clip(0\\,1\\,$position)';
      final progress = switch (left.interpolation) {
        Interpolation.hold => '0',
        Interpolation.linear => normalized,
        Interpolation.easeIn => '($normalized*$normalized)',
        Interpolation.easeOut => '(1-(1-$normalized)*(1-$normalized))',
        Interpolation.easeInOut =>
          'if(lt($normalized,0.5),2*$normalized*$normalized,1-(-2*$normalized+2)*(-2*$normalized+2)/2)',
      };
      final value =
          '(${left.value.toStringAsFixed(4)}+(${right.value.toStringAsFixed(4)}-${left.value.toStringAsFixed(4)})*$progress)';
      expression =
          'if(lt((t-${(timelineStartMs / 1000).toStringAsFixed(6)})*${speed.toStringAsFixed(6)}*1000,${right.timeMs})\\,$value\\,$expression)';
    }
    return expression;
  }

  String _quoteIfNeeded(String value) => value.contains(RegExp(r'[\s\[\];=]'))
      ? '"${value.replaceAll('"', '\\"')}"'
      : value;
}
