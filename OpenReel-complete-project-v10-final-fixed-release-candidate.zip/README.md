# OpenReel

OpenReel é um editor de vídeo local-first escrito em Flutter e Dart, com integração FFmpeg para análise, cache e exportação. O projeto foi organizado para Android, Linux e Windows, sem upload automático de mídia. Os projetos são arquivos JSON armazenados no diretório de documentos do usuário.

> Esta entrega prioriza um núcleo executável e extensível. Recursos que dependem de um backend nativo específico, modelos grandes ou plugins de plataforma não são apresentados como prontos: as limitações estão registradas em [`docs/FEATURE_STATUS.md`](docs/FEATURE_STATUS.md).

## Recursos implementados

| Área | Implementação funcional |
| --- | --- |
| Mídia | Importação múltipla; leitura de duração, resolução, FPS, codec, bitrate, áudio, canais e sample rate com FFprobe; thumbnail e waveform em cache. |
| Timeline | Múltiplas trilhas de vídeo, áudio e overlay; seleção; arraste; snapping de 100 ms; bloqueio; ocultação; zoom; playhead; divisão; trim; exclusão com ripple; duplicação. |
| Preview e composição | `CompositionEngine` gera as camadas ativas por timestamp; o preview usa base e overlays de imagem/texto, sincroniza velocidade/keyframes e preserva opacity/transform/blend no frame. A reprodução multicamada de vídeo e backend desktop continuam parciais. |
| Edição | Velocidade com duração de timeline ajustada, opacidade, escala, rotação, trim, split, copiar/colar, marcadores, X/Y e ScaleX/ScaleY em keyframes; efeitos FFmpeg reais incluindo correção, blur, grain, pixelate, RGB split, distortion e chroma key. |
| Texto e keyframes | Títulos independentes na timeline; keyframes de posição, escala, rotação, opacidade e volume preservados no JSON do projeto. |
| Projetos | Novo, salvar, salvar como, abrir por repositório, autosave periódico, backup atômico e undo/redo com histórico limitado. |
| Exportação | FFmpeg no Android/iOS pelo pacote open source `ffmpeg_kit_flutter_new`; executável `ffmpeg` no desktop; concatenação, trim, escala, FPS, codec, CRF, mixagem básica de áudio, cancelamento e validação pós-exportação. |
| Qualidade | 12 testes automatizados de domínio, composição, legendas, widget, velocidade e stress de 1000 clips; auditoria final e workflows de análise/testes/APK debug. |

## Requisitos

Para desenvolvimento, use Flutter estável, Dart compatível com o `pubspec.yaml`, Android SDK para o APK e `ffmpeg`/`ffprobe` no `PATH` para execução desktop. No Android, o pacote FFmpegKit fornece a engine empacotada. O aplicativo não requer uma API paga.

## Execução

```bash
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter run
```

Para Linux, instale as dependências padrão do Flutter Linux Desktop. Para Windows, instale Visual Studio com a carga de trabalho Desktop development with C++. Para Android, habilite USB debugging ou use um emulador.

## APK

```bash
flutter build apk --debug
flutter build apk --release
```

O workflow [`android.yml`](.github/workflows/android.yml) executa análise, testes e gera o APK debug como artefato. O release assinado requer um keystore configurado como segredo do repositório; por segurança, nenhum segredo é incluído no código.

## Estrutura

```text
lib/
  models/       JSON de projeto, mídias, timeline, composição, efeitos e keyframes
  services/     CompositionEngine, FFprobe/FFmpeg, cache, legendas, projetos e exportação
  state/        controlador, histórico, autosave e operações de edição
  ui/           shell responsivo, biblioteca, preview, inspector e timeline
android/        integração Android gerada pelo Flutter
linux/          runner Linux
windows/        runner Windows
media/         ponto de extensão para assets e cache
engine/        documentação e pontos de extensão da engine
native/         espaço para integrações nativas
ai/             espaço para módulos locais de IA
plugins/        contratos futuros de plugins seguros
test/           testes unitários e widget
docs/           arquitetura, build e status de recursos
```

## Segurança e privacidade

O OpenReel não envia mídia para servidores e não executa plugins externos. Caminhos são recebidos pelo seletor do sistema e os projetos são gravados por troca atômica de arquivo. O pacote de exportação não aceita comandos arbitrários do usuário; os argumentos são montados a partir de propriedades tipadas do projeto.

## Licenças

O código original deste repositório é MIT. As dependências mantêm as respectivas licenças. FFmpeg e FFmpegKit têm licenças e condições próprias; consulte [`docs/FFMPEG.md`](docs/FFMPEG.md) antes de redistribuir binários.

## Referências

[1]: https://flutter.dev/ "Flutter"
[2]: https://ffmpeg.org/ "FFmpeg"
[3]: https://pub.dev/packages/ffmpeg_kit_flutter_new "FFmpeg Kit Flutter New"
[4]: https://pub.dev/packages/video_player "video_player"
