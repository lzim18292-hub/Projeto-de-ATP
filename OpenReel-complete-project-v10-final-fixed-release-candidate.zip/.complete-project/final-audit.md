# OpenReel — Final Audit V4 / Release Gate

Data: 2026-09-07

## Regra de fechamento
A auditoria V4 foi executada sobre o V3 sem reescrever o projeto. A classificação abaixo diferencia implementação real, teste real e limitações não solucionáveis no stack disponível.

| Recurso | Status | Preview | Export | Teste/Evidência | Limitação |
|---|---|---|---|---|---|
| Núcleo/editor | COMPLETE | sim | sim | static + FFmpeg fixture | Flutter não disponível localmente |
| Timeline | COMPLETE | sim | sim | invariant/static | build Flutter pendente |
| CompositionEngine | COMPLETE | fonte única de semântica | grafo derivado da mesma timeline | composition tests presentes | backend FFmpeg é diferente do compositor de widgets |
| Short Auto JSON/XML | COMPLETE | sim | sim para mídia suportada | parser tests presentes | automações de IA são declarativas |
| Texto/SRT/VTT | COMPLETE/PARTIAL | sim | sim | parser/fixture | tipografia avançada limitada |
| Áudio/mixer | PARTIAL | sim para fontes suportadas | sim | FFmpeg fixture | pan/ganho acima de 1 e mixer profissional não têm paridade total no player |
| Blend | PARTIAL | normal real; backdrop modes ainda não equivalentes no widget preview | normal/screen/add/multiply/overlay no grafo FFmpeg | FFmpeg filter smoke test | preview Flutter não expõe blend de backdrop com a mesma semântica |
| Chroma key | PARTIAL | não | real no FFmpeg quando configurado como efeito | filter smoke test | preview não aplica a mesma operação de pixels |
| Máscaras | UNSUPPORTED | não | não | ausência confirmada | paths/feather arbitrários sem backend comum |
| Transições | COMPLETE no escopo | sim | fade real | model/fixture | catálogo avançado ausente |
| 3D preview | COMPLETE no escopo | renderer GLB/GLTF real | — | model validation/static | câmera/lighting/material completos ainda não expostos |
| 3D export | PARTIAL | sim | sim em Android/iOS/macOS/Windows via WebGL WebView + PNG frames + FFmpeg | static wiring; Flutter runtime ainda não executado | Linux sem backend WebView; câmera/lighting/material avançados ainda não têm paridade completa |
| 3D keyframes | PARTIAL | dados avaliados e aplicados por frame ao renderer | sim para transformações suportadas pelo renderer | composition/static | câmera/lighting/material avançados ainda não têm modelo próprio |
| SAF/reabertura | COMPLETE no fluxo de importação | — | arquivos importados são copiados para storage do app | persistência de mídia/modelos | não há permissão URI persistente para edição diretamente no provider original; a cópia durável evita dependência dessa permissão |
| Proxy/cache | COMPLETE no mecanismo | usa proxy quando disponível | original | static/code review | geração só para arquivos acima do limiar |
| Cancelamento/recuperação | COMPLETE no escopo | — | temporário removido | code/invariant | validação em dispositivo ainda depende de CI |
| Exportação 2D | COMPLETE no escopo | sim | sim | FFmpeg/FFprobe fixture | algumas propriedades permanecem rejeitadas para evitar resultado falso |
| Android APK | BLOCKED/NOT TESTED local | — | — | workflow configurado | Flutter/Dart não instalados no ambiente |
| Testes Flutter | NOT TESTED | — | — | arquivos presentes | precisa CI/ambiente Flutter |
| FFmpeg/FFprobe | TESTED | — | sim | fixture real 640x360 H264/AAC 2s | não substitui testes Flutter |

## Correções V4
1. Importações de mídia passam a ser copiadas para armazenamento persistente do aplicativo. O projeto deixa de depender exclusivamente do caminho externo selecionado.
2. `MediaAsset.sourcePath` preserva o caminho original quando disponível.
3. Modelos GLB são copiados para armazenamento persistente; GLTF copia também recursos locais referenciados por `uri` (.bin/texturas).
4. `CompositionEngine` usa proxy somente quando o arquivo ainda existe e possui fallback para o arquivo persistido/original.
5. Exportação passou a ser atômica: FFmpeg grava em `.openreel-part.mp4`, FFprobe valida o temporário e só então ele é promovido ao caminho final.
6. FFprobe agora valida existência de stream de vídeo, resolução e duração esperada, além do sucesso do parser.
7. Preview de volume usa o mesmo teto efetivo de ganho do player (`0..1`) usado no export, evitando prometer ganho que `video_player` não reproduz.
8. Recursos sem paridade foram mantidos como rejeição explícita/limitação documentada, sem placeholders.

## Testes realmente executados nesta máquina
- `.complete-project/stage3_audit.py` — PASS.
- `.complete-project/check_invariants.py` — PASS.
- `.complete-project/ffmpeg-fixture-test.py` — PASS.
- `.complete-project/release_audit_v4.py` — PASS.
- FFmpeg/FFprobe 7.1.5: fixture multimídia real, H.264 + AAC, 640×360, 30 FPS, 2.000 s.
- Flutter/Dart: NÃO EXECUTADOS; binários ausentes.

## Release gate
Não declarar 100% nem COMPLETE globalmente enquanto:
- 3D offscreen/export não tiver sido validado em runtime Android/desktop;
- Flutter analyze/test/build não tiverem passado em CI;
- recursos de preview/export sem paridade não forem fechados ou explicitamente mantidos como unsupported.

## Veredito
STATUS: PARTIAL / RELEASE CANDIDATE. A pipeline 3D offscreen foi implementada, mas ainda depende de validação Flutter/CI em runtime.

O código foi fechado incrementalmente onde havia solução viável neste ambiente. As limitações restantes são técnicas e verificáveis, não placeholders.
