# OpenReel — Progress V4 / Release Gate

Data: 2026-09-07

## V4 fechado
- armazenamento durável de mídia importada;
- fallback de caminho no CompositionEngine;
- armazenamento durável de GLB/GLTF e recursos locais de GLTF;
- exportação atômica com arquivo temporário;
- validação FFprobe de vídeo, resolução e duração;
- teto de ganho de preview/export alinhado ao player;
- auditoria estática V4.

## Ainda dependente de validação/runtime
- validação runtime da rasterização 3D offscreen no APK/desktop;
- paridade completa de câmera/lighting/material/keyframes 3D;
- máscaras arbitrárias;
- chroma key pixel-a-pixel no preview;
- blend backdrop completo no preview;
- mixer profissional;
- acesso direto por URI persistente do SAF (o fluxo atual usa cópia durável para storage do app);
- IA real de auto-cuts/remove-silence/reframe/auto-subtitles sem provider;
- execução local de Flutter/Dart.

## Regra de release
O projeto NÃO é marcado como 100%. O workflow Android continua sendo a porta de validação para `flutter pub get`, `dart format`, `flutter analyze`, `flutter test` e `flutter build apk --release`.
