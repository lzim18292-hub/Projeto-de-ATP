# OpenReel 3D

## Formatos

O projeto aceita GLB e GLTF. A biblioteca valida cabeçalho GLB/versão 2 e asset/version 2 de GLTF antes de registrar o modelo.

O preview usa `flutter_3d_controller` para carregar arquivos locais e URLs quando suportados pelo renderer. O pacote oferece visualização GLB/GLTF e controle de interação. A dependência foi adicionada sem substituir a arquitetura 2D existente.

## Modelo

`Model3DAsset` guarda:
- caminho;
- nome;
- formato;
- tamanho;
- número de nós/animações quando disponível;
- origem;
- autor;
- licença;
- URL/origem.

`TimelineClip` possui `object3dAssetId`, `Transform3D` e listas de keyframes 3D.

## Timeline/Composition

Objetos 3D usam `TrackKind.object3d` e aparecem como `CompositionLayer` com `object3dAssetId`, `sourcePath` e `transform3D`. Portanto o Short Auto Engine cria uma camada normal da timeline; ele não cria um compositor separado.

## Preview

GLB/GLTF são carregados como camada visual real. Posição 2D, escala 2D, rotação Z e opacity podem ser aplicadas pelo compositor Flutter. O renderer 3D externo fornece a cena/modelo.

## Export

A exportação usa um renderer WebGL offscreen baseado em `HeadlessInAppWebView` + `model-viewer`. Cada camada 3D vira uma sequência PNG transparente na resolução do projeto; o grafo FFmpeg recompõe essas imagens com as demais camadas. Em plataformas sem backend WebView/WebGL suportado, a exportação falha explicitamente em vez de ignorar o objeto.

A pipeline é `PARTIAL` até haver validação runtime no APK/desktop e paridade completa de câmera/lighting/materials.

## Limitações

- câmera/iluminação/material PBR ainda não são representados integralmente no `CompositionFrame`;
- keyframes X/Y/Z e rotação 3D são avaliados por frame e enviados ao renderer; posição/profundidade são aproximadas pelo compositor 2D/WebView;
- validação runtime do renderer offscreen ainda depende de Flutter/WebView no CI ou dispositivo real;
- não há download automático de modelos;
- licença/autor são somente os metadados fornecidos pelo usuário/fonte.

## Dependência de preview

O renderer selecionado é `flutter_3d_controller` 2.3.0, que documenta suporte a GLB/GLTF em Android/iOS/Web e macOS beta. A validação oficial depende de `flutter pub get` e do build Flutter.
