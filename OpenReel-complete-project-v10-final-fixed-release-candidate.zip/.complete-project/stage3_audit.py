from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
checks = {
    "short auto service": (ROOT / "lib/services/short_auto_engine.dart").exists(),
    "3D model service": (ROOT / "lib/models/model3d.dart").exists(),
    "3D library UI": (ROOT / "lib/ui/model3d_library.dart").exists(),
    "template service": (ROOT / "lib/services/template_service.dart").exists(),
    "3D offscreen renderer": (ROOT / "lib/services/three_d_offscreen_renderer.dart").exists(),
    "3D export pipeline": "threeDFrameDirs" in (ROOT / "lib/services/export_service.dart").read_text(),
    "JSON schema": "shortAutoSchemaVersion = '1.0'" in (ROOT / "lib/services/short_auto_engine.dart").read_text(),
    "3D track": "object3d" in (ROOT / "lib/models/timeline.dart").read_text(),
    "3D composition": "object3dAssetId" in (ROOT / "lib/models/composition.dart").read_text(),
    "3D dependency": "flutter_3d_controller: ^2.3.0" in (ROOT / "pubspec.yaml").read_text(),
    "workflow release": "flutter build apk --release" in (ROOT / ".github/workflows/android.yml").read_text(),
}
failed = [name for name, ok in checks.items() if not ok]
lib_text = "\n".join(p.read_text(errors="ignore") for p in (ROOT/"lib").rglob("*.dart"))
forbidden = []
for word in ("TODO", "FIXME"):
    if re.search(rf"\b{word}\b", lib_text):
        forbidden.append(word)
if forbidden:
    failed.append("no TODO/FIXME in application code")
for name, ok in checks.items():
    print(("OK   " if ok else "FAIL "), name)
if failed:
    raise SystemExit("FAILED: " + ", ".join(failed))
print("ALL STAGE3 STATIC CHECKS PASSED")
