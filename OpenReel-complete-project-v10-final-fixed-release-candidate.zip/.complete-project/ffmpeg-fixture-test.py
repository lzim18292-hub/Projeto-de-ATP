#!/usr/bin/env python3
"""OpenReel FFmpeg fixture validation.

Backend smoke test for the real FFmpeg primitives used by ExportService.
It does not replace Flutter tests.
"""
from pathlib import Path
import json, shutil, subprocess, tempfile

ffmpeg = shutil.which("ffmpeg")
ffprobe = shutil.which("ffprobe")
if not ffmpeg or not ffprobe:
    raise SystemExit("ffmpeg/ffprobe not available")

with tempfile.TemporaryDirectory(prefix="openreel-fixture-") as d:
    d = Path(d)
    a, b, audio, out = d/"a.mp4", d/"b.mp4", d/"tone.m4a", d/"result.mp4"

    def run(args):
        subprocess.run(args, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    run([ffmpeg, "-y", "-f", "lavfi", "-i", "testsrc=size=320x180:rate=30",
         "-t", "2", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(a)])
    run([ffmpeg, "-y", "-f", "lavfi", "-i", "smptebars=size=320x180:rate=30",
         "-t", "2", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(b)])
    run([ffmpeg, "-y", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100",
         "-t", "2", "-c:a", "aac", str(audio)])

    graph = (
        "[0:v]trim=duration=2,setpts=PTS-STARTPTS,scale=640:360:"
        "force_original_aspect_ratio=decrease,fps=30,format=rgba,"
        "pad=640:360:(ow-iw)/2:(oh-ih)/2:color=black@0.0[v0];"
        "[1:v]trim=duration=2,setpts=PTS-STARTPTS,scale=320:180,"
        "format=rgba,pad=640:360:(ow-iw)/2:(oh-ih)/2:color=black@0.0[v1];"
        "color=c=black:s=640x360:r=30:d=2,format=rgba[base];"
        "[base][v0]overlay=0:0:format=auto[c0];"
        "[c0][v1]overlay=160:90:format=auto[c1];"
        "[c1]drawtext=text='OpenReel':x=20:y=20:fontsize=48:"
        "fontcolor=white:borderw=2:bordercolor=black[c2];"
        "[c2]drawtext=text='Legenda\\nsegunda linha':"
        "enable=between\\(t\\,0.5\\,1.5\\):x=(w-text_w)/2:y=(h-text_h)*0.9:"
        "fontsize=32:fontcolor=yellow:borderw=2:bordercolor=black[vout];"
        "[2:a]atrim=duration=2,asetpts=PTS-STARTPTS,adelay=0|0[aout]"
    )
    run([ffmpeg, "-y", "-i", str(a), "-i", str(b), "-i", str(audio),
         "-filter_complex", graph, "-map", "[vout]", "-map", "[aout]",
         "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(out)])

    probe = subprocess.run(
        [ffprobe, "-v", "error", "-show_entries",
         "format=duration:stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate",
         "-of", "json", str(out)],
        check=True, capture_output=True, text=True,
    )
    data = json.loads(probe.stdout)
    assert any(s.get("codec_name") == "h264" and s.get("width") == 640 and s.get("height") == 360 for s in data["streams"])
    assert any(s.get("codec_name") == "aac" for s in data["streams"])
    assert abs(float(data["format"]["duration"]) - 2.0) < 0.05
    print("PASS: FFmpeg/FFprobe multimídia fixture")
    print(json.dumps(data, indent=2))
