# OpenReel — Requirements Checklist (Final Closure)

Data da auditoria final: 2026-09-07.

Legenda: `[x]` implementação real com verificação disponível; `[~]` parcial; `[B]` bloqueado pelo ambiente; `[U]` não suportado pelo stack atual.

## Processo
- [x] Auditoria integral antes e segunda auditoria após as alterações.
- [x] Arquitetura existente preservada; sem reescrita total.
- [x] Documentação sincronizada com evidências.

## Produto/projetos
- [x] 16:9, 9:16, 1:1 e resolução personalizada.
- [x] FPS persistido e editável.
- [x] Home dedicada: criar, abrir, recentes, renomear, duplicar, excluir.
- [x] Recuperação de autosave disponível na Home.
- [x] JSON, autosave e troca segura com backup.

## Timeline
- [x] seleção, movimento, snapping, split, trim esquerdo/direito, ripple delete, copiar/colar, duplicar, zoom, scroll, playhead, markers, lock/visibility.
- [x] seleção múltipla por long-press.
- [x] pinch-to-zoom.
- [x] handles de trim touch-friendly.
- [~] ripple/edição simultânea de múltiplos clips ainda não é uma operação em lote.

## Composição / Preview
- [x] CompositionEngine é a fonte lógica de frames.
- [x] Preview consome `CompositionFrame`.
- [x] múltiplos vídeos simultâneos, imagens, textos e legendas no mesmo Stack.
- [x] posição, escala, rotação, opacity, Z-order e keyframes no preview.
- [x] efeitos básicos com equivalente Flutter: grayscale, brightness, contrast, saturation, blur.
- [~] áudio externo não possui mixer de reprodução dedicado no preview; áudio embutido de cada vídeo ativo é reproduzido pelo respectivo controller.
- [~] blend modes não têm equivalente de backdrop para texturas de vídeo no compositor Flutter atual; não são falsificados no preview.
- [~] chroma/máscaras avançadas permanecem export/backend-first.

## Keyframes/tempo
- [x] X/Y/scaleX/scaleY/rotation/opacity/volume no modelo e CompositionEngine.
- [x] hold, linear, ease in, ease out, ease in-out.
- [x] export usa a mesma semântica de tempo local e velocidade; expressões FFmpeg corrigidas para usar `t - startMs`.
- [x] trim + speed preserva sourceStartMs e duração de timeline.
- [x] proteção contra duração não positiva no modelo de trim.

## Texto/legendas
- [x] texto persistente com estilo básico, transform, opacity e quebra de linha.
- [x] SRT/VTT parseados e persistidos em `Project.subtitleCues`.
- [x] cues materializados na track de subtitle e na CompositionFrame.
- [x] preview e export usam o mesmo conteúdo/tempo de legenda.
- [~] fontes arbitrárias, espaçamento tipográfico e rotação/escala avançadas do texto ainda não têm paridade completa com FFmpeg.

## Transições
- [x] fade de entrada/saída no modelo, preview e export.
- [x] clips sobrepostos podem produzir crossfade temporal por fade de alpha.
- [x] controle no inspector e persistência.
- [~] catálogo de transições avançadas não existe.

## Blend/máscaras/chroma
- [x] normal, screen, multiply, overlay e add existem no modelo.
- [x] export aplica normal/screen/add/multiply/overlay via `blend`;
- [~] preview de backdrop blend para vídeo ainda limitado pelo compositor Flutter.
- [x] chroma key existe como efeito FFmpeg real.
- [~] preview de chroma e máscaras arbitrárias.
- [U] máscaras com feather/paths arbitrários não têm implementação no stack atual.

## Áudio
- [x] múltiplas fontes, áudio embutido/externo, volume, mute, fades, pan e speed via atempo no export.
- [x] keyframes de volume no domínio/export.
- [~] mixer avançado, solo, EQ, limiter e ducking.

## Export
- [x] grafo FFmpeg real; vídeos/imagens/texto/legendas/áudio/múltiplas camadas.
- [x] PTS/speed/trim.
- [x] resolução customizada e FPS.
- [x] cancelamento e limpeza de saída parcial.
- [x] FFprobe pós-export.
- [~] progresso percentual preciso; callback ainda é baseado em eventos/logs.
- [B] build Android real neste ambiente.

## Android/SAF/performance
- [~] file_picker + caminhos fornecidos pelo sistema funcionam quando o plugin expõe caminho acessível; não há camada persistente de URI permission/content resolver nativa.
- [x] thumbnails/waveforms em cache temporário.
- [x] proxy real para mídia acima do limiar, com cache/index e invalidação por mtime.
- [~] processamento preview não destrutivo, mas sem pipeline GPU dedicado.

## Testes/build
- [x] testes unitários de models/composição/legendas e novos cenários de fechamento.
- [x] validação real de grafo FFmpeg/FFprobe com mídia de fixture gerada.
- [B] flutter pub get, dart format, flutter analyze, flutter test, flutter build apk --release: executáveis não existem no ambiente.
- [x] GitHub Actions preparado para format/analyze/test/build release.



## Estágio 3 — Short Auto + 3D
- [x] Short Auto Engine com parser JSON/XML versão 1.0.
- [x] Validação de schema, versão, propriedades desconhecidas e caminhos.
- [x] Geração de Project + Timeline, sem renderizador paralelo.
- [x] Interface visual para gerar Short sem escrever XML.
- [x] Templates estruturais reutilizáveis.
- [x] Modelo 3D GLB/GLTF, validação e metadados de licença/origem.
- [x] TrackKind.object3d integrado ao Timeline e CompositionFrame.
- [x] Preview GLB/GLTF real via renderer Flutter.
- [~] Keyframes 3D persistidos; paridade de todas as propriedades 3D ainda parcial.
- [~] Objetos 3D no preview e exportação por rasterização WebGL/WebView em PNG + FFmpeg; validação runtime ainda bloqueada sem Flutter/Android.
- [~] IA de auto-cortes, silêncio, reframe e legendas: somente configuração declarativa.
- [~] SAF/URI persistente nativo; [x] mídia importada é copiada para armazenamento durável do app.
- [x] proxy de mídia acima do limiar; [~] geração não foi executada em Android neste ambiente.
- [~] mixer avançado.
- [B] validação Flutter/Android local, pois Flutter/Dart não estão instalados.
