# Technical Audit — Final Pass

## Composição
`CompositionEngine.compose(project, timeMs)` continua sendo a fonte de verdade para a estrutura lógica do frame. Preview consome `CompositionFrame`; export mantém grafo FFmpeg derivado dos mesmos modelos/semântica de tempo.

## Tempo
`sourceStartMs` representa o relógio da mídia. `startMs`/`durationMs` representam o relógio da timeline. `speed` converte timeline local para source local. Export aplica trim da fonte, normalização de PTS, speed e só então offset de timeline.

## Keyframes
Engine e export respeitam interpolação e tempo local. Expressões FFmpeg usam `t - clip.startMs` antes de multiplicar por speed. Funções de expressão têm vírgulas escapadas no contexto do filter graph.

## Preview
Há um `VideoPlayerController` por vídeo ativo do frame. Controllers são criados/removidos conforme a composição muda e sincronizados ao playhead. Imagens são lidas do asset original. Texto e legendas usam os dados do frame.

## Export
Vídeos/imagens são ordenados por track para preservar Z-order. Blend não-normal usa filtro `blend`. Fade usa filtro `fade`. Texto/legendas usam drawtext. Áudio usa trim, PTS, volume, atempo, fade, pan e amix.

## Persistência
Project schemaVersion 3 inclui subtitleCues, TextStyleConfig e TransitionConfig, com defaults retrocompatíveis quando os campos estão ausentes.

## Android
O projeto permanece baseado em file_picker e FFmpegKit. URI permission persistente/ContentResolver nativo não foi implementado; portanto SAF completo continua PARTIAL.

## Validação
FFmpeg/FFprobe reais foram executados. Flutter/Dart não estão instalados neste ambiente e os comandos oficiais ficaram BLOCKED.
