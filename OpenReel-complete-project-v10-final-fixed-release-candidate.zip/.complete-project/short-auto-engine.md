# Short Auto Engine — schema 1.0

O Short Auto Engine não renderiza MP4. Ele transforma JSON/XML em `Project` + `Timeline` e entrega o mesmo modelo ao `CompositionEngine`.

## JSON mínimo

```json
{
  "schemaVersion": "1.0",
  "name": "Meu Short",
  "width": 1080,
  "height": 1920,
  "fps": 30,
  "durationMs": 30000,
  "media": {
    "videos": ["/media/main.mp4"],
    "images": ["/media/broll.png"],
    "audio": ["/media/music.mp3"],
    "subtitles": ["/media/captions.srt"],
    "object3d": ["/media/lua.glb"]
  },
  "texts": ["Título"],
  "automation": {
    "autoCuts": true,
    "removeSilence": true,
    "autoReframe": true,
    "autoZoom": false,
    "autoSubtitles": true
  }
}
```

As opções de automação são declarativas. O OpenReel não afirma possuir IA para corte, silêncio, reframe ou geração automática de legendas sem um provider real.

## XML

A raiz é `<short>` ou `<project>`. Tags iniciais aceitas: `schemaVersion`, `name`, `width`, `height`, `fps`, `durationMs`, `orientation`, `video`, `image`, `audio`, `music`, `voice`, `subtitle`, `srt`, `vtt`, `text`, `object3d/model`, `autoCuts`, `removeSilence`, `autoReframe`, `autoZoom`, `autoSubtitles`.

## Validação

A versão deve ser `1.0`. JSON inválido, XML inválido, propriedades desconhecidas, caminhos inexistentes e formatos não suportados geram erro explícito. GLB/GLTF são validados antes de entrarem no projeto.

## Templates

`TemplateService` fornece presets estruturais reutilizáveis. Aplicação não altera o projeto-template original; assets e clips são clonados para o projeto de destino.

## Arquitetura

`JSON/XML → parser/validation → ShortAutoEngine → Project/Timeline → CompositionEngine → CompositionFrame → Preview/Export`.

Não existe um renderizador paralelo de Shorts.
