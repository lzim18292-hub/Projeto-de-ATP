from pathlib import Path

root = Path(__file__).parent.parent
export = (root / 'lib/services/export_service.dart').read_text()
engine = (root / 'lib/services/composition_engine.dart').read_text()
model = (root / 'lib/models/timeline.dart').read_text()
required = {
    'export filters hidden tracks': '.where((track) => !track.hidden)' in export,
    'export filters disabled clips': '.where((clip) => clip.enabled)' in export,
    'export text chain has no stale label': '[vconcat]' not in export,
    'export keyframe expressions': '_keyframeExpression' in export,
    'audio speed correction': '_atempoFilters' in export,
    'engine skips disabled clips': 'if (!clip.enabled || track.kind == TrackKind.subtitle) continue;' in engine,
    'clip enabled persisted': "'enabled': enabled" in model,
    'subtitle model persisted': "'subtitleCues':" in (root / 'lib/models/project.dart').read_text(),
    'transitions persisted': "'transitionIn':" in model and "'transitionOut':" in model,
}
for label, ok in required.items():
    print(('OK ' if ok else 'FAIL ') + label)
if not all(required.values()):
    raise SystemExit(1)
