from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
checks = {
    "durable media storage": "Future<MediaAsset> persist" in (ROOT/"lib/services/media_service.dart").read_text(),
    "durable 3D storage": "Future<String> persistFile" in (ROOT/"lib/models/model3d.dart").read_text(),
    "atomic export temp": "openreel-part.mp4" in (ROOT/"lib/services/export_service.dart").read_text(),
    "ffprobe stream validation": "expectedWidth" in (ROOT/"lib/services/export_service.dart").read_text(),
    "3D offscreen renderer wired": (ROOT/"lib/services/three_d_offscreen_renderer.dart").exists() and "threeDFrameDirs" in (ROOT/"lib/services/export_service.dart").read_text(),
    "CI release build": "flutter build apk --release" in (ROOT/".github/workflows/android.yml").read_text(),
}
for name, ok in checks.items():
    print(("OK   " if ok else "FAIL "), name)
if not all(checks.values()):
    raise SystemExit("RELEASE STATIC AUDIT FAILED")
print("RELEASE STATIC AUDIT PASSED")
