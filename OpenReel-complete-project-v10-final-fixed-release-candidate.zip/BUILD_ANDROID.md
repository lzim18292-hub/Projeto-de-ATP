# Build Android

## Requisitos

Instale Flutter estável, Android SDK com uma plataforma recente, build-tools, Java compatível e aceite as licenças do SDK. O pacote `ffmpeg_kit_flutter_new` fornece a engine FFmpeg empacotada usada pelo exportador Android.

## Comandos

```bash
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build apk --debug
flutter build apk --release
```

O APK debug é gerado em `build/app/outputs/flutter-apk/app-debug.apk`. A versão release precisa de assinatura configurada pelo consumidor. O workflow `.github/workflows/android.yml` executa análise, testes e build debug.

## Importação e limitações

A seleção passa pelo `file_picker` e aceita o resultado em URI/caminho fornecido pelo sistema. Mídia inexistente ou sem stream compatível gera erro explícito. A integração avançada de MediaStore/SAF para content URIs sem caminho físico ainda depende de uma camada nativa adicional; o código não finge converter uma URI inacessível em arquivo local.
