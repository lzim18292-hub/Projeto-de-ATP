# Contribuindo

## Fluxo

1. Crie uma branch com uma mudança isolada.
2. Adicione ou atualize testes para comportamento novo.
3. Execute `dart format lib test`, `flutter analyze --no-fatal-infos` e `flutter test`.
4. Atualize a documentação quando uma limitação ou dependência mudar.
5. Abra um pull request descrevendo plataforma, reprodução e impacto no formato do projeto.

## Princípios

Não adicione botões sem uma implementação de ponta a ponta. Processamento pesado deve ficar fora da camada visual. Não envie mídia para serviços externos sem consentimento. Não inclua chaves, keystores, binários proprietários ou arquivos de mídia de usuários.

## Compatibilidade

Mudanças no JSON devem incrementar `schemaVersion` e fornecer migração ou uma mensagem de erro clara. Novos formatos e codecs devem ser opcionais quando a plataforma não os suportar.

## Licenças

Contribuições para o código original são aceitas sob MIT. Dependências e binários externos mantêm suas próprias licenças.
