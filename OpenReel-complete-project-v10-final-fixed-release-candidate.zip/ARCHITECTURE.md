# Arquitetura

## Camadas

```text
UI Flutter
  ↓ eventos tipados
EditorController (estado, histórico, autosave)
  ├── Project / Timeline / Keyframes (domínio serializável)
  ├── CompositionEngine → CompositionFrame categorizado por timestamp
  ├── MediaService → FFprobe + cache de thumbnail/waveform
  ├── ExportService → grafo base/overlay FFmpegKit no Android ou processo ffmpeg no desktop
  └── ProjectRepository → JSON atômico no diretório de documentos
```

A interface não executa processamento pesado deliberadamente. A timeline é um modelo de dados independente da renderização e o controlador concentra as mutações, o histórico e o salvamento. Isso permite trocar o preview por um compositor nativo sem reescrever o formato do projeto.

## Persistência

Cada projeto usa um JSON com `schemaVersion`, mídias por caminho, trilhas, clipes, efeitos, keyframes, marcadores e preferências de exportação. O salvamento usa um arquivo temporário seguido de troca atômica. O autosave utiliza o mesmo documento com sufixo `.autosave.json`.

## Engine de mídia

A inspeção chama FFprobe e transforma o resultado em `MediaAsset`. A preparação gera thumbnail e waveform no diretório temporário do aplicativo. O exportador cria uma cadeia de filtros a partir do modelo, mantendo o original intacto.

## Timeline

`TimelineTrack` possui um tipo (`video`, `audio`, `overlay` ou `subtitle`) e uma lista de `TimelineClip`. O clipe armazena intervalo no projeto, intervalo na fonte, velocidade, transformações, efeitos e keyframes. Todas as mutações relevantes passam por checkpoint para undo/redo.

## Segurança

Não existe carregador de plugin executável. Paths chegam pelo seletor nativo e não são concatenados em comandos de shell no desktop: o processo recebe uma lista de argumentos. O ramo Android usa a API de argumentos do pacote FFmpegKit. Segredos não são lidos nem armazenados pelo app.

## Evolução

O `CompositionFrame` é a descrição lógica compartilhada: o preview consulta suas camadas ativas e o exportador usa os mesmos intervalos, tempos de fonte, velocidade, transformações e efeitos para montar o grafo base/overlay. A reprodução multicamada de vídeos no backend Flutter ainda é uma limitação conhecida.

A próxima camada de renderização deve consumir o mesmo `Project` e gerar preview em resolução adaptativa. Um módulo nativo de hardware decoding/encoding pode ser ligado ao `ExportService` sem mudar o formato JSON. IA e proxy devem ser módulos opcionais que adicionam metadados ao projeto, mas não podem tornar a edição básica dependente de rede.
