# Desktop

## Linux

O runner Linux é gerado pelo Flutter. Instale as bibliotecas padrão do Flutter Desktop e confirme a presença de `ffmpeg` e `ffprobe` no `PATH`.

```bash
flutter run -d linux
flutter build linux
```

## Windows

Instale Visual Studio com a carga de trabalho Desktop development with C++ e use um prompt com o ambiente configurado.

```bash
flutter run -d windows
flutter build windows
```

## Processamento

No desktop, o serviço usa `Process.run`/`Process.start` com uma lista de argumentos, sem shell intermediário. O caminho da mídia é passado como argumento do processo. O executável precisa estar instalado pelo usuário ou pelo empacotador da distribuição.

## Preview

A dependência `video_player` utilizada nesta versão fornece backend Android, mas não adiciona um backend nativo Linux/Windows neste pacote. Por isso o desktop mostra thumbnails para mídias sem backend de vídeo. A timeline, metadados, edição do modelo e exportação continuam disponíveis.

## Distribuição

Ao distribuir uma versão desktop, inclua instruções ou um instalador que forneça FFmpeg conforme a licença aplicável. Não coloque binários proprietários ou chaves secretas no código.
