# FFmpeg

## Uso

O OpenReel usa FFprobe para ler `format` e `streams`. O `MediaService` converte os campos de vídeo e áudio em `MediaAsset`. O `ExportService` monta filtros para trim, escala, FPS, velocidade, efeitos e concatenação.

No Android e iOS, a execução usa `ffmpeg_kit_flutter_new`. No Linux e Windows, a execução procura `ffmpeg` e `ffprobe` no `PATH`.

## Argumentos

Os caminhos são passados como argumentos separados no desktop. No Android, a string é montada com aspas apenas na camada de integração do FFmpegKit. O aplicativo não aceita uma linha de comando livre do usuário.

## Codecs

A configuração padrão usa H.264 (`libx264`), AAC, CRF 18, bitrate de vídeo de 8 Mbps e pixel format `yuv420p`. O modelo pode armazenar outro codec disponível, mas a disponibilidade depende da build do FFmpeg instalada.

## Licença

FFmpeg pode ser distribuído sob LGPL ou GPL, dependendo das opções de compilação e das bibliotecas habilitadas. FFmpegKit possui suas próprias condições. Antes de publicar um APK ou instalador com a engine embutida, revise os textos de licença das versões efetivamente empacotadas e forneça os avisos correspondentes.

Referências oficiais: [FFmpeg](https://ffmpeg.org/), [FFmpeg legal](https://ffmpeg.org/legal.html) e [FFmpegKit Flutter](https://pub.dev/packages/ffmpeg_kit_flutter_new).
