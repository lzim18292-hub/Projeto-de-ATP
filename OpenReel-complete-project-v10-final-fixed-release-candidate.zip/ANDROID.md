# Android

## Importação

O seletor nativo do `file_picker` fornece os caminhos acessíveis ao aplicativo. O OpenReel não copia automaticamente a mídia original para um servidor; o projeto guarda o caminho selecionado e os metadados derivados.

## FFmpeg

Em Android, `MediaService` usa FFprobe do pacote FFmpegKit para inspeção e FFmpegKit para gerar thumbnails, waveforms e exportação. O aplicativo não precisa instalar um executável separado.

## Build

```bash
flutter pub get
flutter build apk --debug
```

Para instalar em um dispositivo conectado:

```bash
flutter install
```

## Assinatura

A assinatura release deve ser feita com um keystore fornecido pelo mantenedor no ambiente de CI. Nunca armazene o keystore ou sua senha no repositório. O workflow público gera apenas APK debug, que não exige segredo.

## Hardware

A versão atual delega decodificação e codificação à engine FFmpegKit. A seleção explícita de MediaCodec por codec ainda deve ser adicionada em um adaptador nativo antes de ser apresentada como um modo configurável.

## Limitações

O preview de vídeo está ligado ao `video_player` e é validado principalmente no Android. A análise e exportação offline são o caminho principal; modelos de IA e uploads não são necessários para editar ou exportar.
