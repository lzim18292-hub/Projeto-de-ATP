# Auditoria inicial do produto

## Método

A auditoria percorreu os arquivos Dart, modelos JSON, controlador, timeline, UI, serviços FFmpeg, runners de plataforma, testes, dependências e workflows. A busca por `TODO`, `FIXME`, `mock`, `fake`, `placeholder` e funções vazias encontrou apenas ocorrências dentro da especificação copiada para `SPECIFICATION.txt`; não há código de placeholder no `lib/`.

## Matriz de funcionalidade

| Funcionalidade | Existe | Funciona | Parcial | Bug encontrado | Falta |
| --- | --- | --- | --- | --- | --- |
| Importação de arquivos | Sim | Sim | Não | API usa parâmetros deprecated, sem impacto atual | permissões/URI persistente Android avançado |
| Metadados FFprobe | Sim | Sim em desktop/Android com engine disponível | Não | falha retorna erro para UI | orientação completa e streams múltiplos |
| Thumbnail/waveform | Sim | Sim | Sim | waveform exige áudio | invalidação por hash e limite de cache |
| Timeline multifaixa | Sim | Sim | Sim | pouca otimização para milhares de clipes | seleção múltipla e resize por bordas |
| Seleção e arraste | Sim | Sim | Sim | histórico durante drag precisa checkpoint único | mouse/touch gestures avançados |
| Trim/split/ripple/duplicar | Sim | Sim | Não | dependem de seleção válida | confirmação de exclusão |
| Undo/redo | Sim | Sim | Não | histórico armazena snapshots completos | limite por tamanho e persistência do histórico |
| Texto/overlay | Sim | Parcial | Sim | título aparece na timeline mas não entra no filtro de exportação | composição drawtext/fontes |
| Preview | Sim | Parcial | Sim | preview usa um asset selecionado, não composição timeline completa | compositor de timeline com efeitos/keyframes |
| Efeitos | Sim | Parcial | Sim | filtros básicos exportam; preview não os aplica | efeitos avançados e parâmetros na UI |
| Keyframes | Sim | Parcial | Sim | dados persistem; não são interpolados no preview/export | interpolador aplicado ao render |
| Áudio | Sim | Parcial | Sim | áudio do clipe único é mapeado; mix de faixas não | fade, pan, EQ, compressor, limiter, mute |
| Exportação | Sim | Parcial | Sim | concatenação não mistura áudio de várias faixas | containers/presets/metadata e cancelamento |
| Projetos/autosave | Sim | Sim | Não | carregamento depende de id conhecido | biblioteca UI, duplicar/renomear/excluir/recovery dialog |
| Proxy | Não | Não | Não | nenhum botão falso | geração, associação e render original |
| Legendas | Não | Não | Não | nenhum botão falso | parser SRT/VTT/ASS e render |
| IA local | Não | Não | Não | nenhum botão falso | provider Whisper/visão/modelos opcionais |
| Hardware acceleration | Não exposta | Fallback software | Sim | não há seleção MediaCodec/GPU | adaptador nativo por codec |
| Cache | Parcial | Sim para derivados | Sim | sem limite/invalidação robusta | cache indexado e limpeza por LRU |
| Android | Sim | Não validado no ambiente original | Sim | SDK ausente no primeiro build | teste em dispositivo e permissões modernas |
| Desktop | Sim | Sim para modelo e exportação com FFmpeg | Sim | preview de vídeo sem backend nativo | backend Linux/Windows |
| Testes | Sim | Sim | Sim | cobrem domínio e widget, não pipeline FFmpeg | integração por fixtures e stress |
| GitHub Actions | Sim | Não validado remoto | Sim | depende do runner e ação Flutter | release assinado e matriz Windows |

## Correções prioritárias

A auditoria indica que o maior risco de produto não é um botão falso, mas a divergência entre preview e exportação. A correção prioritária deve ser um compositor mínimo de timeline para preview, seguido por um pipeline de áudio com todas as trilhas. Também é necessário tornar o exportador cancelável e validar cada saída com FFprobe.

O projeto não será descrito como editor profissional completo enquanto os itens marcados como parciais ou ausentes não tiverem pipeline UI–estado–engine–preview–exportação–teste. As lacunas permanecem explicitamente documentadas em [`FEATURE_STATUS.md`](FEATURE_STATUS.md).
