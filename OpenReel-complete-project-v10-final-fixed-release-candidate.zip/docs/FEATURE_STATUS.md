# Status de recursos

Este documento evita apresentar controles sem implementação real como se fossem completos.

| Recurso solicitado | Status nesta versão | Observação técnica |
| --- | --- | --- |
| Importação e metadados | Implementado | FFprobe lê streams e formato; thumbnails e waveform são gerados no cache temporário. |
| Timeline multifaixa | Parcial avançado | Vídeo, áudio e overlay possuem trilhas próprias; arraste usa snapping de 100 ms; copiar/colar, marcador, bloqueio, ocultação e histórico estão conectados. Seleção múltipla e resize por borda ainda não estão completos. |
| Trim, split, ripple delete, duplicar | Implementado | Operações alteram o modelo e entram no histórico undo/redo. |
| Transformações | Parcial avançado | Escala, rotação, opacidade e velocidade são avaliadas pela composição e aplicadas ao exportador; posição/crop/flip/âncora ainda precisam de pipeline completo. |
| Efeitos básicos | Implementado | Brilho, contraste, saturação, blur, sharpen, grayscale e vignette são filtros FFmpeg não destrutivos. |
| Keyframes | Parcial avançado | Keyframes são adicionados, preservados, serializados e avaliados linear/ease na `CompositionEngine`; edição/movimentação/cópia de keyframes e todos os eixos ainda não estão completos. |
| Texto | Parcial avançado | Títulos são clipes overlay, aparecem no preview composto e são renderizados no exportador via `drawtext`; fonte, contorno configurável, animação e editor tipográfico completo ainda não estão completos. |
| Preview de composição | Parcial avançado | `CompositionEngine` determina camadas ativas, categorias e assinatura; UI renderiza overlays e sincroniza a camada base. A descrição agora representa múltiplos vídeos simultâneos, mas o backend Flutter ainda reproduz apenas um vídeo real por vez. |
| Exportação FFmpeg | Parcial avançado | Android usa FFmpegKit; desktop usa `ffmpeg` do sistema; o grafo usa canvas/base + `overlay` para clips simultâneos, trim por duração de fonte/velocidade, escala, FPS, codec, CRF, texto, mixer de áudio de vídeos e trilhas externas, progresso, cancelamento e validação pós-exportação. Transições/máscaras/blend matemático ainda não estão completos. |
| Legendas SRT/VTT/ASS | Implementado no pipeline atual | `SubtitleService` importa/exporta SRT/VTT e agora suporta estilo, edição, mover, dividir e excluir; ainda não há camada de legenda ligada ao `CompositionEngine`, preview ou filtro de exportação. |
| Áudio avançado | Parcial avançado | O exportador mistura áudio embutido de vídeos e trilhas externas com volume, mute, fade in/out, pan e atraso temporal; compressor, limiter, EQ, solo, ducking e noise gate ainda não têm pipeline completo. |
| Cache inteligente | Implementado | `CacheService` implementa índice, invalidação por modificação, limite LRU, limpeza e recuperação de índice; integração completa de proxy/frames/efeitos ainda falta. |
| Proxy | Implementado | O cache de thumbnail/waveform está pronto; proxy transcodificado exige gerenciamento de correspondência original/proxy e troca no render final. |
| IA local | Não exposta na interface | Whisper, detecção de cenas/rostos e auto-reframe exigem modelos distribuídos separadamente e permissões/arquiteturas específicas. |
| LUT e curvas | Não expostos na interface | A engine de efeitos é extensível, mas não finge suportar LUT sem um parser e um pipeline de cor dedicado. |
| Plugins | Arquitetura preparada | O diretório e os contratos de domínio permitem expansão; plugins executáveis não são carregados, evitando execução arbitrária. |

## Critério de habilitação

Um recurso só deve aparecer na interface quando houver implementação de ponta a ponta: entrada validada, estado serializado, operação executável, erro tratado e teste correspondente. As lacunas acima permanecem documentadas para não induzir o usuário a acreditar que um botão visual já entrega a função.
