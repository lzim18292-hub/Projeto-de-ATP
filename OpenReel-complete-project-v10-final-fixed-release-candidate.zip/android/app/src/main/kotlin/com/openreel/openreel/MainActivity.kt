package com.openreel.openreel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
