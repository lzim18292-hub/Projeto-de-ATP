# Build Desktop

## Linux

Instale Flutter estável e as dependências do runner Linux, incluindo `clang`, `cmake`, `ninja-build`, `pkg-config` e `libgtk-3-dev`. Instale `ffmpeg` e `ffprobe` no `PATH` para análise e exportação.

```bash
flutter config --enable-linux-desktop
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build linux
```

## Windows

Instale Flutter estável, Visual Studio com a carga **Desktop development with C++**, CMake e FFmpeg/FFprobe no `PATH`.

```powershell
flutter config --enable-windows-desktop
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build windows
```

## Backend e fallback

No desktop, o exportador invoca o executável `ffmpeg` com argumentos separados e valida o resultado com `ffprobe`. Se codecs acelerados não estiverem disponíveis, o preset usa software (`libx264` por padrão). A reprodução de vídeo multicamada ainda depende de um backend desktop dedicado; o preview mantém thumbnails e overlays disponíveis sem declarar playback completo.
