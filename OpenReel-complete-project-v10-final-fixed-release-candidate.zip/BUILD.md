# Build e desenvolvimento

## Ambiente

Instale Flutter estável, Android SDK com uma API recente e, para desktop, FFmpeg e FFprobe no `PATH`. Execute `flutter doctor` e corrija apenas os componentes da plataforma que pretende compilar.

## Dependências

```bash
flutter pub get
```

O `pubspec.lock` é versionado para tornar o ambiente reproduzível.

## Verificações locais

```bash
flutter analyze --no-fatal-infos
flutter test
```

Os testes cobrem o JSON do projeto, trim, keyframes, timeline e a renderização da tela principal.

## Execução

```bash
flutter run
flutter run -d linux
flutter run -d windows
```

Para testar a exportação desktop, confirme que `ffmpeg -version` e `ffprobe -version` funcionam no mesmo ambiente do processo Flutter.

## Android

```bash
flutter build apk --debug
flutter install
```

O APK debug é criado em `build/app/outputs/flutter-apk/app-debug.apk`. Para release, configure assinatura fora do repositório e execute `flutter build apk --release`.

## Limpeza

```bash
flutter clean
flutter pub get
```

A limpeza remove artefatos de build, não os projetos do usuário. O cache de thumbnail e waveform fica sob o diretório temporário do aplicativo e pode ser removido pelo sistema operacional.

## Diagnóstico

Se a importação falhar, verifique se o arquivo tem um formato suportado e consulte a mensagem de erro do FFprobe. Se a exportação desktop falhar, verifique codec, permissões do caminho de saída e disponibilidade do FFmpeg. No Android, erros do FFmpegKit são capturados pelo controlador e apresentados na barra de status.
