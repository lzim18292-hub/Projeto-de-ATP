
import 'dart:convert';
import '../models/project.dart';
import '../models/timeline.dart';

class ProjectTemplate {
  const ProjectTemplate({
    required this.id, required this.name, required this.description,
    required this.payload,
  });
  final String id, name, description;
  final Map<String, dynamic> payload;
  String encode() => const JsonEncoder.withIndent('  ').convert(payload);
}

class TemplateService {
  List<ProjectTemplate> builtIns() => const [
    ProjectTemplate(
      id: 'short-captioned', name: 'Short legendado',
      description: 'Vídeo vertical com legenda e camada de texto.',
      payload: {
        'schemaVersion': 1, 'name': 'Short legendado', 'width': 1080, 'height': 1920, 'fps': 30,
        'tracks': [
          {'name': 'Vídeo', 'kind': 'video'}, {'name': 'Texto', 'kind': 'overlay'}, {'name': 'Legenda', 'kind': 'subtitle'}, {'name': 'Música', 'kind': 'audio'}
        ],
      },
    ),
    ProjectTemplate(
      id: 'broll-shorts', name: 'Short com B-roll',
      description: 'Vídeo principal, B-roll, texto e música.',
      payload: {
        'schemaVersion': 1, 'name': 'B-roll', 'width': 1080, 'height': 1920, 'fps': 30,
        'tracks': [
          {'name': 'Vídeo principal', 'kind': 'video'}, {'name': 'B-roll', 'kind': 'overlay'}, {'name': 'Texto', 'kind': 'overlay'}, {'name': 'Música', 'kind': 'audio'}
        ],
      },
    ),
  ];

  Project apply(ProjectTemplate template, Project source) {
    final result = Project(
      id: source.id, name: source.name, width: source.width, height: source.height,
      fps: source.fps, durationMs: source.durationMs,
      assets: source.assets.toList(),
      tracks: source.tracks.map(_cloneTrack).toList(),
      markers: source.markers.toList(),
      subtitleCues: source.subtitleCues.map((c) => c.copy()).toList(),
      exportSettings: source.exportSettings,
    );
    final data = template.payload;
    result.width = (data['width'] as num?)?.toInt() ?? result.width;
    result.height = (data['height'] as num?)?.toInt() ?? result.height;
    result.fps = (data['fps'] as num?)?.toInt() ?? result.fps;
    final templateTracks = (data['tracks'] as List?) ?? const [];
    if (templateTracks.isNotEmpty) {
      result.tracks
        ..clear()
        ..addAll(templateTracks.map((raw) {
          final map = (raw as Map).cast<String, dynamic>();
          return TimelineTrack(
            id: 'track-${map['kind']}-${map['name']}',
            name: map['name']?.toString() ?? 'Track',
            kind: TrackKind.values.byName(map['kind']?.toString() ?? 'video'),
          );
        }));
    }
    result.exportSettings = result.exportSettings.copyWith(width: result.width, height: result.height, fps: result.fps);
    return result;
  }

  TimelineTrack _cloneTrack(TimelineTrack t) => TimelineTrack(
    id: t.id, name: t.name, kind: t.kind, locked: t.locked, hidden: t.hidden,
    clips: t.clips.map((c) => c.clone(id: c.id)).toList(),
  );
}
