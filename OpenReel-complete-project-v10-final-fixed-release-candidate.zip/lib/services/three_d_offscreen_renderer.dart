import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../models/composition.dart';
import '../models/model3d.dart';

/// Renders GLB/GLTF frames through the same model-viewer engine used by the
/// interactive 3D preview. Frames are emitted as PNGs so FFmpeg can composite
/// them with the normal OpenReel composition graph.
///
/// This intentionally uses a real WebGL/WebView renderer instead of trying to
/// approximate a 3D scene with Flutter widgets or FFmpeg filters.
class ThreeDOffscreenRenderer {
  HeadlessInAppWebView? _webView;
  Directory? _workingDirectory;

  Future<Directory> renderClip({
    required Model3DAsset asset,
    required CompositionLayer layer,
    required int width,
    required int height,
    required int fps,
    required int durationMs,
    required Directory outputDirectory,
    required CompositionLayer Function(int timelineMs) layerAt,
    void Function(double fraction)? onProgress,
  }) async {
    if (!Platform.isAndroid &&
        !Platform.isIOS &&
        !Platform.isMacOS &&
        !Platform.isWindows) {
      throw UnsupportedError(
        'Renderização 3D offline requer um backend WebView com WebGL nesta plataforma.',
      );
    }
    final model = File(asset.path);
    if (!model.existsSync()) {
      throw StateError('Modelo 3D não encontrado: ${asset.path}');
    }
    final validation = await Model3DService().validateFile(asset.path);
    if (!validation.valid) throw StateError(validation.message);

    await dispose();
    _workingDirectory = Directory(
      '${outputDirectory.path}/3d_${_safeId(layer.clipId)}',
    );
    if (!_workingDirectory!.existsSync()) {
      await _workingDirectory!.create(recursive: true);
    }

    final script = await rootBundle.loadString(
      'packages/flutter_3d_controller/assets/model_viewer.min.js',
    );
    final html = _html(
      modelUri: Uri.file(asset.path).toString(),
      modelViewerScript: script,
      width: width,
      height: height,
    );
    final baseUrl = WebUri(Uri.directory('${_workingDirectory!.path}/').toString());

    final ready = Completer<InAppWebViewController>();
    _webView = HeadlessInAppWebView(
      initialSize: Size(width.toDouble(), height.toDouble()),
      initialData: InAppWebViewInitialData(
        data: html,
        baseUrl: baseUrl,
      ),
      initialSettings: InAppWebViewSettings(
        javaScriptEnabled: true,
        transparentBackground: true,
        allowFileAccess: true,
        allowContentAccess: true,
        allowFileAccessFromFileURLs: true,
        allowUniversalAccessFromFileURLs: true,
        mediaPlaybackRequiresUserGesture: false,
        disableVerticalScroll: true,
        disableHorizontalScroll: true,
        supportZoom: false,
        cacheEnabled: true,
        domStorageEnabled: true,
      ),
      onWebViewCreated: (controller) {
        if (!ready.isCompleted) ready.complete(controller);
      },
    );
    await _webView!.run();
    final controller = await ready.future.timeout(const Duration(seconds: 15));
    await _waitUntilReady(controller);

    final frameCount = ((durationMs / 1000) * fps).ceil().clamp(1, 300000);
    for (var frame = 0; frame < frameCount; frame++) {
      final localMs = ((frame * 1000) / fps).round();
      final timelineMs = layer.startMs + localMs;
      final currentLayer = layerAt(timelineMs);
      await _applyLayer(controller, currentLayer, localMs);
      await Future<void>.delayed(const Duration(milliseconds: 8));
      final bytes = await controller.takeScreenshot();
      if (bytes == null || bytes.isEmpty) {
        throw StateError('Renderer 3D não retornou frame para ${layer.clipId}.');
      }
      final path = '${_workingDirectory!.path}/frame_${frame.toString().padLeft(7, '0')}.png';
      await File(path).writeAsBytes(bytes, flush: true);
      onProgress?.call((frame + 1) / frameCount);
    }
    return _workingDirectory!;
  }

  Future<void> _waitUntilReady(InAppWebViewController controller) async {
    final deadline = DateTime.now().add(const Duration(seconds: 15));
    while (DateTime.now().isBefore(deadline)) {
      final result = await controller.evaluateJavascript(
        source: 'window.__openreelReady === true',
      );
      if (result == true || result.toString() == 'true') return;
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
    throw TimeoutException('Tempo esgotado aguardando o modelo GLB/GLTF carregar.');
  }

  Future<void> _applyLayer(
    InAppWebViewController controller,
    CompositionLayer layer,
    int timelineMs,
  ) async {
    final t = layer.transform3D;
    final payload = {
      'x': t.x,
      'y': t.y,
      'z': t.z,
      'rx': t.rotationX,
      'ry': t.rotationY,
      'rz': t.rotationZ,
      'scale': t.scale,
      'opacity': (layer.opacity * t.opacity).clamp(0, 1),
      'time': timelineMs / 1000,
    };
    await controller.evaluateJavascript(
      source: 'window.__openreelSetTransform(${jsonEncode(payload)});',
    );
  }

  String _html({
    required String modelUri,
    required String modelViewerScript,
    required int width,
    required int height,
  }) {
    final script = jsonEncode(modelViewerScript);
    final src = jsonEncode(modelUri);
    return '''<!doctype html>
<html><head><meta charset="utf-8">
<style>
html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:transparent}
#stage{position:relative;width:${width}px;height:${height}px;overflow:hidden;background:transparent}
#viewer{position:absolute;left:0;top:0;width:100%;height:100%;background-color:transparent;--poster-color:transparent;}
</style></head><body>
<div id="stage"><model-viewer id="viewer" src=$src interaction-prompt="none" shadow-intensity="1" exposure="1" environment-image="neutral" autoplay></model-viewer></div>
<script type="module">eval($script);</script>
<script>
(function(){
 const v=document.getElementById('viewer');
 window.__openreelReady=false;
 v.addEventListener('load',()=>window.__openreelReady=true,{once:true});
 window.__openreelSetTransform=function(p){
   const sx=Math.max(0.001, Number(p.scale)||1);
   v.setAttribute('orientation', `\${Number(p.rx)||0}deg \${Number(p.ry)||0}deg \${Number(p.rz)||0}deg`);
   v.style.transform=`translate3d(\${Number(p.x)||0}px,\${Number(p.y)||0}px,\${Number(p.z)||0}px) scale(\${sx})`;
   v.style.transformOrigin='center center';
   v.style.opacity=String(Math.max(0,Math.min(1,Number(p.opacity)||0)));
   try { v.currentTime=Number(p.time)||0; } catch(e) {}
 };
})();
</script></body></html>''';
  }

  String _safeId(String value) => value.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');

  Future<void> dispose() async {
    final web = _webView;
    _webView = null;
    if (web != null) await web.dispose();
  }
}
