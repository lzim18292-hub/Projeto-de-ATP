
import 'dart:convert';
import 'dart:io';
import 'package:uuid/uuid.dart';
import '../models/model3d.dart';
import '../models/project.dart';
import '../models/timeline.dart';
import '../models/media_asset.dart';
import 'subtitle_service.dart';
import 'media_service.dart';

const shortAutoSchemaVersion = '1.0';

class ShortAutoException implements Exception {
  ShortAutoException(this.message);
  final String message;
  @override String toString() => 'ShortAutoException: $message';
}

class ShortAutoConfig {
  ShortAutoConfig({
    required this.name,
    this.width = 1080, this.height = 1920, this.fps = 30,
    this.durationMs = 0, this.orientation = 'portrait',
    this.videoPaths = const [], this.imagePaths = const [], this.audioPaths = const [],
    this.subtitlePaths = const [], this.texts = const [], this.object3dPaths = const [],
    this.autoCuts = false, this.removeSilence = false, this.autoReframe = false,
    this.autoZoom = false, this.autoSubtitles = false, this.template = '',
  });
  final String name; final int width, height, fps, durationMs; final String orientation;
  final List<String> videoPaths, imagePaths, audioPaths, subtitlePaths, texts, object3dPaths;
  final bool autoCuts, removeSilence, autoReframe, autoZoom, autoSubtitles;
  final String template;
}

class ShortAutoParser {
  Map<String, dynamic> parseJson(String source) {
    dynamic decoded;
    try { decoded = jsonDecode(source); } catch (e) { throw ShortAutoException('JSON inválido: $e'); }
    if (decoded is! Map) throw ShortAutoException('A raiz JSON precisa ser um objeto.');
    return _validate(decoded.cast<String, dynamic>());
  }

  Map<String, dynamic> parseXml(String source) {
    final trimmed = source.trim();
    if (!trimmed.startsWith('<') || !trimmed.contains('>')) {
      throw ShortAutoException('XML inválido: raiz ausente.');
    }
    final root = RegExp(r'<(?:short|project)\b[^>]*>([\s\S]*)</(?:short|project)>', caseSensitive: false).firstMatch(trimmed);
    if (root == null) throw ShortAutoException('XML inválido: use <short>...</short>.');
    final body = root.group(1)!;
    String text(String tag, [String fallback = '']) =>
        RegExp('<$tag(?:\\s[^>]*)?>([\\s\\S]*?)</$tag>', caseSensitive: false).firstMatch(body)?.group(1)?.trim() ?? fallback;
    List<String> paths(String tag) => RegExp('<$tag(?:\\s[^>]*)?>([\\s\\S]*?)</$tag>', caseSensitive: false)
        .allMatches(body).map((m) => m.group(1)!.trim()).where((x) => x.isNotEmpty).toList();
    final videos = paths('video');
    final images = paths('image');
    final audios = paths('audio')..addAll(paths('music'))..addAll(paths('voice'));
    final subs = paths('subtitle')..addAll(paths('srt'))..addAll(paths('vtt'));
    final objects = {...paths('object3d'), ...RegExp(r'<object3d[^>]*>[\s\S]*?<model>([\s\S]*?)</model>[\s\S]*?</object3d>', caseSensitive:false).allMatches(body).map((m) => m.group(1)!.trim())}.toList();
    final result = <String, dynamic>{
      'schemaVersion': text('schemaVersion', shortAutoSchemaVersion),
      'name': text('name', 'Short automático'),
      'width': int.tryParse(text('width', '1080')) ?? 1080,
      'height': int.tryParse(text('height', '1920')) ?? 1920,
      'fps': int.tryParse(text('fps', '30')) ?? 30,
      'durationMs': int.tryParse(text('durationMs', '0')) ?? 0,
      'orientation': text('orientation', 'portrait'),
      'media': {'videos': videos, 'images': images, 'audio': audios, 'subtitles': subs, 'object3d': objects},
      'texts': paths('text'),
      'automation': {
        'autoCuts': text('autoCuts', 'false') == 'true',
        'removeSilence': text('removeSilence', 'false') == 'true',
        'autoReframe': text('autoReframe', 'false') == 'true',
        'autoZoom': text('autoZoom', 'false') == 'true',
        'autoSubtitles': text('autoSubtitles', 'false') == 'true',
      },
      'template': text('template'),
    };
    return _validate(result);
  }

  Map<String, dynamic> _validate(Map<String, dynamic> value) {
    const allowed = {
      'schemaVersion', 'name', 'width', 'height', 'fps', 'durationMs',
      'orientation', 'media', 'texts', 'automation', 'template', 'export',
    };
    final unknown = value.keys.where((key) => !allowed.contains(key)).toList();
    if (unknown.isNotEmpty) throw ShortAutoException('Propriedade desconhecida: ${unknown.join(', ')}');
    final version = value['schemaVersion']?.toString() ?? shortAutoSchemaVersion;
    if (version != shortAutoSchemaVersion) throw ShortAutoException('Versão do schema incompatível: $version.');
    final width = _positive(value['width'], 'width', 240);
    final height = _positive(value['height'], 'height', 240);
    final fps = _positive(value['fps'], 'fps', 1);
    final media = value['media'];
    if (media != null && media is! Map) throw ShortAutoException('media precisa ser objeto.');
    if (media is Map) {
      final unknownMedia = media.keys.map((key) => key.toString()).where((key) => !{'videos','images','audio','music','voice','subtitles','object3d'}.contains(key)).toList();
      if (unknownMedia.isNotEmpty) throw ShortAutoException('Propriedade media desconhecida: ${unknownMedia.join(', ')}');
    }
    for (final key in ['videos','images','audio','music','voice','subtitles','object3d']) {
      if (media is Map && media[key] != null && media[key] is! List) {
        throw ShortAutoException('media.$key precisa ser lista.');
      }
    }
    final copy = Map<String, dynamic>.from(value);
    copy['width'] = width; copy['height'] = height; copy['fps'] = fps;
    return copy;
  }

  int _positive(dynamic value, String name, int minimum) {
    final n = value is num ? value.toInt() : int.tryParse('$value');
    if (n == null || n < minimum) throw ShortAutoException('$name inválido.');
    return n;
  }
}

class ShortAutoEngine {
  ShortAutoEngine({Uuid? uuid}) : _uuid = uuid ?? const Uuid();
  final Uuid _uuid;
  final MediaService _mediaService = MediaService();
  final Model3DService _model3dService = Model3DService();
  final ShortAutoParser parser = ShortAutoParser();

  Future<Project> fromJson(String source) async => build(parser.parseJson(source));
  Future<Project> fromXml(String source) async => build(parser.parseXml(source));

  Future<Project> fromFile(String path) async {
    final file = File(path);
    if (!await file.exists()) throw ShortAutoException('Arquivo de automação não encontrado: $path');
    final source = await file.readAsString();
    final ext = path.split('.').last.toLowerCase();
    if (ext == 'json') return fromJson(source);
    if (ext == 'xml') return fromXml(source);
    throw ShortAutoException('Formato de automação não suportado: .$ext');
  }

  Future<Project> build(Map<String, dynamic> config) async {
    final name = config['name']?.toString().trim();
    if (name == null || name.isEmpty) throw ShortAutoException('name é obrigatório.');
    final project = Project(
      id: _uuid.v4(), name: name,
      width: (config['width'] as num?)?.toInt() ?? 1080,
      height: (config['height'] as num?)?.toInt() ?? 1920,
      fps: (config['fps'] as num?)?.toInt() ?? 30,
    );
    project.exportSettings = project.exportSettings.copyWith(width: project.width, height: project.height, fps: project.fps);
    final media = (config['media'] as Map?)?.cast<String, dynamic>() ?? {};
    final videos = _strings(media['videos']);
    final images = _strings(media['images']);
    final audios = [..._strings(media['audio']), ..._strings(media['music']), ..._strings(media['voice'])];
    final subtitles = _strings(media['subtitles']);
    final objects = _strings(media['object3d']);
    final textValues = _strings(config['texts']);
    var cursor = 0;
    TimelineTrack videoTrack = project.tracks.first;
    for (final path in videos) {
      final asset = await _mediaService.inspect(path, id: _uuid.v4());
      if (asset.kind != MediaKind.video) {
        throw ShortAutoException('Arquivo não é vídeo: $path');
      }
      final persisted = await _mediaService.persist(asset);
      project.assets.add(persisted);
      final duration = persisted.durationMs;
      if (duration <= 0) throw ShortAutoException('Vídeo sem duração válida: $path');
      final clip = TimelineClip(id: _uuid.v4(), assetId: asset.id, trackId: videoTrack.id, startMs: cursor, durationMs: duration);
      videoTrack.clips.add(clip);
      cursor += duration;
    }
    project.durationMs = config['durationMs'] is num ? (config['durationMs'] as num).toInt() : cursor;
    if (project.durationMs <= 0) project.durationMs = cursor > 0 ? cursor : 1000;
    if (images.isNotEmpty) {
      final track = TimelineTrack(id: _uuid.v4(), name: 'B-roll', kind: TrackKind.overlay);
      project.tracks.add(track);
      for (final path in images) {
        if (!await File(path).exists()) throw ShortAutoException('Imagem não encontrada: $path');
        final asset = MediaAsset(id: _uuid.v4(), path: path, name: path.split(Platform.pathSeparator).last, kind: MediaKind.image, durationMs: 3000);
        final persisted = await _mediaService.persist(asset);
        project.assets.add(persisted);
        track.clips.add(TimelineClip(id: _uuid.v4(), assetId: persisted.id, trackId: track.id, startMs: 0, durationMs: mathMin(3000, cursor == 0 ? 3000 : cursor)));
      }
    }
    if (audios.isNotEmpty) {
      final track = TimelineTrack(id: _uuid.v4(), name: 'Música', kind: TrackKind.audio);
      project.tracks.add(track);
      for (final path in audios) {
        if (!await File(path).exists()) throw ShortAutoException('Áudio não encontrado: $path');
        final asset = MediaAsset(id: _uuid.v4(), path: path, name: path.split(Platform.pathSeparator).last, kind: MediaKind.audio);
        final persisted = await _mediaService.persist(asset);
        project.assets.add(persisted);
        track.clips.add(TimelineClip(id: _uuid.v4(), assetId: persisted.id, trackId: track.id, startMs: 0, durationMs: project.durationMs > 0 ? project.durationMs : 30000));
      }
    }
    for (final path in subtitles) {
      if (!await File(path).exists()) throw ShortAutoException('Legenda não encontrada: $path');
      final cues = await SubtitleService().parseFile(path);
      project.subtitleCues.addAll(cues);
    }
    if (objects.isNotEmpty) {
      final track = TimelineTrack(id: _uuid.v4(), name: '3D', kind: TrackKind.object3d);
      project.tracks.add(track);
      for (final path in objects) {
        final modelId = _uuid.v4();
        final persistedPath = await _model3dService.persistFile(path, modelId);
        final model = await _model3dService.inspect(
          id: modelId, path: persistedPath,
          name: path.split(Platform.pathSeparator).last,
        );
        project.model3dAssets.add(model);
        final duration = project.durationMs > 0 ? project.durationMs : (cursor > 0 ? cursor : 5000);
        track.clips.add(TimelineClip(
          id: _uuid.v4(), assetId: '3d:${model.id}', object3dAssetId: model.id,
          trackId: track.id, startMs: 0, durationMs: duration,
        ));
      }
    }
    if (textValues.isNotEmpty) {
      final track = TimelineTrack(id: _uuid.v4(), name: 'Textos', kind: TrackKind.overlay);
      project.tracks.add(track);
      for (final text in textValues) track.clips.add(TimelineClip(id: _uuid.v4(), assetId: 'text:${_uuid.v4()}', trackId: track.id, startMs: 0, durationMs: project.durationMs > 0 ? project.durationMs : 3000, text: text));
    }
    if (config['automation'] is Map) {
      // These flags are intentionally recorded in metadata only until a real
      // analysis provider is configured. No fake AI is performed.
      final automation = (config['automation'] as Map).cast<String,dynamic>();
      if (automation.values.any((v) => v == true)) {
        project.name = '${project.name} • Auto';
      }
    }
    return project;
  }

  List<String> _strings(dynamic value) => value is List ? value.map((e) => '$e').where((e) => e.trim().isNotEmpty).toList() : const [];
  int mathMin(int a, int b) => a < b ? a : b;

}