import 'dart:io';

class SubtitleStyle {
  const SubtitleStyle({
    this.fontFamily = 'sans-serif',
    this.fontSize = 32,
    this.color = 'white',
    this.outlineColor = 'black',
    this.outlineWidth = 2,
    this.background = 'transparent',
    this.x = 0.5,
    this.y = 0.9,
  });

  final String fontFamily;
  final double fontSize;
  final String color;
  final String outlineColor;
  final double outlineWidth;
  final String background;
  final double x;
  final double y;

  Map<String, dynamic> toJson() => {
    'fontFamily': fontFamily,
    'fontSize': fontSize,
    'color': color,
    'outlineColor': outlineColor,
    'outlineWidth': outlineWidth,
    'background': background,
    'x': x,
    'y': y,
  };
  factory SubtitleStyle.fromJson(Map<String, dynamic> json) => SubtitleStyle(
    fontFamily: json['fontFamily'] as String? ?? 'sans-serif',
    fontSize: (json['fontSize'] as num?)?.toDouble() ?? 32,
    color: json['color'] as String? ?? 'white',
    outlineColor: json['outlineColor'] as String? ?? 'black',
    outlineWidth: (json['outlineWidth'] as num?)?.toDouble() ?? 2,
    background: json['background'] as String? ?? 'transparent',
    x: (json['x'] as num?)?.toDouble() ?? .5,
    y: (json['y'] as num?)?.toDouble() ?? .9,
  );
}

class SubtitleCue {
  SubtitleCue({
    required this.startMs,
    required this.endMs,
    required this.text,
    this.style = const SubtitleStyle(),
  });

  int startMs;
  int endMs;
  String text;
  SubtitleStyle style;

  SubtitleCue copy() =>
      SubtitleCue(startMs: startMs, endMs: endMs, text: text, style: style);

  Map<String, dynamic> toJson() => {
    'startMs': startMs,
    'endMs': endMs,
    'text': text,
    'style': style.toJson(),
  };

  factory SubtitleCue.fromJson(Map<String, dynamic> json) => SubtitleCue(
    startMs: (json['startMs'] as num).toInt(),
    endMs: (json['endMs'] as num).toInt(),
    text: json['text'] as String? ?? '',
    style: SubtitleStyle.fromJson(
      (json['style'] as Map?)?.cast<String, dynamic>() ?? {},
    ),
  );
}

class SubtitleService {
  Future<List<SubtitleCue>> parseFile(String path) async =>
      parse(await File(path).readAsString());

  List<SubtitleCue> parse(String source) {
    final normalized = source
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .trim();
    if (normalized.isEmpty) return [];
    final blocks = normalized.split(RegExp(r'\n\s*\n'));
    final cues = <SubtitleCue>[];
    for (final block in blocks) {
      final lines = block.split('\n').map((line) => line.trimRight()).toList();
      final timingIndex = lines.indexWhere((line) => line.contains('-->'));
      if (timingIndex < 0 || timingIndex + 1 >= lines.length) continue;
      final timing = lines[timingIndex].split('-->');
      if (timing.length != 2) continue;
      final start = _parseTime(timing[0].trim());
      final end = _parseTime(timing[1].trim().split(' ').first);
      if (start == null || end == null || end <= start) continue;
      cues.add(
        SubtitleCue(
          startMs: start,
          endMs: end,
          text: lines.sublist(timingIndex + 1).join('\n').trim(),
        ),
      );
    }
    cues.sort((a, b) => a.startMs.compareTo(b.startMs));
    return cues;
  }

  void move(SubtitleCue cue, int deltaMs) {
    cue.startMs = (cue.startMs + deltaMs).clamp(0, 24 * 60 * 60 * 1000);
    cue.endMs = (cue.endMs + deltaMs).clamp(
      cue.startMs + 1,
      24 * 60 * 60 * 1000,
    );
  }

  SubtitleCue split(SubtitleCue cue, int timeMs) {
    if (timeMs <= cue.startMs || timeMs >= cue.endMs) {
      throw ArgumentError(
        'O ponto de divisão precisa estar dentro da legenda.',
      );
    }
    final second = SubtitleCue(
      startMs: timeMs,
      endMs: cue.endMs,
      text: cue.text,
      style: cue.style,
    );
    cue.endMs = timeMs;
    return second;
  }

  void delete(List<SubtitleCue> cues, SubtitleCue cue) => cues.remove(cue);

  void edit(
    SubtitleCue cue, {
    String? text,
    int? startMs,
    int? endMs,
    SubtitleStyle? style,
  }) {
    final nextStart = startMs ?? cue.startMs;
    final nextEnd = endMs ?? cue.endMs;
    if (nextStart < 0 || nextEnd <= nextStart) {
      throw ArgumentError('Intervalo de legenda inválido.');
    }
    cue.startMs = nextStart;
    cue.endMs = nextEnd;
    if (text != null) cue.text = text;
    if (style != null) cue.style = style;
  }

  String toSrt(Iterable<SubtitleCue> cues) {
    final buffer = StringBuffer();
    var index = 1;
    for (final cue in cues) {
      buffer.writeln(index++);
      buffer.writeln('${_format(cue.startMs)} --> ${_format(cue.endMs)}');
      buffer.writeln(cue.text);
      buffer.writeln();
    }
    return buffer.toString();
  }

  String toVtt(Iterable<SubtitleCue> cues) =>
      'WEBVTT\n\n${toSrt(cues).replaceAllMapped(RegExp(r'(\d{2}):(\d{2}):(\d{2}),(\d{3})'), (match) => '${match[1]}:${match[2]}:${match[3]}.${match[4]}')}';

  int? _parseTime(String value) {
    final normalized = value.replaceFirst(',', '.');
    final parts = normalized.split(':');
    if (parts.length == 2) parts.insert(0, '0');
    if (parts.length != 3) return null;
    final seconds = double.tryParse(parts[2]);
    final hours = int.tryParse(parts[0]);
    final minutes = int.tryParse(parts[1]);
    if (seconds == null || hours == null || minutes == null) return null;
    return ((hours * 3600 + minutes * 60 + seconds) * 1000).round();
  }

  String _format(int milliseconds) {
    final hours = milliseconds ~/ 3600000;
    final minutes = (milliseconds ~/ 60000) % 60;
    final seconds = (milliseconds ~/ 1000) % 60;
    final millis = milliseconds % 1000;
    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')},${millis.toString().padLeft(3, '0')}';
  }
}
