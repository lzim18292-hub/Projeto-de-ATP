import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/project.dart';

class ProjectRepository {
  Future<Directory> _root() async {
    final base = await getApplicationDocumentsDirectory();
    final root = Directory('${base.path}/OpenReel/projects');
    if (!root.existsSync()) await root.create(recursive: true);
    return root;
  }

  Future<File> _file(String id) async {
    if (!RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(id)) {
      throw ArgumentError('Identificador de projeto inválido.');
    }
    return File('${(await _root()).path}/$id.openreel.json');
  }

  Future<void> save(Project project) async {
    final file = await _file(project.id);
    final temporary = File('${file.path}.tmp');
    final backup = File('${file.path}.bak');
    await temporary.writeAsString(project.encode(), flush: true);
    if (file.existsSync()) {
      if (backup.existsSync()) await backup.delete();
      await file.rename(backup.path);
    }
    try {
      await temporary.rename(file.path);
      if (backup.existsSync()) await backup.delete();
    } catch (_) {
      if (!file.existsSync() && backup.existsSync()) {
        await backup.rename(file.path);
      }
      rethrow;
    }
  }

  Future<Project?> load(String id) async {
    final file = await _file(id);
    if (!file.existsSync()) return null;
    return Project.fromJson(
      jsonDecode(await file.readAsString()) as Map<String, dynamic>,
    );
  }

  Future<List<ProjectSummary>> list() async {
    final root = await _root();
    final files = root.listSync().whereType<File>().where(
      (file) => file.path.endsWith('.openreel.json'),
    );
    final summaries = <ProjectSummary>[];
    for (final file in files) {
      try {
        final json =
            jsonDecode(await file.readAsString()) as Map<String, dynamic>;
        summaries.add(
          ProjectSummary(
            id: json['id'] as String,
            name: json['name'] as String,
            modifiedAt: file.lastModifiedSync(),
          ),
        );
      } catch (_) {
        // Um projeto corrompido não impede os demais de aparecerem na biblioteca.
      }
    }
    summaries.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    return summaries;
  }

  Future<void> delete(String id) async {
    final file = await _file(id);
    if (file.existsSync()) await file.delete();
  }

  Future<File> exportBackup(Project project, String destinationPath) async {
    final destination = File(destinationPath);
    await destination.writeAsString(project.encode(), flush: true);
    return destination;
  }

  Future<bool> hasAutosave(String id) async {
    if (!RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(id)) return false;
    final root = await _root();
    return File('${root.path}/$id.autosave.json').existsSync();
  }

  Future<Project?> recoverAutosave(String id) async {
    if (!RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(id)) {
      throw ArgumentError('Identificador de autosave inválido.');
    }
    final file = File('${(await _root()).path}/$id.autosave.json');
    if (!file.existsSync()) return null;
    return Project.fromJson(
      jsonDecode(await file.readAsString()) as Map<String, dynamic>,
    );
  }

  Future<void> autosave(Project project) async {
    final file = File('${(await _root()).path}/${project.id}.autosave.json');
    final temporary = File('${file.path}.tmp');
    await temporary.writeAsString(project.encode(), flush: true);
    if (file.existsSync()) await file.delete();
    await temporary.rename(file.path);
  }
}

class ProjectSummary {
  const ProjectSummary({
    required this.id,
    required this.name,
    required this.modifiedAt,
  });
  final String id;
  final String name;
  final DateTime modifiedAt;
}
