import 'dart:convert';
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../models/media_asset.dart';

class MediaService {
  final _uuid = const Uuid();

  Future<MediaAsset> inspect(String path, {String? id}) async {
    final json = await _probe(path);
    final streams = (json['streams'] as List? ?? []).cast<Map>();
    final format = (json['format'] as Map?)?.cast<String, dynamic>() ?? {};
    final video = streams.cast<Map<String, dynamic>?>().firstWhere(
      (stream) => stream?['codec_type'] == 'video',
      orElse: () => null,
    );
    final audio = streams.cast<Map<String, dynamic>?>().firstWhere(
      (stream) => stream?['codec_type'] == 'audio',
      orElse: () => null,
    );
    final kind = mediaKindFromPath(path);
    final duration =
        double.tryParse(
          '${format['duration'] ?? video?['duration'] ?? audio?['duration'] ?? 0}',
        ) ??
        0;
    final rate = _parseRate('${video?['r_frame_rate'] ?? 0}');
    return MediaAsset(
      id: id ?? _uuid.v4(),
      path: path,
      name: path.split(Platform.pathSeparator).last,
      kind: kind,
      durationMs: (duration * 1000).round(),
      width: (video?['width'] as num?)?.toInt() ?? 0,
      height: (video?['height'] as num?)?.toInt() ?? 0,
      fps: rate,
      codec: (video?['codec_name'] ?? audio?['codec_name']) as String?,
      bitrate: int.tryParse('${format['bit_rate'] ?? 0}'),
      hasAudio: audio != null,
      channels: (audio?['channels'] as num?)?.toInt(),
      sampleRate: int.tryParse('${audio?['sample_rate'] ?? 0}'),
      orientation:
          int.tryParse(
            '${video?['tags'] is Map ? (video?['tags'] as Map)['rotate'] ?? 0 : 0}',
          ) ??
          0,
    );
  }

  /// Copies imported media into app-owned storage so project references survive
  /// Android SAF/provider lifecycle changes and external file moves.
  Future<MediaAsset> persist(MediaAsset asset) async {
    final root = await getApplicationDocumentsDirectory();
    final mediaDir = Directory('${root.path}/OpenReel/media');
    if (!mediaDir.existsSync()) await mediaDir.create(recursive: true);
    final extension = asset.path.contains('.')
        ? '.${asset.path.split('.').last.toLowerCase()}'
        : '';
    final destination = File('${mediaDir.path}/${asset.id}$extension');
    final source = File(asset.path);
    if (!source.existsSync()) {
      throw StateError('Arquivo selecionado não está acessível: ${asset.name}');
    }
    if (source.path != destination.path) {
      await source.copy(destination.path);
    }
    return asset.copyWith(
      path: destination.path,
      sourcePath: asset.path,
    );
  }

  Future<MediaAsset> prepare(MediaAsset asset) async {
    final root = await getTemporaryDirectory();
    final thumbnail = File('${root.path}/openreel_thumb_${asset.id}.jpg');
    final waveform = File('${root.path}/openreel_wave_${asset.id}.png');
    if (asset.kind == MediaKind.video ||
        asset.kind == MediaKind.image ||
        asset.kind == MediaKind.gif) {
      await _run([
        '-y',
        '-ss',
        '00:00:01',
        '-i',
        asset.path,
        '-frames:v',
        '1',
        '-vf',
        'scale=640:-2',
        thumbnail.path,
      ]);
    }
    if (asset.kind == MediaKind.video || asset.kind == MediaKind.audio) {
      await _run([
        '-y',
        '-i',
        asset.path,
        '-filter_complex',
        'aformat=channel_layouts=mono,showwavespic=s=1200x200:colors=00d9a6',
        '-frames:v',
        '1',
        waveform.path,
      ]);
    }
    return asset.copyWith(
      thumbnailPath: thumbnail.existsSync() ? thumbnail.path : null,
      waveformPath: waveform.existsSync() ? waveform.path : null,
    );
  }

  Future<Map<String, dynamic>> _probe(String path) async {
    final command =
        '-v quiet -print_format json -show_format -show_streams "${_escape(path)}"';
    if (Platform.isAndroid || Platform.isIOS) {
      final session = await FFprobeKit.execute(command);
      final output = await session.getOutput();
      if (output == null || output.trim().isEmpty)
        throw StateError('FFprobe não retornou metadados.');
      return jsonDecode(output) as Map<String, dynamic>;
    }
    final result = await Process.run('ffprobe', [
      '-v',
      'quiet',
      '-print_format',
      'json',
      '-show_format',
      '-show_streams',
      path,
    ]);
    if (result.exitCode != 0)
      throw StateError('FFprobe falhou: ${result.stderr}');
    return jsonDecode(result.stdout as String) as Map<String, dynamic>;
  }

  Future<void> _run(List<String> args) async {
    if (Platform.isAndroid || Platform.isIOS) {
      final command = args
          .map((arg) => arg.contains(' ') ? '"${_escape(arg)}"' : arg)
          .join(' ');
      final session = await FFmpegKit.execute(command);
      final code = await session.getReturnCode();
      if (code != null && !code.isValueSuccess())
        throw StateError('FFmpeg falhou ao gerar cache.');
      return;
    }
    final result = await Process.run('ffmpeg', args);
    if (result.exitCode != 0)
      throw StateError('FFmpeg falhou: ${result.stderr}');
  }

  double _parseRate(String value) {
    final parts = value.split('/');
    if (parts.length == 2) {
      final numerator = double.tryParse(parts[0]) ?? 0;
      final denominator = double.tryParse(parts[1]) ?? 1;
      return denominator == 0 ? 0 : numerator / denominator;
    }
    return double.tryParse(value) ?? 0;
  }

  String _escape(String value) => value.replaceAll('"', '\\"');
}
