import 'dart:io';

import '../models/composition.dart';
import '../models/media_asset.dart';
import '../models/project.dart';
import '../models/timeline.dart';
import '../models/model3d.dart';
import 'subtitle_service.dart';

class CompositionEngine {
  CompositionFrame compose(Project project, int timeMs) {
    final visual = <CompositionLayer>[];
    final audio = <CompositionLayer>[];
    for (final track in project.tracks) {
      if (track.hidden) continue;
      for (final clip in track.clips) {
        if (!clip.enabled || track.kind == TrackKind.subtitle) continue;
        if (timeMs < clip.startMs || timeMs >= clip.endMs) continue;
        final asset = _asset(project, clip.assetId);
        final model3d = _model3d(project, clip.object3dAssetId);
        final localTime = _localTime(clip, timeMs);
        final timelineLocalTime = timeMs - clip.startMs;
        final transform = _evaluateTransform(clip, timelineLocalTime);
        var opacity = _evaluate(
          clip.opacityKeyframes,
          timelineLocalTime,
          clip.opacity,
        ).clamp(0, 1).toDouble();
        final transition = _transitionProgress(clip, timelineLocalTime);
        opacity *= transition.progress;
        final offsetMs = timeMs - clip.startMs;
        final fadeInGain = clip.fadeInMs <= 0
            ? 1.0
            : (offsetMs / clip.fadeInMs).clamp(0.0, 1.0).toDouble();
        final fadeOutStart = clip.durationMs - clip.fadeOutMs;
        final fadeOutGain = clip.fadeOutMs <= 0 || offsetMs < fadeOutStart
            ? 1.0
            : ((clip.durationMs - offsetMs) / clip.fadeOutMs)
                  .clamp(0.0, 1.0)
                  .toDouble();
        final double volume = clip.muted
            ? 0
            : (_evaluate(
                    clip.volumeKeyframes,
                    timelineLocalTime,
                    clip.volume,
                  ).clamp(0, 4).toDouble() *
                  fadeInGain *
                  fadeOutGain);
        final layer = CompositionLayer(
          clipId: clip.id,
          trackId: track.id,
          kind: track.kind,
          sourcePath: model3d?.path ?? _visualSourcePath(asset),
          localTimeMs: localTime,
          startMs: clip.startMs,
          durationMs: clip.durationMs,
          opacity: opacity,
          volume: volume,
          transform: transform,
          effects: List.unmodifiable(clip.effects),
          blendMode: clip.blendMode,
          text: clip.text,
          textStyle: clip.textStyle,
          transitionType: transition.type,
          transitionProgress: transition.progress,
          object3dAssetId: clip.object3dAssetId,
          transform3D: _evaluateTransform3D(clip, timelineLocalTime),
        );
        if (track.kind == TrackKind.audio || asset?.kind == MediaKind.audio) {
          audio.add(layer);
        } else {
          visual.add(layer);
          if (asset?.hasAudio == true) {
            audio.add(
              CompositionLayer(
                clipId: '${clip.id}:audio',
                trackId: track.id,
                kind: TrackKind.audio,
                sourcePath: asset!.path,
                localTimeMs: localTime,
                startMs: clip.startMs,
                durationMs: clip.durationMs,
                opacity: opacity,
                volume: volume,
                transform: transform,
                effects: const [],
                blendMode: clip.blendMode,
              ),
            );
          }
        }
      }
    }
    final subtitleTrackClips = project.tracks
        .where((track) => !track.hidden && track.kind == TrackKind.subtitle)
        .expand((track) => track.clips)
        .where((clip) => clip.enabled && clip.text?.trim().isNotEmpty == true)
        .toList();
    if (subtitleTrackClips.isNotEmpty) {
      for (final clip in subtitleTrackClips) {
        if (timeMs < clip.startMs || timeMs >= clip.endMs) continue;
        final style = SubtitleStyle(
          fontFamily: clip.textStyle.fontFamily,
          fontSize: clip.textStyle.fontSize,
          color: clip.textStyle.color,
          outlineColor: clip.textStyle.outlineColor,
          outlineWidth: clip.textStyle.outlineWidth,
          background: clip.textStyle.background,
          x: clip.transform.x / project.width,
          y: clip.transform.y / project.height,
        );
        visual.add(
          CompositionLayer(
            clipId: clip.id,
            trackId: clip.trackId,
            kind: TrackKind.subtitle,
            sourcePath: null,
            localTimeMs: timeMs - clip.startMs,
            startMs: clip.startMs,
            durationMs: clip.durationMs,
            opacity: clip.opacity,
            volume: 0,
            transform: clip.transform,
            effects: const [],
            blendMode: BlendMode.normal,
            text: clip.text,
            subtitleStyle: style,
          ),
        );
      }
    } else {
      for (final cue in project.subtitleCues) {
        if (timeMs < cue.startMs || timeMs >= cue.endMs) continue;
        visual.add(
          CompositionLayer(
            clipId: 'subtitle:${cue.startMs}:${cue.endMs}:${cue.text.hashCode}',
            trackId: 'subtitle',
            kind: TrackKind.subtitle,
            sourcePath: null,
            localTimeMs: timeMs - cue.startMs,
            startMs: cue.startMs,
            durationMs: cue.endMs - cue.startMs,
            opacity: 1,
            volume: 0,
            transform: Transform2D(
              x: cue.style.x * project.width,
              y: cue.style.y * project.height,
            ),
            effects: const [],
            blendMode: BlendMode.normal,
            text: cue.text,
            subtitleStyle: cue.style,
          ),
        );
      }
    }
    return CompositionFrame(
      timeMs: timeMs,
      // Timeline order is the z-order contract: later tracks are composited
      // above earlier tracks, while clip order remains stable within a track.
      layers: List.unmodifiable(visual),
      audioLayers: List.unmodifiable(audio),
    );
  }

  ({String type, double progress}) _transitionProgress(
    TimelineClip clip,
    int localTimeMs,
  ) {
    var progress = 1.0;
    var type = 'none';
    if (clip.transitionIn.enabled && localTimeMs < clip.transitionIn.durationMs) {
      type = clip.transitionIn.type;
      progress = (localTimeMs / clip.transitionIn.durationMs)
          .clamp(0.0, 1.0)
          .toDouble();
    }
    if (clip.transitionOut.enabled &&
        localTimeMs > clip.durationMs - clip.transitionOut.durationMs) {
      type = clip.transitionOut.type;
      final remaining = clip.durationMs - localTimeMs;
      progress = progress *
          (remaining / clip.transitionOut.durationMs)
              .clamp(0.0, 1.0)
              .toDouble();
    }
    return (type: type, progress: progress);
  }

  int _localTime(TimelineClip clip, int timeMs) =>
      clip.sourceStartMs + ((timeMs - clip.startMs) * clip.speed).round();

  Transform2D _evaluateTransform(TimelineClip clip, int localTimeMs) {
    final positionX = _evaluate(
      clip.positionXKeyframes.isEmpty
          ? clip.positionKeyframes
          : clip.positionXKeyframes,
      localTimeMs,
      clip.transform.x,
    );
    final positionY = _evaluate(
      clip.positionYKeyframes,
      localTimeMs,
      clip.transform.y,
    );
    final scaleX = _evaluate(
      clip.scaleXKeyframes.isEmpty ? clip.scaleKeyframes : clip.scaleXKeyframes,
      localTimeMs,
      clip.transform.scaleX,
    );
    final scaleY = _evaluate(
      clip.scaleYKeyframes,
      localTimeMs,
      clip.transform.scaleY,
    );
    final rotation = _evaluate(
      clip.rotationKeyframes,
      localTimeMs,
      clip.transform.rotation,
    );
    return clip.transform.copyWith(
      x: positionX,
      y: positionY,
      scaleX: scaleX,
      scaleY: scaleY,
      rotation: rotation,
    );
  }


  Transform3D _evaluateTransform3D(TimelineClip clip, int localTimeMs) {
    final t = clip.transform3D;
    double eval(List<Keyframe> keys, double fallback) => _evaluate(keys, localTimeMs, fallback);
    return t.copyWith(
      x: eval(clip.positionXKeyframes, t.x),
      y: eval(clip.positionYKeyframes, t.y),
      z: eval(clip.positionZKeyframes, t.z),
      rotationX: eval(clip.rotationXKeyframes, t.rotationX),
      rotationY: eval(clip.rotationYKeyframes, t.rotationY),
      rotationZ: eval(clip.rotationZKeyframes, t.rotationZ),
      scale: eval(clip.scale3DKeyframes, t.scale),
      opacity: eval(clip.opacityKeyframes, t.opacity),
    );
  }

  double _evaluate(List<Keyframe> keyframes, int timeMs, double fallback) {
    if (keyframes.isEmpty) return fallback;
    final ordered = [...keyframes]
      ..sort((a, b) => a.timeMs.compareTo(b.timeMs));
    if (timeMs <= ordered.first.timeMs) return ordered.first.value;
    if (timeMs >= ordered.last.timeMs) return ordered.last.value;
    for (var i = 0; i < ordered.length - 1; i++) {
      final left = ordered[i];
      final right = ordered[i + 1];
      if (timeMs < left.timeMs || timeMs > right.timeMs) continue;
      final rawT = (timeMs - left.timeMs) / (right.timeMs - left.timeMs);
      final t = _interpolate(rawT, left.interpolation);
      return left.value + (right.value - left.value) * t;
    }
    return fallback;
  }

  double _interpolate(double t, Interpolation interpolation) =>
      switch (interpolation) {
        Interpolation.hold => 0,
        Interpolation.linear => t,
        Interpolation.easeIn => t * t,
        Interpolation.easeOut => 1 - (1 - t) * (1 - t),
        Interpolation.easeInOut =>
          t < .5 ? 2 * t * t : 1 - (-2 * t + 2) * (-2 * t + 2) / 2,
      };

  String? _visualSourcePath(MediaAsset? asset) {
    if (asset == null) return null;
    if (asset.proxyPath != null && File(asset.proxyPath!).existsSync()) {
      return asset.proxyPath;
    }
    if (File(asset.path).existsSync()) return asset.path;
    if (asset.sourcePath != null && File(asset.sourcePath!).existsSync()) {
      return asset.sourcePath;
    }
    return asset.path;
  }

  Model3DAsset? _model3d(Project project, String? id) => id == null ? null : project.model3dAssets.cast<Model3DAsset?>().firstWhere((asset) => asset?.id == id, orElse: () => null);

  MediaAsset? _asset(Project project, String id) => project.assets
      .cast<MediaAsset?>()
      .firstWhere((asset) => asset?.id == id, orElse: () => null);
}
