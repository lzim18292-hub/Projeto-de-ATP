import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';

class CacheService {
  CacheService({this.maxBytes = 512 * 1024 * 1024});
  final int maxBytes;

  Future<Directory> _directory() async {
    final base = await getTemporaryDirectory();
    final directory = Directory('${base.path}/openreel-cache');
    if (!directory.existsSync()) await directory.create(recursive: true);
    return directory;
  }

  Future<File?> get(String key, {String? sourcePath}) async {
    final directory = await _directory();
    final index = await _readIndex(directory);
    final entry = index[key];
    if (entry == null) return null;
    final file = File('${directory.path}/${entry['file']}');
    if (!file.existsSync() ||
        (sourcePath != null && !_sourceIsCurrent(entry, sourcePath))) {
      await invalidate(key);
      return null;
    }
    entry['lastAccess'] = DateTime.now().millisecondsSinceEpoch;
    await _writeIndex(directory, index);
    return file;
  }

  Future<File> put(String key, List<int> bytes, {String? sourcePath}) async {
    final directory = await _directory();
    final safeKey = base64Url.encode(utf8.encode(key)).replaceAll('=', '');
    final file = File('${directory.path}/$safeKey.bin');
    await file.writeAsBytes(bytes, flush: true);
    final index = await _readIndex(directory);
    index[key] = {
      'file': file.uri.pathSegments.last,
      'size': bytes.length,
      'lastAccess': DateTime.now().millisecondsSinceEpoch,
      'sourcePath': sourcePath,
      'sourceModified': sourcePath != null && File(sourcePath).existsSync()
          ? File(sourcePath).lastModifiedSync().millisecondsSinceEpoch
          : null,
    };
    await _writeIndex(directory, index);
    await trim();
    return file;
  }


  Future<File?> getOrCreateProxy(
    String sourcePath, {
    int width = 960,
    int height = 540,
    double maxSourceMb = 250,
  }) async {
    final source = File(sourcePath);
    if (!source.existsSync()) return null;
    if (await source.length() < maxSourceMb * 1024 * 1024) return null;
    final key = 'proxy:$sourcePath:$width:$height';
    final cached = await get(key, sourcePath: sourcePath);
    if (cached != null) return cached;
    final directory = await _directory();
    final safeKey = base64Url.encode(utf8.encode(key)).replaceAll('=', '');
    final output = File('${directory.path}/$safeKey.mp4');
    final command = [
      '-y', '-i', _quote(sourcePath), '-vf',
      'scale=$width:$height:force_original_aspect_ratio=decrease',
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '28',
      '-an', _quote(output.path),
    ].join(' ');
    bool success;
    if (Platform.isAndroid || Platform.isIOS) {
      final session = await FFmpegKit.execute(command);
      final code = await session.getReturnCode();
      success = ReturnCode.isSuccess(code);
    } else {
      final result = await Process.run('ffmpeg', [
        '-y', '-i', sourcePath, '-vf',
        'scale=$width:$height:force_original_aspect_ratio=decrease',
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '28',
        '-an', output.path,
      ]);
      success = result.exitCode == 0;
    }
    if (!success || !output.existsSync()) return null;
    final index = await _readIndex(directory);
    index[key] = {
      'file': output.uri.pathSegments.last,
      'size': await output.length(),
      'lastAccess': DateTime.now().millisecondsSinceEpoch,
      'sourcePath': sourcePath,
      'sourceModified': source.lastModifiedSync().millisecondsSinceEpoch,
    };
    await _writeIndex(directory, index);
    await trim();
    return output;
  }

  String _quote(String value) => '"${value.replaceAll('"', '\\"')}"';

  Future<void> invalidate(String key) async {
    final directory = await _directory();
    final index = await _readIndex(directory);
    final entry = index.remove(key);
    if (entry != null) {
      final file = File('${directory.path}/${entry['file']}');
      if (file.existsSync()) await file.delete();
      await _writeIndex(directory, index);
    }
  }

  Future<void> clear() async {
    final directory = await _directory();
    if (directory.existsSync()) {
      for (final entity in directory.listSync()) {
        if (entity is File) await entity.delete();
      }
    }
  }

  Future<void> trim() async {
    final directory = await _directory();
    final index = await _readIndex(directory);
    var total = index.values.fold<int>(
      0,
      (sum, value) => sum + ((value['size'] as num?)?.toInt() ?? 0),
    );
    final entries = index.entries.toList()
      ..sort(
        (a, b) => ((a.value['lastAccess'] as num?)?.toInt() ?? 0).compareTo(
          (b.value['lastAccess'] as num?)?.toInt() ?? 0,
        ),
      );
    for (final entry in entries) {
      if (total <= maxBytes) break;
      final file = File('${directory.path}/${entry.value['file']}');
      if (file.existsSync()) await file.delete();
      total -= (entry.value['size'] as num?)?.toInt() ?? 0;
      index.remove(entry.key);
    }
    await _writeIndex(directory, index);
  }

  bool _sourceIsCurrent(Map<String, dynamic> entry, String sourcePath) {
    final file = File(sourcePath);
    if (!file.existsSync()) return false;
    return entry['sourceModified'] ==
        file.lastModifiedSync().millisecondsSinceEpoch;
  }

  Future<Map<String, dynamic>> _readIndex(Directory directory) async {
    final file = File('${directory.path}/index.json');
    if (!file.existsSync()) return {};
    try {
      return (jsonDecode(await file.readAsString()) as Map).map(
        (key, value) =>
            MapEntry(key.toString(), (value as Map).cast<String, dynamic>()),
      );
    } catch (_) {
      if (file.existsSync()) await file.delete();
      return {};
    }
  }

  Future<void> _writeIndex(
    Directory directory,
    Map<String, dynamic> index,
  ) async {
    final file = File('${directory.path}/index.json');
    final temp = File('${file.path}.tmp');
    await temp.writeAsString(jsonEncode(index), flush: true);
    if (file.existsSync()) await file.delete();
    await temp.rename(file.path);
  }
}
