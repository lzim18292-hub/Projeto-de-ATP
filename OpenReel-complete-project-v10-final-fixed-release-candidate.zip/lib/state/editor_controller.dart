import 'dart:async';
import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../models/media_asset.dart';
import '../models/composition.dart';
import '../models/project.dart';
import '../models/timeline.dart';
import '../services/composition_engine.dart';
import '../services/export_service.dart';
import '../services/subtitle_service.dart';
import '../services/media_service.dart';
import '../services/project_repository.dart';
import '../services/cache_service.dart';

class EditorController extends ChangeNotifier {
  EditorController({
    ProjectRepository? repository,
    MediaService? mediaService,
    ExportService? exportService,
    CompositionEngine? compositionEngine,
    SubtitleService? subtitleService,
  }) : _repository = repository ?? ProjectRepository(),
       _mediaService = mediaService ?? MediaService(),
       _exportService = exportService ?? ExportService(),
       _compositionEngine = compositionEngine ?? CompositionEngine(),
       _subtitleService = subtitleService ?? SubtitleService() {
    _autosaveTimer = Timer.periodic(
      const Duration(seconds: 20),
      (_) => _autosave(),
    );
  }

  final ProjectRepository _repository;
  final MediaService _mediaService;
  final ExportService _exportService;
  final CompositionEngine _compositionEngine;
  final SubtitleService _subtitleService;
  final CacheService _cacheService = CacheService();
  final _uuid = const Uuid();
  late Timer _autosaveTimer;
  Project _project = Project(id: const Uuid().v4(), name: 'Projeto sem título');
  final List<String> _undoStack = [];
  final List<String> _redoStack = [];
  final List<TimelineClip> _clipboard = [];
  String? selectedClipId;
  final Set<String> selectedClipIds = <String>{};
  String? selectedAssetId;
  String? selectedTrackId;
  int playheadMs = 0;
  double zoom = 0.08;
  bool isBusy = false;
  String status = 'Pronto';
  double exportProgress = 0;
  String? error;

  Project get project => _project;
  CompositionFrame get composition =>
      _compositionEngine.compose(_project, playheadMs);
  void refresh() => notifyListeners();
  List<TimelineTrack> get tracks => _project.tracks;
  List<MediaAsset> get assets => _project.assets;
  TimelineClip? get selectedClip {
    for (final track in tracks) {
      for (final clip in track.clips) {
        if (clip.id == selectedClipId) return clip;
      }
    }
    return null;
  }

  TimelineClip? get activeClip {
    final candidates =
        tracks
            .expand((track) => track.clips)
            .where(
              (clip) => clip.startMs <= playheadMs && playheadMs < clip.endMs,
            )
            .toList()
          ..sort((a, b) => a.trackId.compareTo(b.trackId));
    return candidates.isEmpty ? null : candidates.first;
  }

  int get timelineDurationMs => _project.durationMs;

  Future<void> importMedia() async {
    final result = await FilePicker.pickFiles(
      allowMultiple: true,
      type: FileType.any,
    );
    if (result.isEmpty) return;
    isBusy = true;
    error = null;
    status = 'Analisando mídia…';
    notifyListeners();
    try {
      _checkpoint();
      for (final file in result) {
        final path = file.path;
        if (path == null) continue;
        final inspected = await _mediaService.inspect(path);
        final durable = await _mediaService.persist(inspected);
        var asset = await _mediaService.prepare(durable);
        if (asset.kind == MediaKind.video) {
          final proxy = await _cacheService.getOrCreateProxy(asset.path);
          if (proxy != null) asset = asset.copyWith(proxyPath: proxy.path);
        }
        _project.assets.add(asset);
        selectedAssetId = asset.id;
        final targetKind = asset.kind == MediaKind.audio
            ? TrackKind.audio
            : TrackKind.video;
        final track = _ensureTrack(targetKind);
        final start = _endOfTrack(track);
        final duration = asset.durationMs > 0 ? asset.durationMs : 5000;
        track.clips.add(
          TimelineClip(
            id: _uuid.v4(),
            assetId: asset.id,
            trackId: track.id,
            startMs: start,
            durationMs: duration,
          ),
        );
      }
      _recalculateDuration();
      status = 'Mídia importada';
      await _autosave();
    } catch (e) {
      _undoStack.removeLastOrNull();
      error = e.toString();
      status = 'Falha na importação';
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<void> importSubtitles() async {
    final result = await FilePicker.pickFiles(
      allowMultiple: false,
      type: FileType.custom,
      allowedExtensions: ['srt', 'vtt'],
    );
    if (result.isEmpty || result.single.path == null) return;
    final path = result.single.path!;
    isBusy = true;
    error = null;
    status = 'Importando legendas…';
    notifyListeners();
    try {
      final cues = await _subtitleService.parseFile(path);
      if (cues.isEmpty) throw StateError('Nenhuma legenda válida encontrada.');
      _checkpoint();
      _project.subtitleCues
        ..clear()
        ..addAll(cues);
      final track = _ensureTrack(TrackKind.subtitle);
      track.clips
        ..clear()
        ..addAll(
          cues.map(
            (cue) => TimelineClip(
              id: _uuid.v4(),
              assetId: 'subtitle:${_uuid.v4()}',
              trackId: track.id,
              startMs: cue.startMs,
              durationMs: cue.endMs - cue.startMs,
              text: cue.text,
              textStyle: TextStyleConfig(
                fontFamily: cue.style.fontFamily,
                fontSize: cue.style.fontSize,
                color: cue.style.color,
                outlineColor: cue.style.outlineColor,
                outlineWidth: cue.style.outlineWidth,
                background: cue.style.background,
              ),
              transform: Transform2D(
                x: cue.style.x * _project.width,
                y: cue.style.y * _project.height,
              ),
            ),
          ),
        );
      _recalculateDuration();
      await _autosave();
      status = 'Legendas importadas (${cues.length})';
    } catch (e) {
      error = e.toString();
      status = 'Falha ao importar legendas';
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<void> newProject() async {
    _checkpoint();
    _project = Project(id: _uuid.v4(), name: 'Projeto sem título');
    selectedClipId = null;
    selectedClipIds.clear();
    selectedAssetId = null;
    playheadMs = 0;
    status = 'Novo projeto';
    notifyListeners();
  }

  Future<void> save() async {
    await _repository.save(_project);
    status = 'Salvo agora';
    notifyListeners();
  }

  Future<void> saveAs(String name) async {
    _checkpoint();
    _project.name = name.trim().isEmpty ? 'Projeto sem título' : name.trim();
    await save();
  }

  Future<void> load(String id) async {
    final project = await _repository.load(id);
    if (project == null) return;
    _project = project;
    selectedClipId = null;
    selectedClipIds.clear();
    selectedAssetId = null;
    playheadMs = 0;
    status = 'Projeto aberto';
    notifyListeners();
  }

  Future<void> duplicateProject() async {
    final copy = Project.fromJson(
      jsonDecode(_project.encode()) as Map<String, dynamic>,
    );
    copy.name = '${copy.name} (cópia)';
    final duplicate = Project(
      id: _uuid.v4(),
      name: copy.name,
      width: copy.width,
      height: copy.height,
      fps: copy.fps,
      durationMs: copy.durationMs,
      assets: copy.assets,
      tracks: copy.tracks,
      markers: copy.markers,
      subtitleCues: copy.subtitleCues.map((cue) => cue.copy()).toList(),
      model3dAssets: copy.model3dAssets.toList(),
      exportSettings: copy.exportSettings,
    );
    await _repository.save(duplicate);
    status = 'Projeto duplicado';
    notifyListeners();
  }

  Future<void> deleteProject(String id) async {
    await _repository.delete(id);
    if (id == _project.id) await newProject();
    status = 'Projeto excluído';
    notifyListeners();
  }

  Future<void> cancelExport() async {
    await _exportService.cancel();
    status = 'Cancelando exportação…';
    notifyListeners();
  }

  Future<List<ProjectSummary>> listProjects() => _repository.list();

  Future<bool> hasAutosave(String id) => _repository.hasAutosave(id);

  Future<bool> recoverAutosave(String id) async {
    final recovered = await _repository.recoverAutosave(id);
    if (recovered == null) return false;
    _project = recovered;
    selectedClipId = null;
    selectedClipIds.clear();
    selectedAssetId = null;
    playheadMs = 0;
    status = 'Autosave recuperado';
    notifyListeners();
    return true;
  }

  void selectClip(String id, {bool additive = false}) {
    if (additive) {
      if (selectedClipIds.contains(id)) {
        selectedClipIds.remove(id);
      } else {
        selectedClipIds.add(id);
      }
      selectedClipId = selectedClipIds.isEmpty ? null : id;
    } else {
      selectedClipIds
        ..clear()
        ..add(id);
      selectedClipId = id;
    }
    selectedAssetId = _findClip(id)?.assetId;
    notifyListeners();
  }

  bool isClipSelected(String id) => selectedClipIds.contains(id);

  void selectAsset(String id) {
    selectedAssetId = id;
    notifyListeners();
  }

  void setPlayhead(int milliseconds) {
    playheadMs = milliseconds.clamp(0, timelineDurationMs);
    notifyListeners();
  }

  void setZoom(double value) {
    zoom = value.clamp(0.02, 0.4);
    notifyListeners();
  }

  void updateProjectSettings({required int width, required int height, required int fps}) {
    if (width < 240 || height < 240 || fps < 1) return;
    _checkpoint();
    _project.width = width;
    _project.height = height;
    _project.fps = fps;
    _project.exportSettings = _project.exportSettings.copyWith(
      width: width,
      height: height,
      fps: fps,
    );
    status = 'Configurações atualizadas';
    notifyListeners();
  }

  void splitSelected() {
    final clip = selectedClip;
    if (clip == null || playheadMs <= clip.startMs || playheadMs >= clip.endMs)
      return;
    final track = _trackFor(clip.trackId);
    if (track == null || track.locked) return;
    _checkpoint();
    final splitLocal = playheadMs - clip.startMs;
    final right = clip.clone(id: _uuid.v4(), startMs: playheadMs);
    right.sourceStartMs += (splitLocal * clip.speed).round();
    right.durationMs = clip.endMs - playheadMs;
    right.shiftKeyframes(-splitLocal);
    clip.durationMs = splitLocal;
    clip.trimKeyframesToDuration();
    track.clips.add(right);
    selectedClipId = right.id;
    _recalculateDuration();
    status = 'Clipe dividido';
    notifyListeners();
  }

  void deleteSelected({bool ripple = false}) {
    final clip = selectedClip;
    if (clip == null) return;
    final track = _trackFor(clip.trackId);
    if (track == null || track.locked) return;
    _checkpoint();
    track.clips.removeWhere((item) => item.id == clip.id);
    if (ripple) {
      for (final other in track.clips.where(
        (item) => item.startMs > clip.startMs,
      )) {
        other.startMs -= clip.durationMs;
      }
    }
    selectedClipId = null;
    _recalculateDuration();
    status = ripple ? 'Clipe removido com ripple' : 'Clipe removido';
    notifyListeners();
  }

  void copySelected() {
    final clip = selectedClip;
    if (clip == null) return;
    _clipboard
      ..clear()
      ..add(clip.clone(id: clip.id));
    status = 'Clipe copiado';
    notifyListeners();
  }

  void pasteClipboard() {
    if (_clipboard.isEmpty) return;
    final source = _clipboard.first;
    final track = _trackFor(source.trackId) ?? _ensureTrack(TrackKind.video);
    if (track.locked) return;
    _checkpoint();
    final pasted = source.clone(id: _uuid.v4(), startMs: playheadMs);
    track.clips.add(pasted);
    selectedClipId = pasted.id;
    _recalculateDuration();
    status = 'Clipe colado';
    notifyListeners();
  }

  void toggleMarkerAtPlayhead() {
    _checkpoint();
    if (_project.markers.contains(playheadMs)) {
      _project.markers.remove(playheadMs);
    } else {
      _project.markers.add(playheadMs);
      _project.markers.sort();
    }
    notifyListeners();
  }

  void duplicateSelected() {
    final clip = selectedClip;
    if (clip == null) return;
    final track = _trackFor(clip.trackId);
    if (track == null || track.locked) return;
    _checkpoint();
    final duplicate = clip.clone(id: _uuid.v4(), startMs: clip.endMs);
    track.clips.add(duplicate);
    selectedClipId = duplicate.id;
    _recalculateDuration();
    notifyListeners();
  }

  void trimStartSelected() {
    final clip = selectedClip;
    if (clip == null || playheadMs <= clip.startMs || playheadMs >= clip.endMs)
      return;
    _checkpoint();
    clip.trimLeft(playheadMs - clip.startMs);
    _recalculateDuration();
    notifyListeners();
  }

  void trimEndSelected() {
    final clip = selectedClip;
    if (clip == null || playheadMs <= clip.startMs || playheadMs >= clip.endMs)
      return;
    _checkpoint();
    clip.trimRight(clip.endMs - playheadMs);
    _recalculateDuration();
    notifyListeners();
  }

  void trimSelectedToStart(int newStartMs, {bool checkpoint = true}) {
    final clip = selectedClip;
    if (clip == null) return;
    final track = _trackFor(clip.trackId);
    if (track == null || track.locked) return;
    final target = newStartMs.clamp(clip.startMs, clip.endMs - 1);
    if (target == clip.startMs) return;
    if (checkpoint) _checkpoint();
    clip.trimLeft(target - clip.startMs);
    _recalculateDuration();
    notifyListeners();
  }

  void trimSelectedToEnd(int newEndMs, {bool checkpoint = true}) {
    final clip = selectedClip;
    if (clip == null) return;
    final track = _trackFor(clip.trackId);
    if (track == null || track.locked) return;
    final target = newEndMs.clamp(clip.startMs + 1, clip.endMs);
    if (target == clip.endMs) return;
    if (checkpoint) _checkpoint();
    clip.trimRight(clip.endMs - target);
    _recalculateDuration();
    notifyListeners();
  }

  void setTransform({double? x, double? y, double? scaleX, double? scaleY, double? rotation}) {
    final clip = selectedClip;
    if (clip == null) return;
    _checkpoint();
    clip.transform = clip.transform.copyWith(
      x: x, y: y, scaleX: scaleX, scaleY: scaleY, rotation: rotation,
    );
    notifyListeners();
  }

  void setOpacity(double value) {
    final clip = selectedClip;
    if (clip == null) return;
    _checkpoint();
    clip.opacity = value.clamp(0, 1).toDouble();
    notifyListeners();
  }

  void setVolume(double value) {
    final clip = selectedClip;
    if (clip == null) return;
    _checkpoint();
    clip.volume = value.clamp(0, 1).toDouble();
    notifyListeners();
  }

  void toggleSelectedMute() {
    final clip = selectedClip;
    if (clip == null) return;
    _checkpoint();
    clip.muted = !clip.muted;
    notifyListeners();
  }

  void setSpeed(double speed) {
    final clip = selectedClip;
    if (clip == null || speed <= 0) return;
    _checkpoint();
    final sourceDuration = clip.durationMs * clip.speed;
    clip.speed = speed;
    clip.durationMs = (sourceDuration / speed).round().clamp(
      1,
      24 * 60 * 60 * 1000,
    );
    _recalculateDuration();
    notifyListeners();
  }

  void toggleTrackLock(String id) {
    final track = _trackFor(id);
    if (track == null) return;
    _checkpoint();
    track.locked = !track.locked;
    notifyListeners();
  }

  void toggleTrackVisibility(String id) {
    final track = _trackFor(id);
    if (track == null) return;
    _checkpoint();
    track.hidden = !track.hidden;
    notifyListeners();
  }

  void moveClip(String id, int newStartMs, {bool checkpoint = true}) {
    final clip = _findClip(id);
    if (clip == null) return;
    final track = _trackFor(clip.trackId);
    if (track == null || track.locked) return;
    if (checkpoint) _checkpoint();
    final snapped = (newStartMs / 100).round() * 100;
    clip.startMs = snapped.clamp(0, 24 * 60 * 60 * 1000);
    _recalculateDuration();
    notifyListeners();
  }

  void addText(String text) {
    if (text.trim().isEmpty) return;
    _checkpoint();
    final track = _ensureTrack(TrackKind.overlay);
    final clip = TimelineClip(
      id: _uuid.v4(),
      assetId: 'text:${_uuid.v4()}',
      trackId: track.id,
      startMs: playheadMs,
      durationMs: 3000,
      text: text.trim(),
    );
    track.clips.add(clip);
    selectedClipId = clip.id;
    _recalculateDuration();
    notifyListeners();
  }

  void setTransitionIn(TransitionConfig transition) {
    final clip = selectedClip;
    if (clip == null) return;
    _checkpoint();
    clip.transitionIn = transition;
    notifyListeners();
  }

  void setTransitionOut(TransitionConfig transition) {
    final clip = selectedClip;
    if (clip == null) return;
    _checkpoint();
    clip.transitionOut = transition;
    notifyListeners();
  }

  void addEffect(EffectConfig effect) {
    final clip = selectedClip;
    if (clip == null) return;
    _checkpoint();
    clip.effects = [...clip.effects, effect];
    notifyListeners();
  }

  void addKeyframe({required String property, required double value}) {
    final clip = selectedClip;
    if (clip == null) return;
    _checkpoint();
    final keyframe = Keyframe(
      timeMs: (playheadMs - clip.startMs).clamp(0, clip.durationMs),
      value: value,
    );
    switch (property) {
      case 'opacity':
        clip.opacityKeyframes = [...clip.opacityKeyframes, keyframe];
      case 'scale':
        clip.scaleKeyframes = [...clip.scaleKeyframes, keyframe];
      case 'scaleX':
        clip.scaleXKeyframes = [...clip.scaleXKeyframes, keyframe];
      case 'scaleY':
        clip.scaleYKeyframes = [...clip.scaleYKeyframes, keyframe];
      case 'rotation':
        clip.rotationKeyframes = [...clip.rotationKeyframes, keyframe];
      case 'volume':
        clip.volumeKeyframes = [...clip.volumeKeyframes, keyframe];
      case 'position':
        clip.positionKeyframes = [...clip.positionKeyframes, keyframe];
      case 'positionX':
        clip.positionXKeyframes = [...clip.positionXKeyframes, keyframe];
      case 'positionY':
        clip.positionYKeyframes = [...clip.positionYKeyframes, keyframe];
    }
    notifyListeners();
  }

  Future<void> export() async {
    final directory = await getApplicationDocumentsDirectory();
    final path =
        '${directory.path}/${_project.name.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_')}_${DateTime.now().millisecondsSinceEpoch}.mp4';
    await exportTo(path);
  }

  Future<void> exportTo(String path) async {
    isBusy = true;
    error = null;
    exportProgress = 0;
    status = 'Exportando…';
    notifyListeners();
    try {
      await _exportService.export(
        _project,
        path,
        onProgress: (progress) {
          exportProgress = progress.fraction;
          status = progress.message;
          notifyListeners();
        },
      );
      status = 'Exportado: $path';
    } catch (e) {
      error = e.toString();
      status = 'Falha na exportação';
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  void undo() {
    if (_undoStack.isEmpty) return;
    _redoStack.add(_project.encode());
    _project = Project.fromJson(
      jsonDecode(_undoStack.removeLast()) as Map<String, dynamic>,
    );
    notifyListeners();
  }

  void redo() {
    if (_redoStack.isEmpty) return;
    _undoStack.add(_project.encode());
    _project = Project.fromJson(
      jsonDecode(_redoStack.removeLast()) as Map<String, dynamic>,
    );
    notifyListeners();
  }

  Future<void> _autosave() async {
    if (!isBusy) {
      try {
        await _repository.autosave(_project);
      } catch (_) {
        // Autosave não interrompe a edição.
      }
    }
  }

  void _checkpoint() {
    _undoStack.add(_project.encode());
    if (_undoStack.length > 50) _undoStack.removeAt(0);
    _redoStack.clear();
  }

  TimelineClip? _findClip(String id) {
    for (final track in tracks) {
      for (final clip in track.clips) {
        if (clip.id == id) return clip;
      }
    }
    return null;
  }

  TimelineTrack? _trackFor(String id) => tracks
      .cast<TimelineTrack?>()
      .firstWhere((track) => track?.id == id, orElse: () => null);

  TimelineTrack _ensureTrack(TrackKind kind) {
    final existing = tracks.cast<TimelineTrack?>().firstWhere(
      (track) => track?.kind == kind && track?.id != 'subtitle-1',
      orElse: () => null,
    );
    if (existing != null) return existing;
    final track = TimelineTrack(
      id: '${kind.name}-${_uuid.v4()}',
      name: '${kind.name} ${tracks.length + 1}',
      kind: kind,
    );
    tracks.add(track);
    return track;
  }

  int _endOfTrack(TimelineTrack track) =>
      track.clips.fold(0, (max, clip) => clip.endMs > max ? clip.endMs : max);

  void _recalculateDuration() {
    _project.durationMs = tracks
        .where((track) => !track.hidden)
        .expand((track) => track.clips)
        .where((clip) => clip.enabled)
        .fold(0, (max, clip) => clip.endMs > max ? clip.endMs : max);
  }

  @override
  void dispose() {
    _autosaveTimer.cancel();
    super.dispose();
  }
}

extension<T> on List<T> {
  T? removeLastOrNull() {
    if (isEmpty) return null;
    return removeLast();
  }
}
