import 'dart:convert';

import 'media_asset.dart';
import 'timeline.dart';
import 'model3d.dart';
import '../services/subtitle_service.dart';

class ExportSettings {
  const ExportSettings({
    this.width = 1920,
    this.height = 1080,
    this.fps = 30,
    this.videoCodec = 'libx264',
    this.audioCodec = 'aac',
    this.bitrate = 8000000,
    this.crf = 18,
    this.container = 'mp4',
  });

  final int width;
  final int height;
  final int fps;
  final String videoCodec;
  final String audioCodec;
  final int bitrate;
  final int crf;
  final String container;

  ExportSettings copyWith({
    int? width,
    int? height,
    int? fps,
    String? videoCodec,
    String? audioCodec,
    int? bitrate,
    int? crf,
    String? container,
  }) => ExportSettings(
    width: width ?? this.width,
    height: height ?? this.height,
    fps: fps ?? this.fps,
    videoCodec: videoCodec ?? this.videoCodec,
    audioCodec: audioCodec ?? this.audioCodec,
    bitrate: bitrate ?? this.bitrate,
    crf: crf ?? this.crf,
    container: container ?? this.container,
  );

  Map<String, dynamic> toJson() => {
    'width': width,
    'height': height,
    'fps': fps,
    'videoCodec': videoCodec,
    'audioCodec': audioCodec,
    'bitrate': bitrate,
    'crf': crf,
    'container': container,
  };

  factory ExportSettings.fromJson(Map<String, dynamic> json) => ExportSettings(
    width: (json['width'] as num?)?.toInt() ?? 1920,
    height: (json['height'] as num?)?.toInt() ?? 1080,
    fps: (json['fps'] as num?)?.toInt() ?? 30,
    videoCodec: json['videoCodec'] as String? ?? 'libx264',
    audioCodec: json['audioCodec'] as String? ?? 'aac',
    bitrate: (json['bitrate'] as num?)?.toInt() ?? 8000000,
    crf: (json['crf'] as num?)?.toInt() ?? 18,
    container: json['container'] as String? ?? 'mp4',
  );
}

class Project {
  Project({
    required this.id,
    required this.name,
    this.width = 1920,
    this.height = 1080,
    this.fps = 30,
    this.durationMs = 0,
    List<MediaAsset>? assets,
    List<TimelineTrack>? tracks,
    List<int>? markers,
    List<SubtitleCue>? subtitleCues,
    List<Model3DAsset>? model3dAssets,
    ExportSettings? exportSettings,
  }) : assets = assets ?? [],
       tracks =
           tracks ??
           [
             TimelineTrack(
               id: 'video-1',
               name: 'Vídeo 1',
               kind: TrackKind.video,
             ),
             TimelineTrack(
               id: 'audio-1',
               name: 'Áudio 1',
               kind: TrackKind.audio,
             ),
           ],
       markers = markers ?? [],
       subtitleCues = subtitleCues ?? [],
       model3dAssets = model3dAssets ?? [],
       exportSettings = exportSettings ?? const ExportSettings();

  final String id;
  String name;
  int width;
  int height;
  int fps;
  int durationMs;
  final List<MediaAsset> assets;
  final List<TimelineTrack> tracks;
  final List<int> markers;
  final List<SubtitleCue> subtitleCues;
  final List<Model3DAsset> model3dAssets;
  ExportSettings exportSettings;

  Map<String, dynamic> toJson() => {
    'schemaVersion': 3,
    'id': id,
    'name': name,
    'width': width,
    'height': height,
    'fps': fps,
    'durationMs': durationMs,
    'assets': assets.map((a) => a.toJson()).toList(),
    'tracks': tracks.map((t) => t.toJson()).toList(),
    'markers': markers,
    'subtitleCues': subtitleCues.map((cue) => cue.toJson()).toList(),
    'model3dAssets': model3dAssets.map((asset) => asset.toJson()).toList(),
    'exportSettings': exportSettings.toJson(),
  };

  String encode() => const JsonEncoder.withIndent('  ').convert(toJson());

  factory Project.fromJson(Map<String, dynamic> json) => Project(
    id: json['id'] as String,
    name: json['name'] as String,
    width: (json['width'] as num?)?.toInt() ?? 1920,
    height: (json['height'] as num?)?.toInt() ?? 1080,
    fps: (json['fps'] as num?)?.toInt() ?? 30,
    durationMs: (json['durationMs'] as num?)?.toInt() ?? 0,
    assets: ((json['assets'] as List?) ?? [])
        .map((a) => MediaAsset.fromJson((a as Map).cast<String, dynamic>()))
        .toList(),
    tracks: ((json['tracks'] as List?) ?? [])
        .map((t) => TimelineTrack.fromJson((t as Map).cast<String, dynamic>()))
        .toList(),
    markers: ((json['markers'] as List?) ?? [])
        .map((m) => (m as num).toInt())
        .toList(),
    subtitleCues: ((json['subtitleCues'] as List?) ?? [])
        .map((cue) => SubtitleCue.fromJson((cue as Map).cast<String, dynamic>()))
        .toList(),
    model3dAssets: ((json['model3dAssets'] as List?) ?? [])
        .map((asset) => Model3DAsset.fromJson((asset as Map).cast<String, dynamic>()))
        .toList(),
    exportSettings: ExportSettings.fromJson(
      (json['exportSettings'] as Map?)?.cast<String, dynamic>() ?? {},
    ),
  );
}
