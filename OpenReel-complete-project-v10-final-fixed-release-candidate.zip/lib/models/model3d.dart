
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'dart:typed_data';

class Model3DAsset {
  Model3DAsset({
    required this.id,
    required this.path,
    required this.name,
    this.origin = '',
    this.author = '',
    this.license = '',
    this.sourceUrl = '',
    this.format = 'glb',
    this.fileSizeBytes = 0,
    this.animationCount = 0,
    this.nodeCount = 0,
  });

  final String id;
  final String path;
  final String name;
  String origin;
  String author;
  String license;
  String sourceUrl;
  final String format;
  final int fileSizeBytes;
  final int animationCount;
  final int nodeCount;

  Map<String, dynamic> toJson() => {
    'id': id, 'path': path, 'name': name, 'origin': origin, 'author': author,
    'license': license, 'sourceUrl': sourceUrl, 'format': format,
    'fileSizeBytes': fileSizeBytes, 'animationCount': animationCount,
    'nodeCount': nodeCount,
  };

  factory Model3DAsset.fromJson(Map<String, dynamic> json) => Model3DAsset(
    id: json['id'] as String,
    path: json['path'] as String,
    name: json['name'] as String,
    origin: json['origin'] as String? ?? '',
    author: json['author'] as String? ?? '',
    license: json['license'] as String? ?? '',
    sourceUrl: json['sourceUrl'] as String? ?? '',
    format: json['format'] as String? ?? 'glb',
    fileSizeBytes: (json['fileSizeBytes'] as num?)?.toInt() ?? 0,
    animationCount: (json['animationCount'] as num?)?.toInt() ?? 0,
    nodeCount: (json['nodeCount'] as num?)?.toInt() ?? 0,
  );

  String encode() => jsonEncode(toJson());
}

class Transform3D {
  const Transform3D({
    this.x = 0, this.y = 0, this.z = 0,
    this.rotationX = 0, this.rotationY = 0, this.rotationZ = 0,
    this.scale = 1, this.opacity = 1,
  });
  final double x, y, z, rotationX, rotationY, rotationZ, scale, opacity;

  Transform3D copyWith({
    double? x, double? y, double? z, double? rotationX, double? rotationY,
    double? rotationZ, double? scale, double? opacity,
  }) => Transform3D(
    x: x ?? this.x, y: y ?? this.y, z: z ?? this.z,
    rotationX: rotationX ?? this.rotationX, rotationY: rotationY ?? this.rotationY,
    rotationZ: rotationZ ?? this.rotationZ, scale: scale ?? this.scale,
    opacity: opacity ?? this.opacity,
  );

  Map<String, dynamic> toJson() => {
    'x': x, 'y': y, 'z': z, 'rotationX': rotationX, 'rotationY': rotationY,
    'rotationZ': rotationZ, 'scale': scale, 'opacity': opacity,
  };
  factory Transform3D.fromJson(Map<String, dynamic> json) => Transform3D(
    x: (json['x'] as num?)?.toDouble() ?? 0,
    y: (json['y'] as num?)?.toDouble() ?? 0,
    z: (json['z'] as num?)?.toDouble() ?? 0,
    rotationX: (json['rotationX'] as num?)?.toDouble() ?? 0,
    rotationY: (json['rotationY'] as num?)?.toDouble() ?? 0,
    rotationZ: (json['rotationZ'] as num?)?.toDouble() ?? 0,
    scale: (json['scale'] as num?)?.toDouble() ?? 1,
    opacity: (json['opacity'] as num?)?.toDouble() ?? 1,
  );
}

class Model3DValidation {
  const Model3DValidation({required this.valid, required this.message, this.format});
  final bool valid;
  final String message;
  final String? format;
}

class Model3DService {
  Future<Model3DValidation> validateFile(String path) async {
    final file = File(path);
    if (!await file.exists()) return const Model3DValidation(valid: false, message: 'Arquivo 3D não encontrado.');
    final ext = path.split('.').last.toLowerCase();
    if (ext != 'glb' && ext != 'gltf') {
      return const Model3DValidation(valid: false, message: 'Somente GLB e GLTF são suportados.');
    }
    if (ext == 'glb') {
      final bytes = await file.openRead(0, 12).fold<List<int>>([], (a, b) => a..addAll(b));
      if (bytes.length < 12 || bytes[0] != 0x67 || bytes[1] != 0x6c || bytes[2] != 0x54 || bytes[3] != 0x46) {
        return const Model3DValidation(valid: false, message: 'Cabeçalho GLB inválido.');
      }
      final version = ByteData.sublistView(Uint8List.fromList(bytes)).getUint32(4, Endian.little);
      if (version != 2) return Model3DValidation(valid: false, message: 'GLB versão $version não suportada.', format: 'glb');
    } else {
      try {
        final text = await file.readAsString();
        final json = jsonDecode(text);
        if (json is! Map || json['asset'] is! Map) throw const FormatException();
        final version = (json['asset'] as Map)['version']?.toString() ?? '';
        if (!version.startsWith('2')) {
          return Model3DValidation(valid: false, message: 'GLTF versão $version não suportada.', format: 'gltf');
        }
      } catch (_) {
        return const Model3DValidation(valid: false, message: 'GLTF inválido ou ilegível.', format: 'gltf');
      }
    }
    return Model3DValidation(valid: true, message: 'Modelo válido.', format: ext);
  }

  Future<Model3DAsset> inspect({
    required String id,
    required String path,
    required String name,
    String origin = '',
    String author = '',
    String license = '',
    String sourceUrl = '',
  }) async {
    final validation = await validateFile(path);
    if (!validation.valid) throw StateError(validation.message);
    final file = File(path);
    var animations = 0, nodes = 0;
    if (validation.format == 'gltf') {
      final json = jsonDecode(await file.readAsString()) as Map;
      animations = (json['animations'] as List?)?.length ?? 0;
      nodes = (json['nodes'] as List?)?.length ?? 0;
    } else {
      final bytes = await file.readAsBytes();
      if (bytes.length >= 20) {
        final jsonLength = ByteData.sublistView(Uint8List.fromList(bytes.sublist(12, 20))).getUint32(0, Endian.little);
        if (jsonLength > 0 && 20 + jsonLength <= bytes.length) {
          try {
            final json = jsonDecode(String.fromCharCodes(bytes.sublist(20, 20 + jsonLength))) as Map;
            animations = (json['animations'] as List?)?.length ?? 0;
            nodes = (json['nodes'] as List?)?.length ?? 0;
          } catch (_) {}
        }
      }
    }
    return Model3DAsset(
      id: id, path: path, name: name, origin: origin, author: author,
      license: license, sourceUrl: sourceUrl, format: validation.format!,
      fileSizeBytes: await file.length(), animationCount: animations, nodeCount: nodes,
    );
  }

  Future<String> persistFile(String path, String id) async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory('${root.path}/OpenReel/models3d/$id');
    if (!dir.existsSync()) await dir.create(recursive: true);
    final source = File(path);
    if (!source.existsSync()) {
      throw StateError('Modelo 3D não está acessível: $path');
    }
    final ext = path.toLowerCase().endsWith('.gltf') ? '.gltf' : '.glb';
    final destination = File('${dir.path}$ext');
    if (ext == '.glb') {
      await source.copy(destination.path);
      return destination.path;
    }

    // GLTF may reference external .bin/textures. Keep the complete local
    // resource graph together so reopening a project remains deterministic.
    final json = jsonDecode(await source.readAsString());
    if (json is! Map) throw const FormatException('GLTF JSON inválido.');
    final uris = <String>{};
    void collectUris(dynamic value) {
      if (value is Map) {
        for (final entry in value.entries) {
          if (entry.key == 'uri' && entry.value is String) {
            final uri = entry.value as String;
            if (!uri.startsWith('data:') && !uri.startsWith('http://') && !uri.startsWith('https://')) {
              uris.add(uri);
            }
          }
          collectUris(entry.value);
        }
      } else if (value is List) {
        for (final item in value) collectUris(item);
      }
    }
    collectUris(json);
    final sourceDir = source.parent;
    for (final uri in uris) {
      final decoded = Uri.decodeComponent(uri);
      final resource = File('${sourceDir.path}/$decoded');
      if (!resource.existsSync()) {
        throw StateError('Recurso externo do GLTF não encontrado: $decoded');
      }
      final relative = decoded.replaceAll('\\', '/');
      final target = File('${dir.path}/$relative');
      await target.parent.create(recursive: true);
      await resource.copy(target.path);
    }
    await source.copy(destination.path);
    return destination.path;
  }
}
