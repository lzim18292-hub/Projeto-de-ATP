import 'dart:math' as math;

import 'model3d.dart';

enum TrackKind { video, audio, overlay, subtitle, object3d }

enum BlendMode { normal, screen, multiply, overlay, add }

enum Interpolation { hold, linear, easeIn, easeOut, easeInOut }

class Keyframe {
  const Keyframe({
    required this.timeMs,
    required this.value,
    this.interpolation = Interpolation.linear,
  });

  final int timeMs;
  final double value;
  final Interpolation interpolation;

  Map<String, dynamic> toJson() => {
    'timeMs': timeMs,
    'value': value,
    'interpolation': interpolation.name,
  };

  factory Keyframe.fromJson(Map<String, dynamic> json) => Keyframe(
    timeMs: (json['timeMs'] as num).toInt(),
    value: (json['value'] as num).toDouble(),
    interpolation: Interpolation.values.byName(
      json['interpolation'] as String? ?? 'linear',
    ),
  );
}

class Transform2D {
  const Transform2D({
    this.x = 0,
    this.y = 0,
    this.scaleX = 1,
    this.scaleY = 1,
    this.rotation = 0,
  });

  final double x;
  final double y;
  final double scaleX;
  final double scaleY;
  final double rotation;

  Transform2D copyWith({
    double? x,
    double? y,
    double? scaleX,
    double? scaleY,
    double? rotation,
  }) => Transform2D(
    x: x ?? this.x,
    y: y ?? this.y,
    scaleX: scaleX ?? this.scaleX,
    scaleY: scaleY ?? this.scaleY,
    rotation: rotation ?? this.rotation,
  );

  Map<String, dynamic> toJson() => {
    'x': x,
    'y': y,
    'scaleX': scaleX,
    'scaleY': scaleY,
    'rotation': rotation,
  };
  factory Transform2D.fromJson(Map<String, dynamic> json) => Transform2D(
    x: (json['x'] as num?)?.toDouble() ?? 0,
    y: (json['y'] as num?)?.toDouble() ?? 0,
    scaleX: (json['scaleX'] as num?)?.toDouble() ?? 1,
    scaleY: (json['scaleY'] as num?)?.toDouble() ?? 1,
    rotation: (json['rotation'] as num?)?.toDouble() ?? 0,
  );
}

class EffectConfig {
  const EffectConfig({required this.type, this.parameters = const {}});
  final String type;
  final Map<String, double> parameters;

  Map<String, dynamic> toJson() => {'type': type, 'parameters': parameters};
  factory EffectConfig.fromJson(Map<String, dynamic> json) => EffectConfig(
    type: json['type'] as String,
    parameters:
        (json['parameters'] as Map?)?.map(
          (key, value) => MapEntry(key.toString(), (value as num).toDouble()),
        ) ??
        {},
  );
}


class TextStyleConfig {
  const TextStyleConfig({
    this.fontFamily = 'sans-serif',
    this.fontSize = 48,
    this.fontWeight = 700,
    this.color = 'white',
    this.opacity = 1,
    this.align = 'center',
    this.background = 'transparent',
    this.outlineColor = 'black',
    this.outlineWidth = 2,
    this.shadowBlur = 0,
  });

  final String fontFamily;
  final double fontSize;
  final int fontWeight;
  final String color;
  final double opacity;
  final String align;
  final String background;
  final String outlineColor;
  final double outlineWidth;
  final double shadowBlur;

  Map<String, dynamic> toJson() => {
    'fontFamily': fontFamily,
    'fontSize': fontSize,
    'fontWeight': fontWeight,
    'color': color,
    'opacity': opacity,
    'align': align,
    'background': background,
    'outlineColor': outlineColor,
    'outlineWidth': outlineWidth,
    'shadowBlur': shadowBlur,
  };

  factory TextStyleConfig.fromJson(Map<String, dynamic> json) => TextStyleConfig(
    fontFamily: json['fontFamily'] as String? ?? 'sans-serif',
    fontSize: (json['fontSize'] as num?)?.toDouble() ?? 48,
    fontWeight: (json['fontWeight'] as num?)?.toInt() ?? 700,
    color: json['color'] as String? ?? 'white',
    opacity: (json['opacity'] as num?)?.toDouble() ?? 1,
    align: json['align'] as String? ?? 'center',
    background: json['background'] as String? ?? 'transparent',
    outlineColor: json['outlineColor'] as String? ?? 'black',
    outlineWidth: (json['outlineWidth'] as num?)?.toDouble() ?? 2,
    shadowBlur: (json['shadowBlur'] as num?)?.toDouble() ?? 0,
  );
}

class TransitionConfig {
  const TransitionConfig({
    this.type = 'none',
    this.durationMs = 0,
  });

  final String type;
  final int durationMs;

  bool get enabled => type != 'none' && durationMs > 0;

  Map<String, dynamic> toJson() => {'type': type, 'durationMs': durationMs};

  factory TransitionConfig.fromJson(Map<String, dynamic> json) =>
      TransitionConfig(
        type: json['type'] as String? ?? 'none',
        durationMs: (json['durationMs'] as num?)?.toInt() ?? 0,
      );
}

class TimelineClip {
  TimelineClip({
    required this.id,
    required this.assetId,
    required this.trackId,
    required this.startMs,
    required this.durationMs,
    this.sourceStartMs = 0,
    this.speed = 1,
    this.opacity = 1,
    this.volume = 1,
    this.muted = false,
    this.enabled = true,
    this.fadeInMs = 0,
    this.fadeOutMs = 0,
    this.pan = 0,
    this.transform = const Transform2D(),
    this.blendMode = BlendMode.normal,
    this.text,
    this.textStyle = const TextStyleConfig(),
    this.transitionIn = const TransitionConfig(),
    this.transitionOut = const TransitionConfig(),
    this.effects = const [],
    this.positionKeyframes = const [],
    this.positionXKeyframes = const [],
    this.positionYKeyframes = const [],
    this.scaleKeyframes = const [],
    this.scaleXKeyframes = const [],
    this.scaleYKeyframes = const [],
    this.rotationKeyframes = const [],
    this.opacityKeyframes = const [],
    this.volumeKeyframes = const [],
    this.object3dAssetId,
    this.transform3D = const Transform3D(),
    this.positionZKeyframes = const [],
    this.rotationXKeyframes = const [],
    this.rotationYKeyframes = const [],
    this.rotationZKeyframes = const [],
    this.scale3DKeyframes = const [],
  });

  final String id;
  final String assetId;
  final String trackId;
  int startMs;
  int durationMs;
  int sourceStartMs;
  double speed;
  double opacity;
  double volume;
  bool muted;
  bool enabled;
  int fadeInMs;
  int fadeOutMs;
  double pan;
  Transform2D transform;
  BlendMode blendMode;
  String? text;
  TextStyleConfig textStyle;
  TransitionConfig transitionIn;
  TransitionConfig transitionOut;
  List<EffectConfig> effects;
  List<Keyframe> positionKeyframes;
  List<Keyframe> positionXKeyframes;
  List<Keyframe> positionYKeyframes;
  List<Keyframe> scaleKeyframes;
  List<Keyframe> scaleXKeyframes;
  List<Keyframe> scaleYKeyframes;
  List<Keyframe> rotationKeyframes;
  List<Keyframe> opacityKeyframes;
  List<Keyframe> volumeKeyframes;
  String? object3dAssetId;
  Transform3D transform3D;
  List<Keyframe> positionZKeyframes;
  List<Keyframe> rotationXKeyframes;
  List<Keyframe> rotationYKeyframes;
  List<Keyframe> rotationZKeyframes;
  List<Keyframe> scale3DKeyframes;

  int get endMs => startMs + durationMs;

  TimelineClip clone({required String id, int? startMs}) => TimelineClip(
    id: id,
    assetId: assetId,
    trackId: trackId,
    startMs: startMs ?? this.startMs,
    durationMs: durationMs,
    sourceStartMs: sourceStartMs,
    speed: speed,
    opacity: opacity,
    volume: volume,
    muted: muted,
    enabled: enabled,
    fadeInMs: fadeInMs,
    fadeOutMs: fadeOutMs,
    pan: pan,
    transform: transform,
    blendMode: blendMode,
    text: text,
    textStyle: textStyle,
    transitionIn: transitionIn,
    transitionOut: transitionOut,
    effects: List.of(effects),
    positionKeyframes: List.of(positionKeyframes),
    positionXKeyframes: List.of(positionXKeyframes),
    positionYKeyframes: List.of(positionYKeyframes),
    scaleKeyframes: List.of(scaleKeyframes),
    scaleXKeyframes: List.of(scaleXKeyframes),
    scaleYKeyframes: List.of(scaleYKeyframes),
    rotationKeyframes: List.of(rotationKeyframes),
    opacityKeyframes: List.of(opacityKeyframes),
    volumeKeyframes: List.of(volumeKeyframes),
    object3dAssetId: object3dAssetId,
    transform3D: transform3D,
    positionZKeyframes: List.of(positionZKeyframes),
    rotationXKeyframes: List.of(rotationXKeyframes),
    rotationYKeyframes: List.of(rotationYKeyframes),
    rotationZKeyframes: List.of(rotationZKeyframes),
    scale3DKeyframes: List.of(scale3DKeyframes),
  );

  void trimLeft(int deltaMs) {
    final safeDelta = math.min(math.max(0, deltaMs), durationMs - 1);
    startMs += safeDelta;
    sourceStartMs += (safeDelta * speed).round();
    durationMs -= safeDelta;
    shiftKeyframes(-safeDelta);
  }

  void trimRight(int deltaMs) {
    durationMs = math.max(1, durationMs - deltaMs);
    trimKeyframesToDuration();
  }

  void shiftKeyframes(int deltaMs) {
    List<Keyframe> shift(List<Keyframe> values) => values
        .map((keyframe) => Keyframe(
              timeMs: keyframe.timeMs + deltaMs,
              value: keyframe.value,
              interpolation: keyframe.interpolation,
            ))
        .where((keyframe) => keyframe.timeMs >= 0 && keyframe.timeMs <= durationMs)
        .toList();
    positionKeyframes = shift(positionKeyframes);
    positionXKeyframes = shift(positionXKeyframes);
    positionYKeyframes = shift(positionYKeyframes);
    scaleKeyframes = shift(scaleKeyframes);
    scaleXKeyframes = shift(scaleXKeyframes);
    scaleYKeyframes = shift(scaleYKeyframes);
    rotationKeyframes = shift(rotationKeyframes);
    opacityKeyframes = shift(opacityKeyframes);
    volumeKeyframes = shift(volumeKeyframes);
    positionZKeyframes = shift(positionZKeyframes);
    rotationXKeyframes = shift(rotationXKeyframes);
    rotationYKeyframes = shift(rotationYKeyframes);
    rotationZKeyframes = shift(rotationZKeyframes);
    scale3DKeyframes = shift(scale3DKeyframes);
  }

  void trimKeyframesToDuration() {
    List<Keyframe> trim(List<Keyframe> values) => values
        .where(
          (keyframe) =>
              keyframe.timeMs >= 0 && keyframe.timeMs <= durationMs,
        )
        .toList();

    positionKeyframes = trim(positionKeyframes);
    positionXKeyframes = trim(positionXKeyframes);
    positionYKeyframes = trim(positionYKeyframes);
    scaleKeyframes = trim(scaleKeyframes);
    scaleXKeyframes = trim(scaleXKeyframes);
    scaleYKeyframes = trim(scaleYKeyframes);
    rotationKeyframes = trim(rotationKeyframes);
    opacityKeyframes = trim(opacityKeyframes);
    volumeKeyframes = trim(volumeKeyframes);
    positionZKeyframes = trim(positionZKeyframes);
    rotationXKeyframes = trim(rotationXKeyframes);
    rotationYKeyframes = trim(rotationYKeyframes);
    rotationZKeyframes = trim(rotationZKeyframes);
    scale3DKeyframes = trim(scale3DKeyframes);
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'assetId': assetId,
    'trackId': trackId,
    'startMs': startMs,
    'durationMs': durationMs,
    'sourceStartMs': sourceStartMs,
    'speed': speed,
    'opacity': opacity,
    'volume': volume,
    'muted': muted,
    'enabled': enabled,
    'fadeInMs': fadeInMs,
    'fadeOutMs': fadeOutMs,
    'pan': pan,
    'transform': transform.toJson(),
    'blendMode': blendMode.name,
    'text': text,
    'textStyle': textStyle.toJson(),
    'transitionIn': transitionIn.toJson(),
    'transitionOut': transitionOut.toJson(),
    'effects': effects.map((e) => e.toJson()).toList(),
    'positionKeyframes': positionKeyframes.map((e) => e.toJson()).toList(),
    'positionXKeyframes': positionXKeyframes.map((e) => e.toJson()).toList(),
    'positionYKeyframes': positionYKeyframes.map((e) => e.toJson()).toList(),
    'scaleKeyframes': scaleKeyframes.map((e) => e.toJson()).toList(),
    'scaleXKeyframes': scaleXKeyframes.map((e) => e.toJson()).toList(),
    'scaleYKeyframes': scaleYKeyframes.map((e) => e.toJson()).toList(),
    'rotationKeyframes': rotationKeyframes.map((e) => e.toJson()).toList(),
    'opacityKeyframes': opacityKeyframes.map((e) => e.toJson()).toList(),
    'volumeKeyframes': volumeKeyframes.map((e) => e.toJson()).toList(),
    'object3dAssetId': object3dAssetId,
    'transform3D': transform3D.toJson(),
    'positionZKeyframes': positionZKeyframes.map((e) => e.toJson()).toList(),
    'rotationXKeyframes': rotationXKeyframes.map((e) => e.toJson()).toList(),
    'rotationYKeyframes': rotationYKeyframes.map((e) => e.toJson()).toList(),
    'rotationZKeyframes': rotationZKeyframes.map((e) => e.toJson()).toList(),
    'scale3DKeyframes': scale3DKeyframes.map((e) => e.toJson()).toList(),
  };

  factory TimelineClip.fromJson(Map<String, dynamic> json) => TimelineClip(
    id: json['id'] as String,
    assetId: json['assetId'] as String,
    trackId: json['trackId'] as String,
    startMs: (json['startMs'] as num).toInt(),
    durationMs: (json['durationMs'] as num).toInt(),
    sourceStartMs: (json['sourceStartMs'] as num?)?.toInt() ?? 0,
    speed: (json['speed'] as num?)?.toDouble() ?? 1,
    opacity: (json['opacity'] as num?)?.toDouble() ?? 1,
    volume: (json['volume'] as num?)?.toDouble() ?? 1,
    muted: json['muted'] as bool? ?? false,
    enabled: json['enabled'] as bool? ?? true,
    fadeInMs: (json['fadeInMs'] as num?)?.toInt() ?? 0,
    fadeOutMs: (json['fadeOutMs'] as num?)?.toInt() ?? 0,
    pan: (json['pan'] as num?)?.toDouble() ?? 0,
    transform: Transform2D.fromJson(
      (json['transform'] as Map?)?.cast<String, dynamic>() ?? {},
    ),
    blendMode: BlendMode.values.byName(
      json['blendMode'] as String? ?? 'normal',
    ),
    text: json['text'] as String?,
    textStyle: TextStyleConfig.fromJson(
      (json['textStyle'] as Map?)?.cast<String, dynamic>() ?? {},
    ),
    transitionIn: TransitionConfig.fromJson(
      (json['transitionIn'] as Map?)?.cast<String, dynamic>() ?? {},
    ),
    transitionOut: TransitionConfig.fromJson(
      (json['transitionOut'] as Map?)?.cast<String, dynamic>() ?? {},
    ),
    effects: ((json['effects'] as List?) ?? [])
        .map((e) => EffectConfig.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    positionKeyframes: ((json['positionKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    positionXKeyframes: ((json['positionXKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    positionYKeyframes: ((json['positionYKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    scaleKeyframes: ((json['scaleKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    scaleXKeyframes: ((json['scaleXKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    scaleYKeyframes: ((json['scaleYKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    rotationKeyframes: ((json['rotationKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    opacityKeyframes: ((json['opacityKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    volumeKeyframes: ((json['volumeKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    object3dAssetId: json['object3dAssetId'] as String?,
    transform3D: Transform3D.fromJson(
      (json['transform3D'] as Map?)?.cast<String, dynamic>() ?? {},
    ),
    positionZKeyframes: ((json['positionZKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    rotationXKeyframes: ((json['rotationXKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    rotationYKeyframes: ((json['rotationYKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    rotationZKeyframes: ((json['rotationZKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
    scale3DKeyframes: ((json['scale3DKeyframes'] as List?) ?? [])
        .map((e) => Keyframe.fromJson((e as Map).cast<String, dynamic>()))
        .toList(),
  );
}

class TimelineTrack {
  TimelineTrack({
    required this.id,
    required this.name,
    required this.kind,
    this.locked = false,
    this.hidden = false,
    List<TimelineClip>? clips,
  }) : clips = clips ?? [];
  final String id;
  String name;
  final TrackKind kind;
  bool locked;
  bool hidden;
  final List<TimelineClip> clips;

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'kind': kind.name,
    'locked': locked,
    'hidden': hidden,
    'clips': clips.map((c) => c.toJson()).toList(),
  };

  factory TimelineTrack.fromJson(Map<String, dynamic> json) => TimelineTrack(
    id: json['id'] as String,
    name: json['name'] as String,
    kind: TrackKind.values.byName(json['kind'] as String? ?? 'video'),
    locked: json['locked'] as bool? ?? false,
    hidden: json['hidden'] as bool? ?? false,
    clips: ((json['clips'] as List?) ?? [])
        .map((c) => TimelineClip.fromJson((c as Map).cast<String, dynamic>()))
        .toList(),
  );
}
