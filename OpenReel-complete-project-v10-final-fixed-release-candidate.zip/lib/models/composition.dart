import 'timeline.dart';
import '../services/subtitle_service.dart';
import 'model3d.dart';

class CompositionLayer {
  const CompositionLayer({
    required this.clipId,
    required this.trackId,
    required this.kind,
    required this.sourcePath,
    required this.localTimeMs,
    required this.startMs,
    required this.durationMs,
    required this.opacity,
    required this.volume,
    required this.transform,
    required this.effects,
    required this.blendMode,
    this.text,
    this.textStyle = const TextStyleConfig(),
    this.subtitleStyle,
    this.transitionType = 'none',
    this.transitionProgress = 1,
    this.object3dAssetId,
    this.transform3D = const Transform3D(),
  });

  final String clipId;
  final String trackId;
  final TrackKind kind;
  final String? sourcePath;
  final int localTimeMs;
  final int startMs;
  final int durationMs;
  final double opacity;
  final double volume;
  final Transform2D transform;
  final List<EffectConfig> effects;
  final BlendMode blendMode;
  final String? text;
  final TextStyleConfig textStyle;
  final SubtitleStyle? subtitleStyle;
  final String transitionType;
  final double transitionProgress;
  final String? object3dAssetId;
  final Transform3D transform3D;

  int get endMs => startMs + durationMs;
  bool get isAudio => kind == TrackKind.audio;
  bool get isVisual => kind != TrackKind.audio;
}

class CompositionFrame {
  const CompositionFrame({
    required this.timeMs,
    required this.layers,
    required this.audioLayers,
  });
  final int timeMs;
  final List<CompositionLayer> layers;
  final List<CompositionLayer> audioLayers;

  List<CompositionLayer> get visualLayers =>
      layers.where((layer) => layer.isVisual).toList(growable: false);
  List<CompositionLayer> get videoLayers => layers
      .where((layer) => layer.kind == TrackKind.video)
      .toList(growable: false);
  List<CompositionLayer> get imageLayers => layers
      .where(
        (layer) => layer.kind == TrackKind.overlay && layer.sourcePath != null,
      )
      .toList(growable: false);
  List<CompositionLayer> get textLayers =>
      layers.where((layer) => layer.text != null).toList(growable: false);
  List<CompositionLayer> get subtitleLayers => layers
      .where((layer) => layer.kind == TrackKind.subtitle)
      .toList(growable: false);

  /// Stable input for preview/export equivalence tests and render caches.
  String get signature => [
    timeMs,
    ...layers.map(
      (layer) => [
        layer.trackId,
        layer.clipId,
        layer.localTimeMs,
        layer.opacity.toStringAsFixed(5),
        layer.volume.toStringAsFixed(5),
        layer.transform.x.toStringAsFixed(4),
        layer.transform.y.toStringAsFixed(4),
        layer.transform.scaleX.toStringAsFixed(4),
        layer.transform.scaleY.toStringAsFixed(4),
        layer.transform.rotation.toStringAsFixed(4),
        layer.blendMode.name,
        layer.text ?? '',
        ...layer.effects.map((effect) => '${effect.type}:${effect.parameters}'),
        layer.textStyle.toJson().toString(),
        layer.subtitleStyle?.toJson().toString() ?? '',
        layer.transitionType,
        layer.transitionProgress.toStringAsFixed(5),
        layer.object3dAssetId ?? '',
        layer.transform3D.toJson().toString(),
      ].join('|'),
    ),
    ...audioLayers.map(
      (layer) =>
          '${layer.trackId}|${layer.clipId}|${layer.localTimeMs}|${layer.volume}',
    ),
  ].join('||');
}
