import 'dart:convert';

enum MediaKind { video, audio, image, gif, unknown }

MediaKind mediaKindFromPath(String path) {
  final extension = path.split('.').last.toLowerCase();
  if (['mp4', 'mov', 'mkv', 'webm', 'avi'].contains(extension)) {
    return MediaKind.video;
  }
  if (['mp3', 'wav', 'aac', 'flac', 'm4a'].contains(extension)) {
    return MediaKind.audio;
  }
  if (['png', 'jpg', 'jpeg', 'webp'].contains(extension)) {
    return MediaKind.image;
  }
  if (extension == 'gif') return MediaKind.gif;
  return MediaKind.unknown;
}

class MediaAsset {
  const MediaAsset({
    required this.id,
    required this.path,
    required this.name,
    required this.kind,
    this.durationMs = 0,
    this.width = 0,
    this.height = 0,
    this.fps = 0,
    this.codec,
    this.bitrate,
    this.hasAudio = false,
    this.channels,
    this.sampleRate,
    this.orientation = 0,
    this.thumbnailPath,
    this.waveformPath,
    this.proxyPath,
    this.sourcePath,
  });

  final String id;
  final String path;
  final String name;
  final MediaKind kind;
  final int durationMs;
  final int width;
  final int height;
  final double fps;
  final String? codec;
  final int? bitrate;
  final bool hasAudio;
  final int? channels;
  final int? sampleRate;
  final int orientation;
  final String? thumbnailPath;
  final String? waveformPath;
  final String? proxyPath;
  /// Original path/URI selected by the user. [path] is the app-managed copy.
  final String? sourcePath;

  Duration get duration => Duration(milliseconds: durationMs);
  String get resolution => width > 0 && height > 0 ? '${width}×$height' : '—';

  MediaAsset copyWith({
    String? path,
    String? name,
    int? durationMs,
    int? width,
    int? height,
    double? fps,
    String? codec,
    int? bitrate,
    bool? hasAudio,
    int? channels,
    int? sampleRate,
    int? orientation,
    String? thumbnailPath,
    String? waveformPath,
    String? proxyPath,
    String? sourcePath,
  }) => MediaAsset(
    id: id,
    path: path ?? this.path,
    name: name ?? this.name,
    kind: kind,
    durationMs: durationMs ?? this.durationMs,
    width: width ?? this.width,
    height: height ?? this.height,
    fps: fps ?? this.fps,
    codec: codec ?? this.codec,
    bitrate: bitrate ?? this.bitrate,
    hasAudio: hasAudio ?? this.hasAudio,
    channels: channels ?? this.channels,
    sampleRate: sampleRate ?? this.sampleRate,
    orientation: orientation ?? this.orientation,
    thumbnailPath: thumbnailPath ?? this.thumbnailPath,
    waveformPath: waveformPath ?? this.waveformPath,
    proxyPath: proxyPath ?? this.proxyPath,
    sourcePath: sourcePath ?? this.sourcePath,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'path': path,
    'name': name,
    'kind': kind.name,
    'durationMs': durationMs,
    'width': width,
    'height': height,
    'fps': fps,
    'codec': codec,
    'bitrate': bitrate,
    'hasAudio': hasAudio,
    'channels': channels,
    'sampleRate': sampleRate,
    'orientation': orientation,
    'thumbnailPath': thumbnailPath,
    'waveformPath': waveformPath,
    'proxyPath': proxyPath,
    'sourcePath': sourcePath,
  };

  factory MediaAsset.fromJson(Map<String, dynamic> json) => MediaAsset(
    id: json['id'] as String,
    path: json['path'] as String,
    name: json['name'] as String,
    kind: MediaKind.values.byName(json['kind'] as String? ?? 'unknown'),
    durationMs: (json['durationMs'] as num?)?.toInt() ?? 0,
    width: (json['width'] as num?)?.toInt() ?? 0,
    height: (json['height'] as num?)?.toInt() ?? 0,
    fps: (json['fps'] as num?)?.toDouble() ?? 0,
    codec: json['codec'] as String?,
    bitrate: (json['bitrate'] as num?)?.toInt(),
    hasAudio: json['hasAudio'] as bool? ?? false,
    channels: (json['channels'] as num?)?.toInt(),
    sampleRate: (json['sampleRate'] as num?)?.toInt(),
    orientation: (json['orientation'] as num?)?.toInt() ?? 0,
    thumbnailPath: json['thumbnailPath'] as String?,
    waveformPath: json['waveformPath'] as String?,
    proxyPath: json['proxyPath'] as String?,
    sourcePath: json['sourcePath'] as String?,
  );

  String encode() => jsonEncode(toJson());
}
