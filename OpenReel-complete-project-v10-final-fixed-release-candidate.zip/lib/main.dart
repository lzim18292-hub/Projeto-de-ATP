import 'package:flutter/material.dart';

import 'ui/project_home.dart';
import 'ui/openreel_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OpenReelApp());
}

class OpenReelApp extends StatelessWidget {
  const OpenReelApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'OpenReel',
    debugShowCheckedModeBanner: false,
    theme: OpenReelTheme.dark(),
    home: const ProjectHome(),
  );
}
