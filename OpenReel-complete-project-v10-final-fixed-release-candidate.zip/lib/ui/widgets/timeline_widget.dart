import 'dart:io';

import 'package:flutter/material.dart';

import '../../models/media_asset.dart';
import '../../models/timeline.dart';
import '../../state/editor_controller.dart';

class TimelineWidget extends StatefulWidget {
  const TimelineWidget({
    super.key,
    required this.controller,
    required this.onSelectAsset,
  });

  final EditorController controller;
  final Future<void> Function(MediaAsset asset) onSelectAsset;

  @override
  State<TimelineWidget> createState() => _TimelineWidgetState();
}

class _TimelineWidgetState extends State<TimelineWidget> {
  double? _dragOrigin;
  int? _clipOrigin;
  double _trimDeltaPx = 0;
  bool _trimLeft = false;
  int _trimOriginMs = 0;
  bool _trimStarted = false;
  double _gestureStartZoom = .1;

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    final duration = controller.timelineDurationMs.clamp(
      10000,
      24 * 60 * 60 * 1000,
    );
    final contentWidth = duration * controller.zoom + 40;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          width: 108,
          child: Column(
            children: [
              const SizedBox(height: 29),
              Expanded(
                child: ListView.builder(
                  itemCount: controller.tracks.length,
                  itemBuilder: (_, index) =>
                      _trackHeader(controller.tracks[index]),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onScaleStart: (_) => _gestureStartZoom = controller.zoom,
            onScaleUpdate: (details) {
              if (details.scale != 1) {
                controller.setZoom(_gestureStartZoom * details.scale);
              }
            },
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SizedBox(
              width: contentWidth,
              child: Stack(
                children: [
                  Column(
                    children: [
                      SizedBox(
                        height: 29,
                        child: GestureDetector(
                          onTapDown: (details) => controller.setPlayhead(
                            (details.localPosition.dx / controller.zoom)
                                .round(),
                          ),
                          child: CustomPaint(
                            size: Size(contentWidth, 29),
                            painter: _RulerPainter(
                              zoom: controller.zoom,
                              durationMs: duration,
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: ListView.builder(
                          itemCount: controller.tracks.length,
                          itemBuilder: (_, index) =>
                              _trackRow(controller.tracks[index], contentWidth),
                        ),
                      ),
                    ],
                  ),
                  for (final marker in controller.project.markers)
                    Positioned(
                      left: marker * controller.zoom,
                      top: 0,
                      bottom: 0,
                      child: IgnorePointer(
                        child: Container(
                          width: 1,
                          color: const Color(0xffffb74d),
                        ),
                      ),
                    ),
                  Positioned(
                    left: controller.playheadMs * controller.zoom,
                    top: 0,
                    bottom: 0,
                    child: IgnorePointer(
                      child: Container(
                        width: 2,
                        color: const Color(0xffff5e62),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        ),
      ],
    );
  }

  Widget _trackHeader(TimelineTrack track) => Container(
    height: 64,
    padding: const EdgeInsets.symmetric(horizontal: 5),
    decoration: const BoxDecoration(
      border: Border(bottom: BorderSide(color: Color(0xff25313d))),
    ),
    child: Row(
      children: [
        Icon(_trackIcon(track.kind), size: 13, color: _trackColor(track.kind)),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            track.name,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 9, color: Color(0xffbdc8d5)),
          ),
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _smallTrackButton(
              track.locked ? Icons.lock : Icons.lock_open,
              track.locked ? 'Desbloquear' : 'Bloquear',
              () => widget.controller.toggleTrackLock(track.id),
            ),
            _smallTrackButton(
              track.hidden ? Icons.visibility_off : Icons.visibility,
              track.hidden ? 'Mostrar' : 'Ocultar',
              () => widget.controller.toggleTrackVisibility(track.id),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _smallTrackButton(
    IconData icon,
    String tooltip,
    VoidCallback onPressed,
  ) => SizedBox(
    width: 40,
    height: 32,
    child: IconButton(
      tooltip: tooltip,
      onPressed: onPressed,
      icon: Icon(icon, size: 15),
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints.tightFor(width: 40, height: 32),
    ),
  );

  Widget _trackRow(TimelineTrack track, double width) => SizedBox(
    height: 64,
    width: width,
    child: Container(
      decoration: BoxDecoration(
        color: track.hidden ? const Color(0xff11151b) : const Color(0xff131c26),
        border: const Border(bottom: BorderSide(color: Color(0xff25313d))),
      ),
      child: Stack(
        children: [for (final clip in track.clips) _clipWidget(clip, track)],
      ),
    ),
  );

  Widget _clipWidget(TimelineClip clip, TimelineTrack track) {
    final controller = widget.controller;
    final selected = controller.isClipSelected(clip.id);
    final left = clip.startMs * controller.zoom;
    final width = (clip.durationMs * controller.zoom)
        .clamp(28, 5000)
        .toDouble();
    final asset = controller.project.assets.cast<MediaAsset?>().firstWhere(
      (item) => item?.id == clip.assetId,
      orElse: () => null,
    );
    final color = clip.text != null
        ? const Color(0xff8d67dd)
        : _trackColor(track.kind);
    return Positioned(
      left: left,
      top: 7,
      width: width,
      height: 50,
      child: GestureDetector(
        onTap: () async {
          controller.selectClip(clip.id);
          if (asset != null) await widget.onSelectAsset(asset);
        },
        onLongPress: () => controller.selectClip(clip.id, additive: true),
        onHorizontalDragStart: (_) {
          _dragOrigin = null;
          _clipOrigin = clip.startMs;
          controller.selectClip(clip.id);
        },
        onHorizontalDragUpdate: (details) {
          if (_clipOrigin == null) return;
          _dragOrigin ??= details.localPosition.dx;
          final next = _clipOrigin! +
              ((details.localPosition.dx - _dragOrigin!) / controller.zoom).round();
          controller.moveClip(clip.id, next, checkpoint: false);
        },
        onHorizontalDragEnd: (_) {
          _dragOrigin = null;
          _clipOrigin = null;
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(
          decoration: BoxDecoration(
            color: color.withOpacity(selected ? .9 : .65),
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: selected ? Colors.white : color.withOpacity(.9),
              width: selected ? 1.5 : .7,
            ),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
          child: Row(
            children: [
              if (asset != null &&
                  asset.thumbnailPath != null &&
                  File(asset.thumbnailPath!).existsSync())
                ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: Image.file(
                    File(asset.thumbnailPath!),
                    width: 30,
                    height: 38,
                    fit: BoxFit.cover,
                  ),
                ),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  clip.text ?? asset?.name ?? 'Clipe',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
              ),
            ),
            _trimHandle(clip, left: true),
            _trimHandle(clip, left: false),
          ],
        ),
      ),
    );
  }

  Widget _trimHandle(TimelineClip clip, {required bool left}) => Align(
    alignment: left ? Alignment.centerLeft : Alignment.centerRight,
    child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragStart: (_) {
        _trimDeltaPx = 0;
        _trimLeft = left;
        _trimOriginMs = left ? clip.startMs : clip.endMs;
        _trimStarted = false;
        widget.controller.selectClip(clip.id);
      },
      onHorizontalDragUpdate: (details) {
        _trimDeltaPx += details.delta.dx;
        final deltaMs = (_trimDeltaPx / widget.controller.zoom).round();
        final checkpoint = !_trimStarted;
        _trimStarted = true;
        if (_trimLeft) {
          widget.controller.trimSelectedToStart(
            _trimOriginMs + deltaMs,
            checkpoint: checkpoint,
          );
        } else {
          widget.controller.trimSelectedToEnd(
            _trimOriginMs + deltaMs,
            checkpoint: checkpoint,
          );
        }
      },
      onHorizontalDragEnd: (_) {
        _trimDeltaPx = 0;
        widget.controller.refresh();
      },
      child: Container(
        width: 14,
        margin: const EdgeInsets.symmetric(vertical: 5),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.65),
          borderRadius: BorderRadius.circular(3),
        ),
      ),
    ),
  );

  Color _trackColor(TrackKind kind) => switch (kind) {
    TrackKind.video => const Color(0xff1e9f8a),
    TrackKind.audio => const Color(0xff387ac8),
    TrackKind.overlay => const Color(0xff875fd1),
    TrackKind.subtitle => const Color(0xffc17f34),
    TrackKind.object3d => const Color(0xff5e7ce2),
  };

  IconData _trackIcon(TrackKind kind) => switch (kind) {
    TrackKind.video => Icons.videocam_outlined,
    TrackKind.audio => Icons.graphic_eq,
    TrackKind.overlay => Icons.layers_outlined,
    TrackKind.subtitle => Icons.subtitles_outlined,
    TrackKind.object3d => Icons.view_in_ar_outlined,
  };
}

class _RulerPainter extends CustomPainter {
  const _RulerPainter({required this.zoom, required this.durationMs});

  final double zoom;
  final int durationMs;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xff647489)
      ..strokeWidth = 1;
    const labelStyle = TextStyle(color: Color(0xff7f8da0), fontSize: 9);
    final interval = zoom > .15
        ? 1000
        : zoom > .06
        ? 5000
        : 10000;
    for (var ms = 0; ms <= durationMs; ms += interval) {
      final x = ms * zoom;
      canvas.drawLine(Offset(x, 17), Offset(x, 28), paint);
      final tp = TextPainter(
        text: TextSpan(text: _format(ms), style: labelStyle),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(x + 3, 3));
    }
  }

  String _format(int ms) =>
      '${(ms ~/ 60000).toString().padLeft(2, '0')}:${((ms ~/ 1000) % 60).toString().padLeft(2, '0')}';

  @override
  bool shouldRepaint(covariant _RulerPainter oldDelegate) =>
      oldDelegate.zoom != zoom || oldDelegate.durationMs != durationMs;
}
