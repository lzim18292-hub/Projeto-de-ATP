import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:file_picker/file_picker.dart';
import '../services/short_auto_engine.dart';
import '../services/template_service.dart';

import '../models/project.dart';
import '../services/project_repository.dart';
import 'editor_shell.dart';

class ProjectHome extends StatefulWidget {
  const ProjectHome({super.key});

  @override
  State<ProjectHome> createState() => _ProjectHomeState();
}

class _ProjectHomeState extends State<ProjectHome> {
  final _repository = ProjectRepository();
  bool _loading = true;
  List<ProjectSummary> _projects = const [];

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final projects = await _repository.list();
    if (!mounted) return;
    setState(() {
      _projects = projects;
      _loading = false;
    });
  }

  Future<void> _create() async {
    final name = await _nameDialog('Novo projeto', 'Projeto sem título');
    if (name == null) return;
    final project = Project(
      id: const Uuid().v4(),
      name: name.isEmpty ? 'Projeto sem título' : name,
    );
    await _repository.save(project);
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditorShell(projectId: project.id)),
    );
    _refresh();
  }

  Future<void> _open(String id) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditorShell(projectId: id)),
    );
    _refresh();
  }

  Future<void> _rename(ProjectSummary summary) async {
    final name = await _nameDialog('Renomear projeto', summary.name);
    if (name == null || name.trim().isEmpty) return;
    final project = await _repository.load(summary.id);
    if (project == null) return;
    project.name = name.trim();
    await _repository.save(project);
    _refresh();
  }

  Future<void> _duplicate(ProjectSummary summary) async {
    final project = await _repository.load(summary.id);
    if (project == null) return;
    final copy = Project.fromJson(
      project.toJson(),
    );
    final duplicate = Project(
      id: const Uuid().v4(),
      name: '${copy.name} (cópia)',
      width: copy.width,
      height: copy.height,
      fps: copy.fps,
      durationMs: copy.durationMs,
      assets: copy.assets,
      tracks: copy.tracks,
      markers: copy.markers,
      subtitleCues: copy.subtitleCues.map((cue) => cue.copy()).toList(),
      model3dAssets: copy.model3dAssets.toList(),
      exportSettings: copy.exportSettings,
    );
    await _repository.save(duplicate);
    _refresh();
  }

  Future<void> _delete(ProjectSummary summary) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir projeto?'),
        content: Text('“${summary.name}” será removido deste dispositivo.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir')),
        ],
      ),
    );
    if (confirmed == true) {
      await _repository.delete(summary.id);
      _refresh();
    }
  }

  Future<void> _recover(ProjectSummary summary) async {
    final recovered = await _repository.recoverAutosave(summary.id);
    if (recovered == null) return;
    await _repository.save(recovered);
    await _open(summary.id);
  }

  Future<void> _templateProject() async {
    final templates = TemplateService().builtIns();
    final chosen = await showDialog<ProjectTemplate>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('Escolher template'),
        children: [
          for (final template in templates)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(context, template),
              child: ListTile(
                leading: const Icon(Icons.dashboard_customize_outlined),
                title: Text(template.name),
                subtitle: Text(template.description),
              ),
            ),
        ],
      ),
    );
    if (chosen == null) return;
    final source = Project(id: const Uuid().v4(), name: chosen.name);
    final project = TemplateService().apply(chosen, source);
    await _repository.save(project);
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => EditorShell(projectId: project.id)));
    _refresh();
  }

  Future<void> _visualAuto() async {
    final name = TextEditingController(text: 'Short automático');
    final video = <String>[];
    final audio = <String>[];
    final subtitle = <String>[];
    var autoCuts = true, removeSilence = true, autoReframe = true, autoZoom = false, autoSubs = true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
        title: const Text('Criar Short automaticamente'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: () async {
            final r = await FilePicker.pickFiles(type: FileType.video, allowMultiple: true);
            setLocal(() => video
              ..clear()
              ..addAll(r.map((file) => file.path).whereType<String>()));
          }, icon: const Icon(Icons.movie_outlined), label: Text('Vídeos (${video.length})')),
          OutlinedButton.icon(onPressed: () async {
            final r = await FilePicker.pickFiles(type: FileType.audio, allowMultiple: true);
            setLocal(() => audio
              ..clear()
              ..addAll(r.map((file) => file.path).whereType<String>()));
          }, icon: const Icon(Icons.audiotrack_outlined), label: Text('Áudio (${audio.length})')),
          OutlinedButton.icon(onPressed: () async {
            final r = await FilePicker.pickFiles(type: FileType.custom, allowedExtensions: const ['srt','vtt']);
            setLocal(() => subtitle
              ..clear()
              ..addAll(r.map((file) => file.path).whereType<String>()));
          }, icon: const Icon(Icons.subtitles_outlined), label: Text('Legenda (${subtitle.length})')),
          CheckboxListTile(value: autoCuts, onChanged: (v) => setLocal(() => autoCuts = v ?? false), title: const Text('Cortes automáticos')),
          CheckboxListTile(value: removeSilence, onChanged: (v) => setLocal(() => removeSilence = v ?? false), title: const Text('Remover silêncio')),
          CheckboxListTile(value: autoReframe, onChanged: (v) => setLocal(() => autoReframe = v ?? false), title: const Text('Auto-reframe')),
          CheckboxListTile(value: autoZoom, onChanged: (v) => setLocal(() => autoZoom = v ?? false), title: const Text('Zoom automático')),
          CheckboxListTile(value: autoSubs, onChanged: (v) => setLocal(() => autoSubs = v ?? false), title: const Text('Legendas automáticas')),
          const Text('As opções que exigem IA permanecem declarativas até um provider real ser configurado.', style: TextStyle(fontSize: 11)),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: video.isEmpty ? null : () => Navigator.pop(context, true), child: const Text('Gerar projeto')),
        ],
      )),
    );
    if (ok != true) return;
    try {
      final project = await ShortAutoEngine().build({
        'schemaVersion': shortAutoSchemaVersion,
        'name': name.text.trim().isEmpty ? 'Short automático' : name.text.trim(),
        'width': 1080, 'height': 1920, 'fps': 30,
        'media': {'videos': video, 'audio': audio, 'subtitles': subtitle},
        'automation': {'autoCuts': autoCuts, 'removeSilence': removeSilence, 'autoReframe': autoReframe, 'autoZoom': autoZoom, 'autoSubtitles': autoSubs},
      });
      await _repository.save(project);
      if (!mounted) return;
      await Navigator.push(context, MaterialPageRoute(builder: (_) => EditorShell(projectId: project.id)));
      _refresh();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      name.dispose();
    }
  }

  Future<void> _autoShort() async {
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['json', 'xml'],
    );
    final path = result.isEmpty ? null : result.single.path;
    if (path == null) return;
    try {
      final project = await ShortAutoEngine().fromFile(path);
      await _repository.save(project);
      if (!mounted) return;
      await Navigator.push(context, MaterialPageRoute(builder: (_) => EditorShell(projectId: project.id)));
      _refresh();
    } catch (e) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Não foi possível gerar o projeto'),
          content: SelectableText('$e'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Fechar'))],
        ),
      );
    }
  }

  Future<String?> _nameDialog(String title, String initial) async {
    final controller = TextEditingController(text: initial);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Nome',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Salvar')),
        ],
      ),
    );
    controller.dispose();
    return result;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('OpenReel'),
      actions: [
        IconButton(
          tooltip: 'Criar Short automaticamente',
          onPressed: _visualAuto,
          icon: const Icon(Icons.auto_awesome_outlined),
        ),
        IconButton(
          tooltip: 'Importar automação JSON/XML',
          onPressed: _autoShort,
          icon: const Icon(Icons.code_outlined),
        ),
        IconButton(
          tooltip: 'Templates',
          onPressed: _templateProject,
          icon: const Icon(Icons.dashboard_customize_outlined),
        ),
        IconButton(
          tooltip: 'Atualizar projetos',
          onPressed: _refresh,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: _refresh,
            child: _projects.isEmpty
                ? ListView(
                    children: const [
                      SizedBox(height: 100),
                      Icon(Icons.movie_creation_outlined, size: 64),
                      SizedBox(height: 18),
                      Center(child: Text('Nenhum projeto ainda')),
                      SizedBox(height: 8),
                      Center(child: Text('Crie um projeto para começar a editar.')),
                    ],
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(18),
                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 360,
                      mainAxisExtent: 190,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                    ),
                    itemCount: _projects.length,
                    itemBuilder: (_, index) => _projectCard(_projects[index]),
                  ),
          ),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: _create,
      icon: const Icon(Icons.add),
      label: const Text('Novo projeto'),
    ),
  );

  Widget _projectCard(ProjectSummary summary) => Card(
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: () => _open(summary.id),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.movie_outlined, size: 28),
            const Spacer(),
            Text(
              summary.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            Text(
              summary.modifiedAt.toLocal().toString(),
              style: const TextStyle(fontSize: 10, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                IconButton(
                  tooltip: 'Renomear',
                  onPressed: () => _rename(summary),
                  icon: const Icon(Icons.edit_outlined, size: 18),
                ),
                IconButton(
                  tooltip: 'Duplicar',
                  onPressed: () => _duplicate(summary),
                  icon: const Icon(Icons.copy_outlined, size: 18),
                ),
                IconButton(
                  tooltip: 'Excluir',
                  onPressed: () => _delete(summary),
                  icon: const Icon(Icons.delete_outline, size: 18),
                ),
                const Spacer(),
                FutureBuilder<bool>(
                  future: _repository.hasAutosave(summary.id),
                  builder: (_, snapshot) => snapshot.data == true
                      ? TextButton.icon(
                          onPressed: () => _recover(summary),
                          icon: const Icon(Icons.restore, size: 16),
                          label: const Text('Recuperar'),
                        )
                      : const SizedBox.shrink(),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
