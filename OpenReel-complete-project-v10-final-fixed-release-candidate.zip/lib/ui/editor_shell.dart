import 'dart:io';
import 'dart:typed_data';
import 'dart:async';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_3d_controller/flutter_3d_controller.dart';

import '../models/composition.dart';
import '../models/media_asset.dart';
import '../models/timeline.dart';
import '../state/editor_controller.dart';
import 'widgets/timeline_widget.dart';
import 'model3d_library.dart';

class EditorShell extends StatefulWidget {
  const EditorShell({super.key, this.projectId});

  final String? projectId;

  @override
  State<EditorShell> createState() => _EditorShellState();
}

class _EditorShellState extends State<EditorShell> {
  final EditorController _controller = EditorController();
  final Map<String, VideoPlayerController> _videoControllers = {};
  final Map<String, Flutter3DController> _model3dControllers = {};

  @override
  void initState() {
    super.initState();
    if (widget.projectId != null) {
      _controller.load(widget.projectId!);
    }
  }
  final Map<String, Future<void>> _videoInitializations = {};
  final Map<String, VideoPlayerController> _audioControllers = {};
  final Map<String, Future<void>> _audioInitializations = {};
  Timer? _playTimer;
  bool _isPlaying = false;

  @override
  void dispose() {
    _playTimer?.cancel();
    for (final controller in _videoControllers.values) {
      controller.dispose();
    }
    for (final controller in _audioControllers.values) {
      controller.dispose();
    }
    _model3dControllers.clear();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _ensureVideoController(CompositionLayer layer) async {
    final path = layer.sourcePath;
    if (path == null || _videoControllers.containsKey(layer.clipId)) return;
    final video = VideoPlayerController.file(File(path));
    final future = video.initialize();
    _videoControllers[layer.clipId] = video;
    _videoInitializations[layer.clipId] = future;
    try {
      await future;
      await video.setLooping(false);
      if (mounted) setState(() {});
    } catch (_) {
      await video.dispose();
      _videoControllers.remove(layer.clipId);
      _videoInitializations.remove(layer.clipId);
    }
  }

  Future<void> _ensureAudioController(CompositionLayer layer) async {
    final path = layer.sourcePath;
    if (path == null || _audioControllers.containsKey(layer.clipId)) return;
    final audio = VideoPlayerController.file(File(path));
    final future = audio.initialize();
    _audioControllers[layer.clipId] = audio;
    _audioInitializations[layer.clipId] = future;
    try {
      await future;
      await audio.setLooping(false);
    } catch (_) {
      await audio.dispose();
      _audioControllers.remove(layer.clipId);
      _audioInitializations.remove(layer.clipId);
    }
  }

  Future<void> _syncPreviewVideos(CompositionFrame frame) async {
    final activeVideoIds = frame.videoLayers.map((l) => l.clipId).toSet();
    for (final id in _videoControllers.keys.toList()) {
      if (!activeVideoIds.contains(id)) {
        await _videoControllers.remove(id)?.dispose();
        _videoInitializations.remove(id);
      }
    }
    for (final layer in frame.videoLayers) {
      await _ensureVideoController(layer);
      final video = _videoControllers[layer.clipId];
      if (video == null || !video.value.isInitialized) continue;
      final target = Duration(
        milliseconds: layer.localTimeMs.clamp(0, video.value.duration.inMilliseconds),
      );
      if ((video.value.position - target).inMilliseconds.abs() > 80) {
        await video.seekTo(target);
      }
      await video.setVolume(layer.volume.clamp(0, 1));
      if (_isPlaying && !video.value.isPlaying) {
        await video.play();
      } else if (!_isPlaying && video.value.isPlaying) {
        await video.pause();
      }
    }

    final activeAudioIds = frame.audioLayers
        .where((layer) => !frame.videoLayers.any((video) => '${video.clipId}:audio' == layer.clipId))
        .map((layer) => layer.clipId)
        .toSet();
    for (final id in _audioControllers.keys.toList()) {
      if (!activeAudioIds.contains(id)) {
        await _audioControllers.remove(id)?.dispose();
        _audioInitializations.remove(id);
      }
    }
    for (final layer in frame.audioLayers) {
      if (frame.videoLayers.any((video) => '${video.clipId}:audio' == layer.clipId)) continue;
      await _ensureAudioController(layer);
      final audio = _audioControllers[layer.clipId];
      if (audio == null || !audio.value.isInitialized) continue;
      final target = Duration(
        milliseconds: layer.localTimeMs.clamp(0, audio.value.duration.inMilliseconds),
      );
      if ((audio.value.position - target).inMilliseconds.abs() > 80) {
        await audio.seekTo(target);
      }
      await audio.setVolume(layer.volume.clamp(0, 1));
      if (_isPlaying && !audio.value.isPlaying && layer.volume > 0) {
        await audio.play();
      } else if ((!_isPlaying || layer.volume <= 0) && audio.value.isPlaying) {
        await audio.pause();
      }
    }
  }

  Future<void> _preview(MediaAsset asset) async {
    _controller.selectAsset(asset.id);
    if (asset.kind == MediaKind.video) {
      final frame = _controller.composition;
      await _syncPreviewVideos(frame);
    }
    if (mounted) setState(() {});
  }

  void _togglePlayback() {
    setState(() => _isPlaying = !_isPlaying);
    if (_isPlaying) {
      _playTimer?.cancel();
      _playTimer = Timer.periodic(const Duration(milliseconds: 33), (_) {
        if (!_isPlaying || !mounted) return;
        final next = _controller.playheadMs + 33;
        if (next >= _controller.timelineDurationMs) {
          _controller.setPlayhead(_controller.timelineDurationMs);
          setState(() => _isPlaying = false);
          _playTimer?.cancel();
        } else {
          _controller.setPlayhead(next);
        }
      });
    } else {
      _playTimer?.cancel();
      for (final video in _videoControllers.values) {
        video.pause();
      }
      for (final audio in _audioControllers.values) {
        audio.pause();
      }
    }
    _syncPreviewVideos(_controller.composition);
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    builder: (context, _) {
      final compact = MediaQuery.sizeOf(context).width < 950;
      return Scaffold(
        appBar: _buildToolbar(context),
        body: compact
            ? _buildCompactLayout(context)
            : _buildDesktopLayout(context),
        bottomNavigationBar: _buildStatusBar(),
      );
    },
  );

  PreferredSizeWidget _buildToolbar(BuildContext context) {
    final compact = MediaQuery.sizeOf(context).width < 650;
    return AppBar(
      backgroundColor: const Color(0xff101720),
      titleSpacing: 12,
      title: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: const Color(0xff00d9a6),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.movie_creation_outlined,
              color: Colors.black,
              size: 18,
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            'OpenReel',
            style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .2),
          ),
          if (!compact) ...[
            const SizedBox(width: 14),
            Flexible(
              child: Text(
                _controller.project.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white.withOpacity(.55),
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ],
      ),
      actions: [
        if (compact)
          PopupMenuButton<String>(
            tooltip: 'Ações do projeto',
            onSelected: (value) {
              switch (value) {
                case 'new':
                  _newProject();
                case 'open':
                  _openProject();
                case 'save':
                  _controller.save();
                case 'duplicate':
                  _controller.duplicateProject();
                case 'undo':
                  _controller.undo();
                case 'redo':
                  _controller.redo();
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'new', child: Text('Novo projeto')),
              PopupMenuItem(value: 'open', child: Text('Abrir projeto')),
              PopupMenuItem(value: 'save', child: Text('Salvar')),
              PopupMenuItem(
                value: 'duplicate',
                child: Text('Duplicar projeto'),
              ),
              PopupMenuItem(value: 'undo', child: Text('Desfazer')),
              PopupMenuItem(value: 'redo', child: Text('Refazer')),
            ],
          )
        else ...[
          IconButton(
            tooltip: 'Novo projeto',
            onPressed: _controller.isBusy ? null : _newProject,
            icon: const Icon(Icons.add_box_outlined),
          ),
          IconButton(
            tooltip: 'Abrir projeto',
            onPressed: _controller.isBusy ? null : _openProject,
            icon: const Icon(Icons.folder_open_outlined),
          ),
          IconButton(
            tooltip: 'Salvar',
            onPressed: _controller.isBusy ? null : _controller.save,
            icon: const Icon(Icons.save_outlined),
          ),
          IconButton(
            tooltip: 'Desfazer',
            onPressed: _controller.isBusy ? null : _controller.undo,
            icon: const Icon(Icons.undo),
          ),
          IconButton(
            tooltip: 'Refazer',
            onPressed: _controller.isBusy ? null : _controller.redo,
            icon: const Icon(Icons.redo),
          ),
        ],
        IconButton(
          tooltip: 'Biblioteca 3D',
          onPressed: _controller.isBusy ? null : () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => Model3DLibraryPage(controller: _controller)),
            );
          },
          icon: const Icon(Icons.view_in_ar_outlined, size: 19),
        ),
        IconButton(
          tooltip: 'Configurações do projeto',
          onPressed: _controller.isBusy ? null : _projectSettings,
          icon: const Icon(Icons.tune_outlined, size: 19),
        ),
        const SizedBox(width: 4),
        compact
            ? IconButton(
                tooltip: 'Exportar',
                onPressed: _controller.isBusy ? null : _export,
                icon: const Icon(Icons.ios_share, size: 19),
              )
            : FilledButton.icon(
                onPressed: _controller.isBusy ? null : _export,
                icon: const Icon(Icons.ios_share, size: 17),
                label: const Text('Exportar'),
              ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildDesktopLayout(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      SizedBox(width: 235, child: _buildMediaPanel()),
      Expanded(
        child: Column(
          children: [
            Expanded(flex: 5, child: _buildPreviewPanel()),
            Expanded(flex: 4, child: _buildTimelinePanel()),
          ],
        ),
      ),
      SizedBox(width: 280, child: _buildInspectorPanel()),
    ],
  );

  Widget _buildCompactLayout(BuildContext context) => ListView(
    children: [
      SizedBox(height: 230, child: _buildPreviewPanel()),
      SizedBox(height: 250, child: _buildTimelinePanel()),
      SizedBox(height: 270, child: _buildMediaPanel()),
      SizedBox(height: 310, child: _buildInspectorPanel()),
    ],
  );

  Widget _panel({
    required String title,
    required Widget child,
    Widget? trailing,
  }) => Container(
    decoration: const BoxDecoration(
      color: Color(0xff111923),
      border: Border(
        right: BorderSide(color: Color(0xff26313d)),
        bottom: BorderSide(color: Color(0xff26313d)),
      ),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 10, 10),
          child: Row(
            children: [
              Text(
                title.toUpperCase(),
                style: const TextStyle(
                  fontSize: 11,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.w700,
                  color: Color(0xff9baabd),
                ),
              ),
              const Spacer(),
              if (trailing != null) trailing,
            ],
          ),
        ),
        Expanded(child: child),
      ],
    ),
  );

  Widget _buildMediaPanel() => _panel(
    title: 'Mídia',
    trailing: IconButton(
      tooltip: 'Importar mídia',
      onPressed: _controller.isBusy ? null : _controller.importMedia,
      icon: const Icon(Icons.add, size: 18),
    ),
    child: Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
          child: OutlinedButton.icon(
            onPressed: _controller.isBusy ? null : _controller.importMedia,
            icon: const Icon(Icons.file_upload_outlined, size: 17),
            label: const Text('Importar arquivos'),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(38),
            ),
          ),
        ),
        Expanded(
          child: _controller.project.assets.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(22),
                    child: Text(
                      'Importe vídeos, áudios ou imagens para começar.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xff78879a), fontSize: 12),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: _controller.project.assets.length,
                  itemBuilder: (_, index) {
                    final asset = _controller.project.assets[index];
                    final selected = asset.id == _controller.selectedAssetId;
                    return ListTile(
                      selected: selected,
                      dense: true,
                      onTap: () => _preview(asset),
                      leading: _assetThumb(asset, size: 42),
                      title: Text(
                        asset.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12),
                      ),
                      subtitle: Text(
                        '${asset.kind.name}  ${asset.resolution}',
                        style: const TextStyle(
                          fontSize: 10,
                          color: Color(0xff748398),
                        ),
                      ),
                      trailing: asset.hasAudio
                          ? const Icon(Icons.volume_up_outlined, size: 14)
                          : null,
                    );
                  },
                ),
        ),
      ],
    ),
  );

  Widget _assetThumb(MediaAsset asset, {double size = 52}) => Container(
    width: size,
    height: size,
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(
      color: const Color(0xff202b38),
      borderRadius: BorderRadius.circular(6),
    ),
    child:
        asset.thumbnailPath != null && File(asset.thumbnailPath!).existsSync()
        ? Image.file(File(asset.thumbnailPath!), fit: BoxFit.cover)
        : Icon(
            _iconForKind(asset.kind),
            color: const Color(0xff8b9aad),
            size: size * .42,
          ),
  );

  IconData _iconForKind(MediaKind kind) => switch (kind) {
    MediaKind.video => Icons.movie_outlined,
    MediaKind.audio => Icons.audiotrack_outlined,
    MediaKind.image => Icons.image_outlined,
    MediaKind.gif => Icons.gif_box_outlined,
    _ => Icons.insert_drive_file_outlined,
  };

  Widget _buildPreviewPanel() => Container(
    color: const Color(0xff0b1016),
    child: Column(
      children: [
        Expanded(child: Center(child: _buildPreviewContent())),
        Container(
          height: 48,
          decoration: const BoxDecoration(
            color: Color(0xff121b25),
            border: Border(top: BorderSide(color: Color(0xff26313d))),
          ),
          child: Row(
            children: [
              IconButton(
                tooltip: 'Retroceder 1 segundo',
                onPressed: () =>
                    _controller.setPlayhead(_controller.playheadMs - 1000),
                icon: const Icon(Icons.skip_previous, size: 19),
              ),
              IconButton(
                tooltip: 'Reproduzir ou pausar',
                onPressed: _controller.timelineDurationMs == 0
                    ? null
                    : _togglePlayback,
                icon: Icon(
                  _isPlaying ? Icons.pause : Icons.play_arrow,
                  size: 22,
                ),
              ),
              IconButton(
                tooltip: 'Avançar 1 segundo',
                onPressed: () =>
                    _controller.setPlayhead(_controller.playheadMs + 1000),
                icon: const Icon(Icons.skip_next, size: 19),
              ),
              const SizedBox(width: 10),
              Text(
                _formatTime(_controller.playheadMs),
                style: const TextStyle(
                  fontFeatures: [FontFeature.tabularFigures()],
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Slider(
                  value: _controller.timelineDurationMs == 0
                      ? 0
                      : _controller.playheadMs.toDouble().clamp(
                          0,
                          _controller.timelineDurationMs.toDouble(),
                        ),
                  max:
                      (_controller.timelineDurationMs == 0
                              ? 1
                              : _controller.timelineDurationMs)
                          .toDouble(),
                  onChanged: (value) => _controller.setPlayhead(value.round()),
                ),
              ),
              Text(
                _formatTime(_controller.timelineDurationMs),
                style: const TextStyle(
                  fontFeatures: [FontFeature.tabularFigures()],
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 12),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _buildPreviewContent() {
    final frame = _controller.composition;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _syncPreviewVideos(frame);
    });
    if (frame.visualLayers.isEmpty) {
      return const Text(
        'Preview',
        style: TextStyle(color: Color(0xff57687a), fontSize: 17),
      );
    }

    final assetsByPath = <String, MediaAsset>{
      for (final asset in _controller.project.assets) ...{
        asset.path: asset,
        if (asset.proxyPath != null) asset.proxyPath!: asset,
      },
    };
    final active3d = frame.visualLayers.map((l) => l.clipId).toSet();
    _model3dControllers.removeWhere((id, _) => !active3d.contains(id));
    final canvas = Stack(
      clipBehavior: Clip.hardEdge,
      children: [
        for (final layer in frame.visualLayers) _buildPreviewLayer(layer, assetsByPath),
      ],
    );
    return AspectRatio(
      aspectRatio: _controller.project.width / _controller.project.height,
      child: FittedBox(
        fit: BoxFit.contain,
        child: SizedBox(
          width: _controller.project.width.toDouble(),
          height: _controller.project.height.toDouble(),
          child: canvas,
        ),
      ),
    );
  }

  Widget _buildPreviewLayer(
    CompositionLayer layer,
    Map<String, MediaAsset> assetsByPath,
  ) {
    final asset = layer.sourcePath == null ? null : assetsByPath[layer.sourcePath!];
    Widget child;
    if (layer.object3dAssetId != null && layer.sourcePath != null) {
      final controller = _model3dControllers.putIfAbsent(
        layer.clipId,
        Flutter3DController.new,
      );
      child = ClipRect(
        child: Flutter3DViewer(
          key: ValueKey('${layer.clipId}:${layer.sourcePath}'),
          controller: controller,
          src: layer.sourcePath!,
          enableTouch: !_isPlaying,
          progressBarColor: Colors.transparent,
          onError: (_) {},
        ),
      );
    } else if (layer.text != null) {
      final style = layer.subtitleStyle;
      final textStyle = layer.textStyle;
      final color = _parseColor(style?.color ?? textStyle.color, Colors.white);
      final outline = _parseColor(
        style?.outlineColor ?? textStyle.outlineColor,
        Colors.black,
      );
      child = Text(
        layer.text!,
        textAlign: _textAlign(style?.x != null ? 'center' : textStyle.align),
        style: TextStyle(
          fontFamily: style?.fontFamily ?? textStyle.fontFamily,
          fontSize: style?.fontSize ?? textStyle.fontSize,
          fontWeight: FontWeight.values[(style == null
                  ? ((textStyle.fontWeight - 100) ~/ 100).clamp(0, 8)
                  : 6)],
          color: color.withOpacity(layer.opacity * (style == null ? textStyle.opacity : 1)),
          shadows: [
            Shadow(
              color: outline,
              blurRadius: style?.outlineWidth ?? textStyle.outlineWidth,
            ),
          ],
        ),
      );
      if ((style?.background ?? textStyle.background) != 'transparent') {
        child = DecoratedBox(
          decoration: BoxDecoration(
            color: _parseColor(style?.background ?? textStyle.background, Colors.black54),
          ),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), child: child),
        );
      }
    } else if (asset != null && asset.kind == MediaKind.video) {
      final video = _videoControllers[layer.clipId];
      final future = _videoInitializations[layer.clipId];
      child = future == null
          ? const SizedBox.shrink()
          : FutureBuilder<void>(
              future: future,
              builder: (_, snapshot) => snapshot.connectionState == ConnectionState.done &&
                      video?.value.isInitialized == true
                  ? FittedBox(
                      fit: BoxFit.contain,
                      child: SizedBox(
                        width: video!.value.size.width,
                        height: video.value.size.height,
                        child: VideoPlayer(video),
                      ),
                    )
                  : const Center(child: CircularProgressIndicator()),
            );
    } else if (asset != null) {
      child = Image.file(File(asset.path), fit: BoxFit.contain);
    } else {
      return const SizedBox.shrink();
    }

    child = _applyPreviewEffects(child, layer.effects);
    final is3d = layer.object3dAssetId != null;
    final t3d = layer.transform3D;
    final left = is3d ? t3d.x : layer.transform.x;
    final top = is3d ? t3d.y : layer.transform.y;
    final matrix = Matrix4.identity();
    if (is3d) {
      matrix
        ..translate(0.0, 0.0, t3d.z)
        ..rotateX(t3d.rotationX * 3.1415926535 / 180)
        ..rotateY(t3d.rotationY * 3.1415926535 / 180)
        ..rotateZ(t3d.rotationZ * 3.1415926535 / 180)
        ..scale(t3d.scale);
    } else {
      matrix
        ..rotateZ(layer.transform.rotation * 3.1415926535 / 180)
        ..scale(layer.transform.scaleX, layer.transform.scaleY);
    }
    return Positioned(
      left: left,
      top: top,
      child: Transform(
        alignment: Alignment.center,
        transform: matrix,
        child: Opacity(
          opacity: (layer.opacity * (is3d ? t3d.opacity : 1)).clamp(0, 1),
          child: _applyBlend(child, layer.blendMode),
        ),
      ),
    );
  }

  Widget _applyBlend(Widget child, BlendMode mode) {
    // Flutter's widget compositor does not expose backdrop blend semantics for
    // arbitrary video textures. Do not fake them with a ColorFilter: the model
    // and FFmpeg export retain the requested mode, while the live preview stays
    // explicitly normal for unsupported modes.
    return child;
  }

  Widget _applyPreviewEffects(Widget child, List<EffectConfig> effects) {
    var result = child;
    for (final effect in effects) {
      switch (effect.type) {
        case 'grayscale':
          result = ColorFiltered(
            colorFilter: const ColorFilter.matrix(<double>[
              .2126, .7152, .0722, 0, 0,
              .2126, .7152, .0722, 0, 0,
              .2126, .7152, .0722, 0, 0,
              0, 0, 0, 1, 0,
            ]),
            child: result,
          );
        case 'brightness':
        case 'contrast':
        case 'saturation':
          result = ColorFiltered(
            colorFilter: _effectColorFilter(effect),
            child: result,
          );
        case 'blur':
          result = ImageFiltered(
            imageFilter: ui.ImageFilter.blur(
              sigmaX: (effect.parameters['radius'] ?? 2).clamp(0.0, 20.0),
              sigmaY: (effect.parameters['radius'] ?? 2).clamp(0.0, 20.0),
            ),
            child: result,
          );
        default:
          // Effects without a reliable GPU equivalent remain export-only.
          break;
      }
    }
    return result;
  }

  ColorFilter _effectColorFilter(EffectConfig effect) {
    final value = effect.parameters['value'] ?? 0;
    if (effect.type == 'brightness') {
      final b = value.clamp(-1.0, 1.0);
      return ColorFilter.matrix(<double>[
        1, 0, 0, 0, b * 255,
        0, 1, 0, 0, b * 255,
        0, 0, 1, 0, b * 255,
        0, 0, 0, 1, 0,
      ]);
    }
    if (effect.type == 'contrast') {
      final c = value;
      final t = 128 * (1 - c);
      return ColorFilter.matrix(<double>[
        c, 0, 0, 0, t, 0, c, 0, 0, t, 0, 0, c, 0, t, 0, 0, 0, 1, 0,
      ]);
    }
    final s = value;
    final ir = .2126 * (1 - s), ig = .7152 * (1 - s), ib = .0722 * (1 - s);
    return ColorFilter.matrix(<double>[
      ir + s, ig, ib, 0, 0,
      ir, ig + s, ib, 0, 0,
      ir, ig, ib + s, 0, 0,
      0, 0, 0, 1, 0,
    ]);
  }

  TextAlign _textAlign(String value) => switch (value) {
    'left' => TextAlign.left,
    'right' => TextAlign.right,
    _ => TextAlign.center,
  };

  Color _parseColor(String value, Color fallback) {
    final normalized = value.trim().toLowerCase();
    const names = <String, Color>{
      'white': Colors.white,
      'black': Colors.black,
      'red': Colors.red,
      'green': Colors.green,
      'blue': Colors.blue,
      'yellow': Colors.yellow,
      'transparent': Colors.transparent,
    };
    if (names.containsKey(normalized)) return names[normalized]!;
    final hex = normalized.replaceFirst('#', '');
    final value64 = int.tryParse(hex.length == 6 ? 'ff$hex' : hex, radix: 16);
    return value64 == null ? fallback : Color(value64);
  }

  Widget _buildTimelinePanel() => Container(
    color: const Color(0xff0e151e),
    child: Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 5),
          child: Row(
            children: [
              const Text(
                'TIMELINE',
                style: TextStyle(
                  fontSize: 11,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.w700,
                  color: Color(0xff9baabd),
                ),
              ),
              const Spacer(),
              IconButton(
                tooltip: 'Adicionar texto',
                onPressed: () => _addText(),
                icon: const Icon(Icons.title, size: 18),
              ),
              IconButton(
                tooltip: 'Importar SRT/VTT',
                onPressed: _controller.isBusy ? null : _controller.importSubtitles,
                icon: const Icon(Icons.subtitles_outlined, size: 18),
              ),
              IconButton(
                tooltip: 'Copiar clipe',
                onPressed: _controller.copySelected,
                icon: const Icon(Icons.copy_outlined, size: 18),
              ),
              IconButton(
                tooltip: 'Colar clipe',
                onPressed: _controller.pasteClipboard,
                icon: const Icon(Icons.content_paste_outlined, size: 18),
              ),
              IconButton(
                tooltip: 'Cortar no playhead',
                onPressed: _controller.splitSelected,
                icon: const Icon(Icons.content_cut, size: 18),
              ),
              IconButton(
                tooltip: 'Excluir',
                onPressed: () => _controller.deleteSelected(ripple: true),
                icon: const Icon(Icons.delete_outline, size: 18),
              ),
              IconButton(
                tooltip: 'Adicionar/remover marcador',
                onPressed: _controller.toggleMarkerAtPlayhead,
                icon: const Icon(Icons.bookmark_outline, size: 18),
              ),
              const SizedBox(width: 7),
              SizedBox(
                width: 90,
                child: Slider(
                  value: _controller.zoom,
                  min: .02,
                  max: .4,
                  onChanged: _controller.setZoom,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: TimelineWidget(
            controller: _controller,
            onSelectAsset: _preview,
          ),
        ),
      ],
    ),
  );

  Widget _buildInspectorPanel() => _panel(
    title: 'Inspector',
    child: ListView(
      padding: const EdgeInsets.all(12),
      children: [
        if (_controller.selectedClip == null)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 22),
            child: Text(
              'Selecione um clipe para editar propriedades.',
              style: TextStyle(color: Color(0xff78879a), fontSize: 12),
            ),
          )
        else ...[
          _sectionTitle('Transformação'),
          _numberTile('Posição X', _controller.selectedClip!.transform.x, -2000, 2000, (value) {
            _controller.setTransform(x: value);
          }),
          _numberTile('Posição Y', _controller.selectedClip!.transform.y, -2000, 2000, (value) {
            _controller.setTransform(y: value);
          }),
          _numberTile('Escala X', _controller.selectedClip!.transform.scaleX, .1, 4, (value) {
            _controller.setTransform(scaleX: value);
          }),
          _numberTile('Escala Y', _controller.selectedClip!.transform.scaleY, .1, 4, (value) {
            _controller.setTransform(scaleY: value);
          }),
          _numberTile('Rotação', _controller.selectedClip!.transform.rotation, -360, 360, (value) {
            _controller.setTransform(rotation: value);
          }),
          _numberTile('Opacidade', _controller.selectedClip!.opacity, 0, 1, (value) {
            _controller.setOpacity(value);
          }),
          _numberTile('Volume', _controller.selectedClip!.volume, 0, 1, (value) {
            _controller.setVolume(value);
          }),
          SwitchListTile.adaptive(
            contentPadding: EdgeInsets.zero,
            dense: true,
            title: const Text('Silenciar', style: TextStyle(fontSize: 12)),
            value: _controller.selectedClip!.muted,
            onChanged: (_) => _controller.toggleSelectedMute(),
          ),
          const SizedBox(height: 12),
          _sectionTitle('Velocidade'),
          DropdownButtonFormField<double>(
            value: _controller.selectedClip!.speed,
            decoration: const InputDecoration(
              isDense: true,
              border: OutlineInputBorder(),
            ),
            items: const <double>[0.25, .5, .75, 1, 1.25, 1.5, 2, 4]
                .map<DropdownMenuItem<double>>(
                  (value) => DropdownMenuItem<double>(
                    value: value,
                    child: Text('${value}×'),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) _controller.setSpeed(value);
            },
          ),
          const SizedBox(height: 12),
          _sectionTitle('Transição'),
          DropdownButtonFormField<String>(
            value: _controller.selectedClip!.transitionIn.type,
            decoration: const InputDecoration(
              isDense: true,
              border: OutlineInputBorder(),
              labelText: 'Entrada',
            ),
            items: const [
              DropdownMenuItem(value: 'none', child: Text('Nenhuma')),
              DropdownMenuItem(value: 'fade', child: Text('Fade / Crossfade')),
            ],
            onChanged: (value) {
              if (value == null) return;
              _controller.setTransitionIn(
                TransitionConfig(
                  type: value,
                  durationMs: value == 'none' ? 0 : 500,
                ),
              );
            },
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _controller.selectedClip!.transitionOut.type,
            decoration: const InputDecoration(
              isDense: true,
              border: OutlineInputBorder(),
              labelText: 'Saída',
            ),
            items: const [
              DropdownMenuItem(value: 'none', child: Text('Nenhuma')),
              DropdownMenuItem(value: 'fade', child: Text('Fade')),
            ],
            onChanged: (value) {
              if (value == null) return;
              _controller.setTransitionOut(
                TransitionConfig(
                  type: value,
                  durationMs: value == 'none' ? 0 : 500,
                ),
              );
            },
          ),
          const SizedBox(height: 12),
          _sectionTitle('Efeitos não destrutivos'),
          Wrap(
            spacing: 5,
            runSpacing: 5,
            children:
                [
                      'brightness',
                      'contrast',
                      'saturation',
                      'blur',
                      'sharpen',
                      'grayscale',
                      'vignette',
                    ]
                    .map(
                      (effect) => ActionChip(
                        label: Text(
                          effect,
                          style: const TextStyle(fontSize: 10),
                        ),
                        onPressed: () =>
                            _controller.addEffect(EffectConfig(type: effect)),
                      ),
                    )
                    .toList(),
          ),
          const SizedBox(height: 12),
          _sectionTitle('Keyframes'),
          Wrap(
            spacing: 5,
            runSpacing: 5,
            children: ['opacity', 'scale', 'rotation', 'volume', 'position']
                .map(
                  (property) => OutlinedButton(
                    onPressed: () => _controller.addKeyframe(
                      property: property,
                      value: property == 'opacity'
                          ? _controller.selectedClip!.opacity
                          : 1,
                    ),
                    child: Text(
                      '+ $property',
                      style: const TextStyle(fontSize: 10),
                    ),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              OutlinedButton.icon(
                onPressed: _controller.trimStartSelected,
                icon: const Icon(Icons.first_page, size: 15),
                label: const Text('Trim início'),
              ),
              OutlinedButton.icon(
                onPressed: _controller.trimEndSelected,
                icon: const Icon(Icons.last_page, size: 15),
                label: const Text('Trim fim'),
              ),
              OutlinedButton.icon(
                onPressed: _controller.duplicateSelected,
                icon: const Icon(Icons.copy, size: 15),
                label: const Text('Duplicar'),
              ),
            ],
          ),
        ],
      ],
    ),
  );

  Widget _sectionTitle(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 7),
    child: Text(
      text,
      style: const TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: Color(0xff9baabd),
      ),
    ),
  );

  Widget _numberTile(
    String label,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged,
  ) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        label,
        style: const TextStyle(fontSize: 11, color: Color(0xff78879a)),
      ),
      Slider(
        value: value.clamp(min, max),
        min: min,
        max: max,
        onChanged: onChanged,
      ),
    ],
  );

  Widget _buildStatusBar() => Container(
    height: 25,
    color: const Color(0xff0a0f14),
    padding: const EdgeInsets.symmetric(horizontal: 12),
    child: Row(
      children: [
        Text(
          _controller.status,
          style: const TextStyle(fontSize: 10, color: Color(0xff7e8da1)),
        ),
        const Spacer(),
        if (_controller.isBusy) ...[
          SizedBox(
            width: 120,
            child: LinearProgressIndicator(
              value: _controller.exportProgress == 0
                  ? null
                  : _controller.exportProgress,
              minHeight: 3,
            ),
          ),
          const SizedBox(width: 6),
          SizedBox(
            height: 22,
            child: TextButton(
              onPressed: _controller.cancelExport,
              child: const Text('Cancelar', style: TextStyle(fontSize: 10)),
            ),
          ),
        ],
        const SizedBox(width: 12),
        Text(
          '${_controller.project.width}×${_controller.project.height}  ${_controller.project.fps} FPS',
          style: const TextStyle(fontSize: 10, color: Color(0xff7e8da1)),
        ),
      ],
    ),
  );

  Future<void> _projectSettings() async {
    var width = _controller.project.width;
    var height = _controller.project.height;
    var fps = _controller.project.fps;
    var format = ['1920x1080', '1080x1920', '1080x1080', '1280x720']
        .contains('${width}x$height')
        ? '${width}x$height'
        : 'custom';
    final widthField = TextEditingController(text: '$width');
    final heightField = TextEditingController(text: '$height');
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Configurações do projeto'),
          content: SizedBox(
            width: 360,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: format,
                  decoration: const InputDecoration(labelText: 'Formato'),
                  items: const [
                    DropdownMenuItem(value: '1920x1080', child: Text('16:9 · 1920×1080')),
                    DropdownMenuItem(value: '1080x1920', child: Text('9:16 · 1080×1920')),
                    DropdownMenuItem(value: '1080x1080', child: Text('1:1 · 1080×1080')),
                    DropdownMenuItem(value: '1280x720', child: Text('16:9 · 1280×720')),
                    DropdownMenuItem(value: 'custom', child: Text('Personalizado')),
                  ],
                  onChanged: (value) {
                    if (value == null) return;
                    if (value == 'custom') {
                      setDialogState(() => format = 'custom');
                      return;
                    }
                    final parts = value.split('x');
                    setDialogState(() {
                      format = value;
                      width = int.parse(parts[0]);
                      height = int.parse(parts[1]);
                      widthField.text = '$width';
                      heightField.text = '$height';
                    });
                  },
                ),
                if (format == 'custom') ...[
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: widthField,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Largura',
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (value) => width = int.tryParse(value) ?? width,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: heightField,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Altura',
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (value) => height = int.tryParse(value) ?? height,
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  value: fps,
                  decoration: const InputDecoration(labelText: 'FPS'),
                  items: const [24, 25, 30, 50, 60].map((v) => DropdownMenuItem(value: v, child: Text('$v FPS'))).toList(),
                  onChanged: (value) => setDialogState(() => fps = value ?? fps),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Aplicar')),
          ],
        ),
      ),
    );
    widthField.dispose();
    heightField.dispose();
    if (result == true) {
      _controller.updateProjectSettings(width: width, height: height, fps: fps);
    }
  }

  Future<void> _openProject() async {
    final projects = await _controller.listProjects();
    if (!mounted) return;
    final selected = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Abrir projeto'),
        content: SizedBox(
          width: 420,
          height: 300,
          child: projects.isEmpty
              ? const Center(child: Text('Nenhum projeto salvo.'))
              : ListView.builder(
                  itemCount: projects.length,
                  itemBuilder: (_, index) {
                    final project = projects[index];
                    return ListTile(
                      title: Text(project.name),
                      subtitle: Text(project.modifiedAt.toLocal().toString()),
                      onTap: () => Navigator.pop(context, project.id),
                      trailing: IconButton(
                        tooltip: 'Excluir projeto',
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          await _controller.deleteProject(project.id);
                          if (context.mounted) Navigator.pop(context);
                        },
                      ),
                    );
                  },
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
    if (selected != null) await _controller.load(selected);
  }

  Future<void> _newProject() async {
    final name = await _textDialog('Novo projeto', 'Nome do projeto');
    if (name != null) {
      await _controller.newProject();
      await _controller.saveAs(name);
    }
  }

  Future<void> _addText() async {
    final text = await _textDialog('Adicionar texto', 'Texto do título');
    if (text != null) _controller.addText(text);
  }

  Future<void> _export() async {
    final uri = await FilePicker.saveFile(
      dialogTitle: 'Exportar vídeo',
      fileName: '${_controller.project.name}.mp4',
      bytes: Uint8List(0),
      mimeType: 'video/mp4',
    );
    if (uri == null) return;
    if (uri.scheme == 'file') {
      await _controller.exportTo(uri.toFilePath());
    } else {
      await _controller.export();
    }
  }

  Future<String?> _textDialog(String title, String hint) async {
    final field = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: field,
          autofocus: true,
          decoration: InputDecoration(
            hintText: hint,
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, field.text),
            child: const Text('Confirmar'),
          ),
        ],
      ),
    );
    field.dispose();
    return result;
  }

  String _formatTime(int milliseconds) {
    final seconds = milliseconds ~/ 1000;
    final minutes = seconds ~/ 60;
    return '${minutes.toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}.${(milliseconds % 1000 ~/ 10).toString().padLeft(2, '0')}';
  }
}

