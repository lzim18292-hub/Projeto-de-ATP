
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/model3d.dart';
import '../models/timeline.dart';
import '../state/editor_controller.dart';

class Model3DLibraryPage extends StatefulWidget {
  const Model3DLibraryPage({super.key, required this.controller});
  final EditorController controller;
  @override State<Model3DLibraryPage> createState() => _Model3DLibraryPageState();
}

class _Model3DLibraryPageState extends State<Model3DLibraryPage> {
  final _service = Model3DService();
  bool _busy = false;

  Future<void> _import() async {
    final result = await FilePicker.pickFile(type: FileType.custom, allowedExtensions: const ['glb', 'gltf']);
    final path = result?.path;
    if (path == null) return;
    setState(() => _busy = true);
    try {
      final modelId = const Uuid().v4();
      final durablePath = await _service.persistFile(path, modelId);
      final model = await _service.inspect(
        id: modelId, path: durablePath,
        name: path.split(Platform.pathSeparator).last,
      );
      if (!mounted) return;
      final metadata = await _metadata(model);
      if (metadata == null) return;
      model.origin = metadata.origin; model.author = metadata.author;
      model.license = metadata.license; model.sourceUrl = metadata.url;
      widget.controller.project.model3dAssets.add(model);
      widget.controller.refresh();
      await widget.controller.save();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<({String origin, String author, String license, String url})?> _metadata(Model3DAsset model) async {
    final origin = TextEditingController();
    final author = TextEditingController();
    final license = TextEditingController();
    final url = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Registrar ${model.name}'),
        content: SingleChildScrollView(child: Column(children: [
          TextField(controller: origin, decoration: const InputDecoration(labelText: 'Origem')),
          TextField(controller: author, decoration: const InputDecoration(labelText: 'Autor')),
          TextField(controller: license, decoration: const InputDecoration(labelText: 'Licença')),
          TextField(controller: url, decoration: const InputDecoration(labelText: 'URL/origem')),
          const SizedBox(height: 12),
          const Text('A licença não é inferida automaticamente. Informe os dados da fonte.', style: TextStyle(fontSize: 12)),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Confirmar')),
        ],
      ),
    );
    final result = ok == true ? (origin: origin.text, author: author.text, license: license.text, url: url.text) : null;
    origin.dispose(); author.dispose(); license.dispose(); url.dispose();
    return result;
  }

  void _addToTimeline(Model3DAsset model) {
    final track = widget.controller.project.tracks.cast<TimelineTrack?>().firstWhere(
      (t) => t?.kind == TrackKind.object3d, orElse: () => null,
    ) ?? TimelineTrack(id: const Uuid().v4(), name: '3D', kind: TrackKind.object3d);
    if (!widget.controller.project.tracks.contains(track)) widget.controller.project.tracks.add(track);
    final duration = widget.controller.timelineDurationMs > 0 ? widget.controller.timelineDurationMs : 5000;
    track.clips.add(TimelineClip(
      id: const Uuid().v4(), assetId: '3d:${model.id}', object3dAssetId: model.id,
      trackId: track.id, startMs: widget.controller.playheadMs, durationMs: duration,
    ));
    widget.controller.refresh();
    widget.controller.save();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Objeto 3D adicionado à timeline.')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Biblioteca 3D'), actions: [
      IconButton(onPressed: _busy ? null : _import, icon: const Icon(Icons.add_box_outlined), tooltip: 'Importar GLB/GLTF'),
    ]),
    body: widget.controller.project.model3dAssets.isEmpty
      ? const Center(child: Text('Nenhum modelo 3D. Importe GLB ou GLTF.'))
      : ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: widget.controller.project.model3dAssets.length,
          itemBuilder: (_, i) {
            final model = widget.controller.project.model3dAssets[i];
            return Card(child: ListTile(
              leading: const Icon(Icons.view_in_ar_outlined),
              title: Text(model.name),
              subtitle: Text('${model.format.toUpperCase()} • ${model.fileSizeBytes} bytes • ${model.nodeCount} nós • ${model.animationCount} animações\n${model.author.isEmpty ? "Autor não informado" : model.author} • ${model.license.isEmpty ? "Licença não informada" : model.license}'),
              isThreeLine: true,
              trailing: FilledButton(onPressed: () => _addToTimeline(model), child: const Text('Adicionar')),
            ));
          },
        ),
  );
}
