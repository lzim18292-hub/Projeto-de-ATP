# IA local

A camada de IA deve permanecer opcional e offline. Nesta versão, o projeto não baixa modelos nem expõe botões que dependam de um modelo ausente.

## Integração planejada

| Módulo | Entrada | Saída esperada |
| --- | --- | --- |
| Transcrição | WAV/áudio extraído | segmentos com início, fim e texto para legendas |
| Detecção de silêncio | waveform e energia | intervalos removíveis ou marcadores |
| Detecção de cenas | frames amostrados | cortes e marcadores de mudança de cena |
| Rostos/objeto principal | frames | caixas normalizadas e trilha de acompanhamento |
| Auto-reframe | caixas + proporção | keyframes de posição e escala |
| Highlights | cenas, áudio e duração | seleção de clipes e marcadores |

## Regras de privacidade

Modelos devem ser carregados de um caminho local escolhido pelo usuário ou distribuídos de forma compatível com suas licenças. Nenhuma mídia deve ser enviada para a rede sem consentimento explícito. O resultado deve ser anexado ao JSON do projeto, permitindo desfazer ou editar a sugestão.

## Android e desktop

O carregamento de modelos exige bibliotecas diferentes por arquitetura e deve ficar atrás de uma interface Dart. O processamento pesado deve ocorrer em isolate ou código nativo, nunca no build da interface. A ausência do modelo precisa gerar uma mensagem clara e não impedir edição manual ou exportação.

## Implementação futura segura

Um módulo de IA pode implementar uma interface como `LocalAiProvider`, mas o app não deve carregar código arbitrário de plugins. Modelos e pesos são dados; executáveis nativos devem vir do pacote assinado e passar pelo processo de release.
