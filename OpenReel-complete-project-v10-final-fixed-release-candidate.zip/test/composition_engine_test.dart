import 'package:flutter_test/flutter_test.dart';
import 'package:openreel/models/project.dart';
import 'package:openreel/models/model3d.dart';
import 'package:openreel/models/timeline.dart';
import 'package:openreel/services/composition_engine.dart';
import 'package:openreel/services/subtitle_service.dart';

void main() {
  test('compõe clipe ativo usando tempo local e velocidade', () {
    final project = Project(id: 'p', name: 'Teste');
    final track = project.tracks.first;
    final clip = TimelineClip(
      id: 'c',
      assetId: 'missing',
      trackId: track.id,
      startMs: 1000,
      durationMs: 2000,
      sourceStartMs: 500,
      speed: 2,
    );
    track.clips.add(clip);
    final frame = CompositionEngine().compose(project, 1500);
    expect(frame.layers.single.localTimeMs, 1500);
    expect(frame.layers.single.startMs, 1000);
  });

  test('avalia keyframes de opacity entre dois pontos', () {
    final project = Project(id: 'p', name: 'Teste');
    final track = project.tracks.first;
    final clip = TimelineClip(
      id: 'c',
      assetId: 'missing',
      trackId: track.id,
      startMs: 0,
      durationMs: 2000,
      opacityKeyframes: [
        Keyframe(timeMs: 0, value: 0),
        Keyframe(timeMs: 1000, value: 1),
      ],
    );
    track.clips.add(clip);
    final layer = CompositionEngine().compose(project, 500).layers.single;
    expect(layer.opacity, closeTo(.5, .001));
  });

  test('avalia X e Y independentemente e preserva blend mode', () {
    final project = Project(id: 'p', name: 'XY');
    final track = project.tracks.first;
    final clip = TimelineClip(
      id: 'c',
      assetId: 'missing',
      trackId: track.id,
      startMs: 0,
      durationMs: 2000,
      blendMode: BlendMode.screen,
      positionXKeyframes: [
        Keyframe(timeMs: 0, value: 0),
        Keyframe(timeMs: 1000, value: 100),
      ],
      positionYKeyframes: [
        Keyframe(timeMs: 0, value: 50),
        Keyframe(timeMs: 1000, value: 150),
      ],
    );
    track.clips.add(clip);
    final layer = CompositionEngine().compose(project, 500).layers.single;
    expect(layer.transform.x, closeTo(50, .001));
    expect(layer.transform.y, closeTo(100, .001));
    expect(layer.blendMode, BlendMode.screen);
  });

  test('não compõe clip desabilitado nem track oculta', () {
    final project = Project(id: 'p', name: 'Estados');
    final visible = project.tracks.first;
    final disabled = TimelineClip(
      id: 'disabled',
      assetId: 'missing',
      trackId: visible.id,
      startMs: 0,
      durationMs: 1000,
      enabled: false,
    );
    visible.clips.add(disabled);
    final hidden = TimelineTrack(
      id: 'hidden',
      name: 'Hidden',
      kind: TrackKind.video,
      hidden: true,
    );
    hidden.clips.add(
      TimelineClip(
        id: 'hidden-clip',
        assetId: 'missing',
        trackId: hidden.id,
        startMs: 0,
        durationMs: 1000,
      ),
    );
    project.tracks.add(hidden);
    final frame = CompositionEngine().compose(project, 500);
    expect(frame.layers, isEmpty);
    expect(frame.audioLayers, isEmpty);
  });

  test('keyframes usam tempo da timeline mesmo com sourceStart', () {
    final project = Project(id: 'p', name: 'Offset');
    final track = project.tracks.first;
    track.clips.add(
      TimelineClip(
        id: 'offset',
        assetId: 'missing',
        trackId: track.id,
        startMs: 1000,
        durationMs: 2000,
        sourceStartMs: 5000,
        positionXKeyframes: [
          Keyframe(timeMs: 0, value: 0),
          Keyframe(timeMs: 1000, value: 100),
        ],
      ),
    );
    final layer = CompositionEngine().compose(project, 1500).layers.single;
    expect(layer.localTimeMs, 5500);
    expect(layer.transform.x, closeTo(50, .001));
  });


  test('legenda do track tem precedência sobre subtitleCues do projeto', () {
    final project = Project(id: 'sub', name: 'Subtitles');
    final track = TimelineTrack(id: 'sub-track', name: 'Legendas', kind: TrackKind.subtitle);
    track.clips.add(
      TimelineClip(
        id: 'track-sub',
        assetId: 'text:track',
        trackId: track.id,
        startMs: 0,
        durationMs: 1000,
        text: 'Legenda da timeline',
      ),
    );
    project.tracks.add(track);
    project.subtitleCues.add(
      SubtitleCue(startMs: 0, endMs: 1000, text: 'Legenda importada'),
    );
    final layers = CompositionEngine().compose(project, 500).subtitleLayers;
    expect(layers, hasLength(1));
    expect(layers.single.text, 'Legenda da timeline');
  });

  test('3D keyframes chegam ao CompositionFrame no tempo correto', () {
    final project = Project(id: 'p3d', name: '3D');
    final track = TimelineTrack(id: '3d', name: '3D', kind: TrackKind.object3d);
    project.tracks.add(track);
    project.model3dAssets.add(
      Model3DAsset(id: 'm', path: '/tmp/model.glb', name: 'model.glb'),
    );
    track.clips.add(
      TimelineClip(
        id: 'c3d',
        assetId: '3d:m',
        object3dAssetId: 'm',
        trackId: track.id,
        startMs: 0,
        durationMs: 2000,
        transform3D: const Transform3D(z: -2),
        rotationYKeyframes: const [
          Keyframe(timeMs: 0, value: 0),
          Keyframe(timeMs: 1000, value: 90),
        ],
      ),
    );
    final layer = CompositionEngine().compose(project, 500).layers.single;
    expect(layer.object3dAssetId, 'm');
    expect(layer.transform3D.z, -2);
    expect(layer.transform3D.rotationY, closeTo(45, .001));
  });
}
