import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:openreel/models/project.dart';
import 'package:openreel/models/timeline.dart';
import 'package:openreel/models/model3d.dart';

void main() {
  group('TimelineClip', () {
    test('trim left atualiza o início da fonte e a duração', () {
      final clip = TimelineClip(
        id: 'c',
        assetId: 'a',
        trackId: 'v',
        startMs: 0,
        durationMs: 10000,
        speed: 2,
      );
      clip.trimLeft(2000);
      expect(clip.startMs, 2000);
      expect(clip.sourceStartMs, 4000);
      expect(clip.durationMs, 8000);
    });

    test('trim left rebasa keyframes para o novo relógio da timeline', () {
      final clip = TimelineClip(
        id: 'c',
        assetId: 'a',
        trackId: 'v',
        startMs: 0,
        durationMs: 1000,
        positionXKeyframes: const [
          Keyframe(timeMs: 100, value: 10),
          Keyframe(timeMs: 500, value: 50),
          Keyframe(timeMs: 900, value: 90),
        ],
      );
      clip.trimLeft(400);
      expect(clip.positionXKeyframes.map((k) => k.timeMs), [100, 500]);
    });

    test('trim right remove keyframes além do novo fim', () {
      final clip = TimelineClip(
        id: 'c',
        assetId: 'a',
        trackId: 'v',
        startMs: 0,
        durationMs: 1000,
        positionXKeyframes: const [
          Keyframe(timeMs: 500, value: 50),
          Keyframe(timeMs: 900, value: 90),
        ],
      );
      clip.trimRight(400);
      expect(clip.positionXKeyframes.map((k) => k.timeMs), [500]);
    });

    test('trim right nunca deixa duração inválida', () {
      final clip = TimelineClip(
        id: 'c',
        assetId: 'a',
        trackId: 'v',
        startMs: 0,
        durationMs: 1000,
      );
      clip.trimRight(5000);
      expect(clip.durationMs, 1);
    });

    test('keyframe é serializável', () {
      const keyframe = Keyframe(
        timeMs: 250,
        value: .75,
        interpolation: Interpolation.easeInOut,
      );
      final restored = Keyframe.fromJson(
        jsonDecode(jsonEncode(keyframe.toJson())) as Map<String, dynamic>,
      );
      expect(restored.timeMs, 250);
      expect(restored.value, .75);
      expect(restored.interpolation, Interpolation.easeInOut);
    });
  });


  test('modelo 3D e transformação 3D são persistidos', () {
    final project = Project(id: 'p3d', name: '3D');
    final model = Model3DAsset(id: 'm', path: '/tmp/lua.glb', name: 'Lua.glb', license: 'CC0');
    project.model3dAssets.add(model);
    final track = TimelineTrack(id: '3d', name: '3D', kind: TrackKind.object3d);
    project.tracks.add(track);
    track.clips.add(TimelineClip(
      id: 'c3d', assetId: '3d:m', object3dAssetId: 'm', trackId: '3d',
      startMs: 0, durationMs: 1000,
      transform3D: const Transform3D(z: -2, rotationY: 45, scale: 1.5),
      rotationYKeyframes: const [Keyframe(timeMs: 0, value: 0), Keyframe(timeMs: 1000, value: 360)],
    ));
    final restored = Project.fromJson(jsonDecode(project.encode()) as Map<String, dynamic>);
    expect(restored.model3dAssets.single.license, 'CC0');
    expect(restored.tracks.last.kind, TrackKind.object3d);
    expect(restored.tracks.last.clips.single.transform3D.rotationY, 45);
    expect(restored.tracks.last.clips.single.rotationYKeyframes, hasLength(2));
  });

  test('projeto preserva configurações e trilhas no JSON', () {
    final project = Project(
      id: 'p',
      name: 'Teste',
      width: 1080,
      height: 1920,
      fps: 60,
      exportSettings: const ExportSettings(width: 1080, height: 1920, fps: 60),
    );
    final restored = Project.fromJson(
      jsonDecode(project.encode()) as Map<String, dynamic>,
    );
    expect(restored.name, 'Teste');
    expect(restored.width, 1080);
    expect(restored.height, 1920);
    expect(restored.fps, 60);
    expect(restored.tracks, isNotEmpty);
    expect(restored.exportSettings.width, 1080);
  });

  test('texto e transição são preservados no JSON', () {
    final project = Project(id: 'p', name: 'Texto');
    final clip = TimelineClip(
      id: 'c',
      assetId: 'text',
      trackId: project.tracks.first.id,
      startMs: 0,
      durationMs: 1000,
      text: 'Título',
      textStyle: const TextStyleConfig(fontSize: 64, color: 'yellow'),
      transitionIn: const TransitionConfig(type: 'fade', durationMs: 300),
    );
    project.tracks.first.clips.add(clip);
    final restored = Project.fromJson(
      jsonDecode(project.encode()) as Map<String, dynamic>,
    );
    final copy = restored.tracks.first.clips.single;
    expect(copy.textStyle.fontSize, 64);
    expect(copy.transitionIn.type, 'fade');
  });
}
