import 'package:flutter_test/flutter_test.dart';
import 'package:openreel/models/project.dart';
import 'package:openreel/models/timeline.dart';
import 'package:openreel/services/composition_engine.dart';

void main() {
  test('avalia velocidades e mantém tempo local consistente', () {
    final engine = CompositionEngine();
    for (final speed in [0.25, 0.5, 1.0, 2.0, 4.0]) {
      final project = Project(id: 'speed-$speed', name: 'Speed');
      final track = project.tracks.first;
      track.clips.add(
        TimelineClip(
          id: 'clip',
          assetId: 'asset',
          trackId: track.id,
          startMs: 1000,
          durationMs: 4000,
          sourceStartMs: 200,
          speed: speed,
        ),
      );
      final frame = engine.compose(project, 2000);
      expect(frame.layers.single.localTimeMs, 200 + (1000 * speed).round());
    }
  });

  test('compõe 1000 clips em múltiplas trilhas sem perder camadas ativas', () {
    final project = Project(id: 'stress', name: 'Stress');
    project.tracks.clear();
    for (var trackIndex = 0; trackIndex < 5; trackIndex++) {
      if (trackIndex >= project.tracks.length) {
        project.tracks.add(
          TimelineTrack(
            id: 'track-$trackIndex',
            name: 'Track $trackIndex',
            kind: TrackKind.video,
          ),
        );
      }
      final track = project.tracks[trackIndex];
      for (var i = 0; i < 200; i++) {
        track.clips.add(
          TimelineClip(
            id: '$trackIndex-$i',
            assetId: 'asset-$i',
            trackId: track.id,
            startMs: 0,
            durationMs: 60000,
          ),
        );
      }
    }
    final frame = CompositionEngine().compose(project, 1000);
    expect(frame.layers, hasLength(1000));
  });
}
