import 'package:flutter_test/flutter_test.dart';
import 'package:openreel/models/media_asset.dart';
import 'package:openreel/models/project.dart';
import 'package:openreel/models/timeline.dart';
import 'package:openreel/services/composition_engine.dart';
import 'package:openreel/services/subtitle_service.dart';

void main() {
  test('CompositionFrame representa vídeo, imagem e texto simultâneos', () {
    final project = Project(id: 'integration', name: 'Integration');
    project.tracks.clear();
    project.assets.addAll([
      const MediaAsset(
        id: 'video-a',
        path: '/tmp/a.mp4',
        name: 'A',
        kind: MediaKind.video,
      ),
      const MediaAsset(
        id: 'image',
        path: '/tmp/a.png',
        name: 'PNG',
        kind: MediaKind.image,
      ),
    ]);
    final video = TimelineTrack(id: 'v', name: 'Video', kind: TrackKind.video);
    final overlay = TimelineTrack(
      id: 'o',
      name: 'Overlay',
      kind: TrackKind.overlay,
    );
    project.tracks.addAll([video, overlay]);
    video.clips.add(
      TimelineClip(
        id: 'a',
        assetId: 'video-a',
        trackId: 'v',
        startMs: 0,
        durationMs: 5000,
      ),
    );
    overlay.clips.add(
      TimelineClip(
        id: 'png',
        assetId: 'image',
        trackId: 'o',
        startMs: 0,
        durationMs: 5000,
      ),
    );
    overlay.clips.add(
      TimelineClip(
        id: 'title',
        assetId: 'text',
        trackId: 'o',
        startMs: 0,
        durationMs: 5000,
        text: 'OpenReel',
      ),
    );
    final frame = CompositionEngine().compose(project, 1000);
    expect(frame.visualLayers, hasLength(3));
    expect(frame.videoLayers, hasLength(1));
    expect(frame.imageLayers, hasLength(1));
    expect(frame.textLayers, hasLength(1));
    expect(frame.signature, isNotEmpty);
  });

  test('legenda permite editar, mover, dividir e excluir', () {
    final service = SubtitleService();
    final cues = service.parse('1\n00:00:01,000 --> 00:00:03,000\nTexto');
    final cue = cues.single;
    service.edit(cue, text: 'Novo texto');
    service.move(cue, 500);
    final second = service.split(cue, 2500);
    expect(cue.text, 'Novo texto');
    expect(cue.endMs, 2500);
    expect(second.startMs, 2500);
    service.delete(cues, cue);
    expect(cues, hasLength(0));
  });
}
