import 'package:flutter_test/flutter_test.dart';
import 'package:openreel/services/subtitle_service.dart';

void main() {
  test('parseia SRT com milissegundos e múltiplas linhas', () {
    final cues = SubtitleService().parse(
      '1\n00:00:01,250 --> 00:00:03,500\nOlá\nmundo\n',
    );
    expect(cues, hasLength(1));
    expect(cues.single.startMs, 1250);
    expect(cues.single.endMs, 3500);
    expect(cues.single.text, 'Olá\nmundo');
  });

  test('exporta VTT com cabeçalho e timestamps válidos', () {
    final vtt = SubtitleService().toVtt([
      SubtitleCue(startMs: 0, endMs: 1000, text: 'Teste'),
    ]);
    expect(vtt, startsWith('WEBVTT'));
    expect(vtt, contains('00:00:00.000 --> 00:00:01.000'));
  });
}
