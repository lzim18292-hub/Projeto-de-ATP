
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:openreel/models/project.dart';
import 'package:openreel/models/timeline.dart';
import 'package:openreel/services/short_auto_engine.dart';
import 'package:openreel/services/composition_engine.dart';
import 'package:openreel/models/model3d.dart';
import 'package:openreel/services/export_service.dart';
import 'package:openreel/services/template_service.dart';

void main() {

  test('template cria estrutura de tracks sem alterar projeto original', () {
    final service = TemplateService();
    final template = service.builtIns().first;
    final source = Project(id: 'p', name: 'Original');
    final result = service.apply(template, source);
    expect(result.name, 'Original');
    expect(result.tracks.map((t) => t.name), contains('Texto'));
    expect(source.tracks.map((t) => t.name), contains('Vídeo 1'));
  });

  test('JSON válido é validado e cria projeto sem render paralelo', () async {
    final engine = ShortAutoEngine();
    final project = await engine.fromJson(jsonEncode({
      'schemaVersion': '1.0',
      'name': 'Short teste',
      'width': 1080, 'height': 1920, 'fps': 30,
      'durationMs': 5000,
      'media': {},
      'texts': ['Olá'],
    }));
    expect(project.width, 1080);
    expect(project.height, 1920);
    expect(project.tracks.expand((t) => t.clips).any((c) => c.text == 'Olá'), isTrue);
  });

  test('JSON inválido e propriedade desconhecida geram erro claro', () async {
    final engine = ShortAutoEngine();
    expect(() => engine.parser.parseJson('{'), throwsA(isA<ShortAutoException>()));
    expect(
      () => engine.parser.parseJson(jsonEncode({'schemaVersion': '1.0', 'name': 'x', 'wat': 1})),
      throwsA(predicate((e) => '$e'.contains('Propriedade desconhecida'))),
    );
  });

  test('XML válido usa o mesmo builder do JSON', () async {
    final project = await ShortAutoEngine().fromXml(
      '<short><schemaVersion>1.0</schemaVersion><name>XML</name><width>1080</width><height>1920</height><fps>30</fps><text>Olá</text></short>',
    );
    expect(project.name, 'XML');
    expect(project.tracks.expand((t) => t.clips).any((c) => c.text == 'Olá'), isTrue);
  });


  test('3D export usa renderer offscreen e só recusa plataformas sem WebGL WebView', () async {
    final dir = await Directory.systemTemp.createTemp('openreel_3d_export_test');
    addTearDown(() => dir.delete(recursive: true));
    final project = Project(id: 'p', name: '3D', durationMs: 1000);
    final track = TimelineTrack(id: '3d', name: '3D', kind: TrackKind.object3d);
    project.tracks.add(track);
    track.clips.add(TimelineClip(id: 'c', assetId: '3d:m', object3dAssetId: 'm', trackId: '3d', startMs: 0, durationMs: 1000));
    expect(
      () => ExportService().export(project, '${dir.path}/out.mp4'),
      throwsA(predicate((e) => '$e'.contains('WebGL'))),
    );
  });

  test('GLB é validado e pode virar camada 3D no CompositionEngine', () async {
    final dir = await Directory.systemTemp.createTemp('openreel_3d_test');
    addTearDown(() => dir.delete(recursive: true));
    final json = utf8.encode('{"asset":{"version":"2.0"},"nodes":[{}],"animations":[{}]}');
    final padded = [...json, ...List<int>.filled((4 - json.length % 4) % 4, 0x20)];
    final raw = BytesBuilder()
      ..add(Uint8List.fromList([0x67,0x6c,0x54,0x46,2,0,0,0]))
      ..add(Uint8List.fromList([padded.length & 255, (padded.length>>8)&255, (padded.length>>16)&255, (padded.length>>24)&255]))
      ..add(Uint8List.fromList([0x4a,0x53,0x4f,0x4e]))
      ..add(Uint8List.fromList([0,0,0,0]))
      ..add(Uint8List.fromList(padded));
    final path = '${dir.path}/lua.glb';
    await File(path).writeAsBytes(raw.takeBytes());
    final model = await Model3DService().inspect(id: 'm1', path: path, name: 'Lua.glb');
    final project = Project(id: 'p', name: '3D', durationMs: 1000);
    project.model3dAssets.add(model);
    final track = TimelineTrack(id: '3d', name: '3D', kind: TrackKind.object3d);
    project.tracks.add(track);
    track.clips.add(TimelineClip(id: 'c', assetId: '3d:m1', object3dAssetId: 'm1', trackId: '3d', startMs: 0, durationMs: 1000));
    final frame = CompositionEngine().compose(project, 500);
    expect(frame.visualLayers.single.object3dAssetId, 'm1');
    expect(frame.visualLayers.single.sourcePath, path);
  });
}
