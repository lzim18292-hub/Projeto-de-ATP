import 'package:flutter_test/flutter_test.dart';
import 'package:openreel/models/project.dart';
import 'package:openreel/models/timeline.dart';
import 'package:openreel/services/composition_engine.dart';
import 'package:openreel/services/subtitle_service.dart';

void main() {
  test('tempo local, trim e speed não alteram a semântica dos keyframes', () {
    final project = Project(id: 'time', name: 'Tempo');
    final track = project.tracks.first;
    final clip = TimelineClip(
      id: 'c',
      assetId: 'asset',
      trackId: track.id,
      startMs: 1000,
      durationMs: 2000,
      sourceStartMs: 4000,
      speed: 2,
      positionXKeyframes: const [
        Keyframe(timeMs: 0, value: 0),
        Keyframe(timeMs: 1000, value: 100),
      ],
    );
    track.clips.add(clip);
    final engine = CompositionEngine();
    final frameStart = engine.compose(project, 1000);
    final frameMid = engine.compose(project, 1500);
    final frameEnd = engine.compose(project, 2999);
    expect(frameStart.layers.single.localTimeMs, 4000);
    expect(frameMid.layers.single.localTimeMs, 5000);
    expect(frameEnd.layers.single.localTimeMs, 7998);
    expect(frameMid.layers.single.transform.x, closeTo(50, .001));
    clip.trimLeft(500);
    expect(clip.startMs, 1500);
    expect(clip.sourceStartMs, 5000);
    expect(clip.durationMs, 1500);
    expect(
      clip.positionXKeyframes.map((keyframe) => keyframe.timeMs),
      [500],
    );
  });

  test('hold, linear, ease in, ease out e ease in-out são determinísticos', () {
    final project = Project(id: 'kf', name: 'Keyframes');
    final track = project.tracks.first;
    track.clips.add(
      TimelineClip(
        id: 'c',
        assetId: 'asset',
        trackId: track.id,
        startMs: 0,
        durationMs: 1000,
        opacityKeyframes: const [
          Keyframe(timeMs: 0, value: 0, interpolation: Interpolation.hold),
          Keyframe(timeMs: 500, value: 1, interpolation: Interpolation.easeOut),
        ],
      ),
    );
    final engine = CompositionEngine();
    expect(engine.compose(project, 250).layers.single.opacity, 0);
    expect(engine.compose(project, 750).layers.single.opacity, closeTo(1, .001));
  });

  test('legendas importadas fazem parte do projeto e da CompositionFrame', () {
    final project = Project(id: 'subs', name: 'Subs');
    project.subtitleCues.add(
      SubtitleCue(
        startMs: 500,
        endMs: 1500,
        text: 'Olá\\nOpenReel',
        style: const SubtitleStyle(x: .5, y: .8, fontSize: 40),
      ),
    );
    final frame = CompositionEngine().compose(project, 1000);
    expect(frame.subtitleLayers.single.text, 'Olá\\nOpenReel');
    expect(frame.subtitleLayers.single.subtitleStyle?.fontSize, 40);
    final roundTrip = Project.fromJson(project.toJson());
    expect(roundTrip.subtitleCues.single.text, 'Olá\\nOpenReel');
  });

  test('transição de entrada reduz opacity progressivamente', () {
    final project = Project(id: 'transition', name: 'Transition');
    final track = project.tracks.first;
    track.clips.add(
      TimelineClip(
        id: 'c',
        assetId: 'asset',
        trackId: track.id,
        startMs: 1000,
        durationMs: 2000,
        transitionIn: const TransitionConfig(type: 'fade', durationMs: 1000),
      ),
    );
    final frame = CompositionEngine().compose(project, 1500);
    expect(frame.layers.single.opacity, closeTo(.5, .001));
    expect(frame.layers.single.transitionType, 'fade');
  });

  test('ordem de tracks é a ordem Z compartilhada pela composição', () {
    final project = Project(id: 'z', name: 'Z');
    project.tracks.clear();
    final bottom = TimelineTrack(id: 'bottom', name: 'Bottom', kind: TrackKind.video);
    final top = TimelineTrack(id: 'top', name: 'Top', kind: TrackKind.overlay);
    bottom.clips.add(TimelineClip(id: 'a', assetId: 'a', trackId: bottom.id, startMs: 0, durationMs: 1000));
    top.clips.add(TimelineClip(id: 'b', assetId: 'b', trackId: top.id, startMs: 0, durationMs: 1000));
    project.tracks.addAll([bottom, top]);
    final frame = CompositionEngine().compose(project, 500);
    expect(frame.layers.map((e) => e.clipId), ['a', 'b']);
    expect(frame.signature, contains('a'));
    expect(frame.signature, contains('b'));
  });
}
