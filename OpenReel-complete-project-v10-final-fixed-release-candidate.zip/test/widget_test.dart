import 'package:flutter_test/flutter_test.dart';

import 'package:openreel/main.dart';

void main() {
  testWidgets('renderiza a Home de projetos do OpenReel', (tester) async {
    await tester.pumpWidget(const OpenReelApp());
    // ProjectHome performs an asynchronous repository refresh. A bounded
    // pump makes this test deterministic without requiring the entire widget
    // tree to become idle.
    await tester.pump(const Duration(seconds: 1));
    expect(find.text('OpenReel'), findsOneWidget);
    expect(find.text('Novo projeto'), findsOneWidget);
  });
}
